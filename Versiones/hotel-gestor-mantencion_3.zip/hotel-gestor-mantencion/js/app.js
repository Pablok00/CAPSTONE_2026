// ==========================================================
// APP PRINCIPAL & ENRUTADOR - HOTEL EL ALMENDRO
// ==========================================================

function navigateTo(viewName, filterAreaId = null) {
  currentView = viewName;
  if (filterAreaId !== undefined) {
    activeAreaFilter = filterAreaId;
  }
  
  document.querySelectorAll('.nav-item').forEach(btn => {
    btn.classList.remove('bg-blue-600/20', 'text-blue-400', 'border', 'border-blue-500/30');
  });
  const activeNav = document.getElementById(`nav-${viewName}`);
  if (activeNav) {
    activeNav.classList.add('bg-blue-600/20', 'text-blue-400', 'border', 'border-blue-500/30');
  }

  renderCurrentView();
}

function renderCurrentView() {
  const container = document.getElementById('view-container');
  const pageIcon = document.getElementById('page-icon');
  const pageTitle = document.getElementById('page-title');
  const pageSubtitle = document.getElementById('page-subtitle');

  switch (currentView) {
    case 'dashboard':
      pageIcon.textContent = '📊';
      pageTitle.textContent = 'Panel Principal - Hotel El Almendro';
      pageSubtitle.textContent = 'Navegación visual por los tres pilares de trabajo y resúmenes';
      container.innerHTML = renderDashboardView();
      break;

    case 'mantenciones':
      pageIcon.textContent = '🔧';
      pageTitle.textContent = 'Mantenciones del Hotel';
      pageSubtitle.textContent = 'Cuadrícula visual de mantenciones preventivas, correctivas y esporádicas';
      container.innerHTML = renderMaintenancesView();
      break;

    case 'mejoras':
      pageIcon.textContent = '🌿';
      pageTitle.textContent = 'Mejoras y Proyectos Nuevos';
      pageSubtitle.textContent = 'Obras, quincho, pérgolas, jardinería y conectividad';
      container.innerHTML = renderImprovementsView();
      break;

    case 'remodelaciones':
      pageIcon.textContent = '🏗️';
      pageTitle.textContent = 'Remodelaciones de Espacios';
      pageSubtitle.textContent = 'Renovación de habitaciones, salones y calculadora de materiales';
      container.innerHTML = renderRenovationsView();
      break;

    case 'activos':
      pageIcon.textContent = '🏷️';
      pageTitle.textContent = 'Activos Fijos y Equipamiento';
      pageSubtitle.textContent = 'Inventario, fichas técnicas, garantías automatizadas e historial';
      container.innerHTML = renderAssetsView();
      break;

    case 'areas':
      pageIcon.textContent = '📍';
      pageTitle.textContent = 'Áreas e Instalaciones de El Almendro';
      pageSubtitle.textContent = 'Navegación visual por sectores: Habitaciones, Comedor, Cocina, Jardines...';
      container.innerHTML = renderAreasView();
      break;

    case 'fechas-proximas':
      pageIcon.textContent = '📅';
      pageTitle.textContent = 'Fechas Próximas y Vencimientos';
      pageSubtitle.textContent = 'Cronograma en tarjetas organizado por días';
      container.innerHTML = renderUpcomingDatesView();
      break;

    case 'gantt':
      pageIcon.textContent = '📈';
      pageTitle.textContent = 'Línea de Tiempo & Diagrama Visual Gantt';
      pageSubtitle.textContent = 'Visualización 100% gráfica de obras y mantenciones sin listas ni tablas';
      container.innerHTML = renderGanttView();
      break;

    case 'solicitudes':
      pageIcon.textContent = '📩';
      pageTitle.textContent = 'Solicitudes de Personal y Huéspedes';
      pageSubtitle.textContent = 'Bandeja de solicitudes para conversión a órdenes de trabajo';
      container.innerHTML = renderRequestsView();
      break;

    case 'notificaciones':
      pageIcon.textContent = '🔔';
      pageTitle.textContent = 'Centro de Notificaciones y Alertas';
      pageSubtitle.textContent = 'Avisos automáticos de garantías, mantenciones atrasadas y asignaciones';
      container.innerHTML = renderNotificationsView();
      break;

    case 'importar':
      pageIcon.textContent = '📥';
      pageTitle.textContent = 'Importación de Datos Excel / CSV';
      pageSubtitle.textContent = 'Mapeo visual y carga masiva de datos';
      container.innerHTML = renderImportView();
      break;

    case 'configuracion':
      pageIcon.textContent = '⚙️';
      pageTitle.textContent = 'Configuración del Sistema';
      pageSubtitle.textContent = 'Ajustes de alertas de garantías, áreas y parámetros del hotel';
      container.innerHTML = renderSettingsView();
      break;

    default:
      container.innerHTML = `<div class="p-8 text-center"><p class="text-slate-500">Módulo en construcción</p></div>`;
  }

  updateSidebarBadges();
  populateSelectAreas();
}

function updateSidebarBadges() {
  const activeMnt = state.maintenances.filter(m => m.status !== 'Completada' && m.status !== 'Cancelada').length;
  const activeImp = state.improvements.filter(i => i.status !== 'Completado').length;
  const activeRen = state.renovations.filter(r => r.status !== 'Completado').length;
  const pendingReq = state.requests.filter(r => r.status === 'Pendiente').length;
  const unreadNotif = state.notifications.filter(n => !n.read).length;

  const elMnt = document.getElementById('badge-nav-mantenciones');
  const elImp = document.getElementById('badge-nav-mejoras');
  const elRen = document.getElementById('badge-nav-remodelaciones');
  const elAst = document.getElementById('badge-nav-activos');
  const elReq = document.getElementById('badge-nav-solicitudes');
  const elNot = document.getElementById('badge-nav-notif-count');
  const elTopNot = document.getElementById('topbar-notif-badge');

  if (elMnt) elMnt.textContent = activeMnt;
  if (elImp) elImp.textContent = activeImp;
  if (elRen) elRen.textContent = activeRen;
  if (elAst) elAst.textContent = state.assets.length;
  if (elReq) elReq.textContent = pendingReq;
  if (elNot) elNot.textContent = unreadNotif;
  if (elTopNot) {
    elTopNot.textContent = unreadNotif;
    elTopNot.style.display = unreadNotif > 0 ? 'flex' : 'none';
  }
}

function handleGlobalSearch(e) {
  const query = e.target.value.toLowerCase().trim();
  if (!query) return;
  if (e.key === 'Enter') {
    navigateTo('mantenciones');
  }
}

// Inicialización
window.addEventListener('DOMContentLoaded', () => {
  renderCurrentView();
});
