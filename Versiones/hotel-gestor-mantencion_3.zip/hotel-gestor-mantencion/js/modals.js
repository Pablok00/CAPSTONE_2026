// ==========================================================
// MODALES Y ACCIONES INTERACTIVAS - HOTEL EL ALMENDRO
// ==========================================================

function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.remove('hidden');
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.add('hidden');
}

function populateSelectAreas() {
  const select = document.getElementById('req-area');
  if (select) {
    select.innerHTML = state.areas.map(a => `<option value="${a.id}">${a.icon} ${a.name}</option>`).join('');
  }
  const reqRequester = document.getElementById('req-requester');
  if (reqRequester && state.currentUser) {
    reqRequester.value = `${state.currentUser.name} (${state.currentUser.title})`;
  }
}

function openNewRequestModal() {
  populateSelectAreas();
  openModal('modal-new-request');
}

function handleCreateRequest(e) {
  e.preventDefault();
  const title = document.getElementById('req-title').value;
  const areaId = document.getElementById('req-area').value;
  const location = document.getElementById('req-location').value;
  const description = document.getElementById('req-description').value;
  const priority = document.getElementById('req-priority').value;
  const requester = document.getElementById('req-requester').value;

  const areaObj = state.areas.find(a => a.id === areaId);

  const newReq = {
    id: `req_${Date.now()}`,
    title,
    areaId,
    areaName: areaObj ? areaObj.name : 'General',
    location,
    description,
    priority,
    requesterName: requester,
    requesterEmail: state.currentUser ? state.currentUser.email : 'contacto@elalmendro.cl',
    createdDate: '2026-08-28 ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    photo: null,
    status: 'Pendiente',
    convertedTo: null
  };

  state.requests.unshift(newReq);

  state.notifications.unshift({
    id: `notif_${Date.now()}`,
    type: 'info',
    title: `Nueva Solicitud: ${title}`,
    message: `${requester} ingresó solicitud en ${newReq.areaName} (${location}).`,
    timestamp: 'Recién',
    linkModule: 'solicitudes',
    read: false
  });

  saveState();
  closeModal('modal-new-request');
  document.getElementById('form-new-request').reset();
  alert("✅ Solicitud ingresada correctamente.");
}

function openConvertRequestModal(reqId) {
  activeConvertingRequestId = reqId;
  const req = state.requests.find(r => r.id === reqId);
  if (req) {
    document.getElementById('convert-req-title').textContent = req.title;
    openModal('modal-convert-request');
  }
}

function executeConversion(targetType) {
  if (!activeConvertingRequestId) return;
  const req = state.requests.find(r => r.id === activeConvertingRequestId);
  if (!req) return;

  if (targetType === 'Preventiva' || targetType === 'Correctiva' || targetType === 'Esporádica') {
    const newMnt = {
      id: `mnt_${Date.now()}`,
      title: req.title,
      description: req.description + ` (Originado desde solicitud de ${req.requesterName} en ${req.location})`,
      areaId: req.areaId,
      areaName: req.areaName,
      assetId: null,
      assetName: req.location,
      type: targetType,
      priority: req.priority,
      responsible: "Manuel Pérez",
      createdDate: "2026-08-28",
      startDate: "2026-08-29",
      limitDate: "2026-08-30",
      completedDate: null,
      status: "Pendiente",
      estimatedCost: 30000,
      actualCost: 0,
      photosBefore: [],
      photosAfter: [],
      documents: [],
      observations: "Solicitud convertida."
    };
    state.maintenances.unshift(newMnt);
  } else if (targetType === 'Mejora') {
    const newImp = {
      id: `imp_${Date.now()}`,
      name: req.title,
      description: req.description,
      areaId: req.areaId,
      areaName: req.areaName,
      responsible: "Carolina Morales",
      startDate: "2026-09-01",
      endDate: "2026-09-30",
      priority: req.priority,
      status: "Planificación",
      budget: 1000000,
      actualCost: 0,
      progressPercent: 0,
      materials: [],
      photos: [],
      documents: []
    };
    state.improvements.unshift(newImp);
  } else if (targetType === 'Remodelacion') {
    const newRen = {
      id: `ren_${Date.now()}`,
      name: req.title,
      space: req.location,
      areaId: req.areaId,
      areaName: req.areaName,
      description: req.description,
      responsible: "Carolina Morales",
      startDate: "2026-09-01",
      endDate: "2026-09-30",
      status: "Planificación",
      budget: 2000000,
      progressPercent: 0,
      materials: []
    };
    state.renovations.unshift(newRen);
  }

  req.status = 'Convertida';
  req.convertedTo = { type: targetType, id: `gen_${Date.now()}` };

  saveState();
  closeModal('modal-convert-request');
  alert(`✅ Solicitud convertida exitosamente a ${targetType}.`);
}

function openMaintenanceDetail(mntId) {
  const mnt = state.maintenances.find(m => m.id === mntId);
  if (!mnt) return;

  const content = document.getElementById('maintenance-modal-content');
  content.innerHTML = `
    <div class="flex items-center justify-between pb-4 border-b border-slate-100">
      <div>
        <span class="text-xs font-extrabold px-2.5 py-1 rounded-md uppercase bg-blue-100 text-blue-800">
          Mantención ${mnt.type}
        </span>
        <h3 class="text-xl font-extrabold text-slate-900 mt-2">${mnt.title}</h3>
      </div>
      <button onclick="closeModal('modal-maintenance-detail')" class="text-slate-400 hover:text-slate-600 text-2xl font-bold p-1">&times;</button>
    </div>

    <div class="mt-5 grid grid-cols-1 md:grid-cols-2 gap-6">
      <div class="space-y-4">
        <div>
          <p class="text-xs font-bold text-slate-400 uppercase">Descripción</p>
          <p class="text-xs text-slate-700 mt-1 leading-relaxed">${mnt.description}</p>
        </div>

        <div class="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
          <div>
            <p class="text-[10px] text-slate-400 uppercase font-bold">Área</p>
            <p class="font-bold text-slate-800">${mnt.areaName}</p>
          </div>
          <div>
            <p class="text-[10px] text-slate-400 uppercase font-bold">Activo Vinculado</p>
            <p class="font-bold text-blue-700">${mnt.assetName || 'Instalación General'}</p>
          </div>
        </div>

        <div class="grid grid-cols-2 gap-3 text-xs">
          <div>
            <p class="text-[10px] text-slate-400 uppercase font-bold">Fecha Inicio</p>
            <p class="font-bold text-slate-800">${formatDate(mnt.startDate)}</p>
          </div>
          <div>
            <p class="text-[10px] text-slate-400 uppercase font-bold">Fecha Límite</p>
            <p class="font-bold text-slate-800">${formatDate(mnt.limitDate)}</p>
          </div>
        </div>

        <div class="p-3 bg-blue-50/60 rounded-xl border border-blue-100 text-xs">
          <p class="text-[10px] font-bold text-blue-900 uppercase">Control de Costos</p>
          <div class="flex items-center justify-between mt-1">
            <span>Costo Estimado: <strong>${formatCLP(mnt.estimatedCost)}</strong></span>
            <span>Costo Real: <strong>${formatCLP(mnt.actualCost)}</strong></span>
          </div>
        </div>
      </div>

      <div class="space-y-4">
        <div>
          <label class="block text-xs font-bold text-slate-400 uppercase mb-1">Estado de la Mantención</label>
          <select onchange="updateMaintenanceStatus('${mnt.id}', this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-bold text-slate-800">
            <option value="Pendiente" ${mnt.status === 'Pendiente' ? 'selected' : ''}>Pendiente</option>
            <option value="Programada" ${mnt.status === 'Programada' ? 'selected' : ''}>Programada</option>
            <option value="En proceso" ${mnt.status === 'En proceso' ? 'selected' : ''}>En proceso</option>
            <option value="Completada" ${mnt.status === 'Completada' ? 'selected' : ''}>Completada</option>
            <option value="Atrasada" ${mnt.status === 'Atrasada' ? 'selected' : ''}>Atrasada</option>
            <option value="Cancelada" ${mnt.status === 'Cancelada' ? 'selected' : ''}>Cancelada</option>
          </select>
        </div>

        <div>
          <p class="text-xs font-bold text-slate-400 uppercase mb-1">Observaciones Técnicas</p>
          <p class="text-xs text-slate-700 bg-slate-50 p-3 rounded-xl border border-slate-200">
            ${mnt.observations || 'Sin observaciones adicionales.'}
          </p>
        </div>

        ${mnt.photosBefore && mnt.photosBefore.length > 0 ? `
          <div>
            <p class="text-xs font-bold text-slate-400 uppercase mb-1">Fotografías del Trabajo</p>
            <div class="grid grid-cols-2 gap-2">
              <div>
                <p class="text-[10px] text-slate-500 font-bold mb-0.5">Antes:</p>
                <img src="${mnt.photosBefore[0]}" class="rounded-xl h-24 w-full object-cover border border-slate-200">
              </div>
              ${mnt.photosAfter && mnt.photosAfter.length > 0 ? `
                <div>
                  <p class="text-[10px] text-slate-500 font-bold mb-0.5">Después:</p>
                  <img src="${mnt.photosAfter[0]}" class="rounded-xl h-24 w-full object-cover border border-slate-200">
                </div>
              ` : ''}
            </div>
          </div>
        ` : ''}
      </div>
    </div>

    <div class="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
      <span class="text-xs text-slate-500">Responsable asignado: <strong>${mnt.responsible}</strong></span>
      <button onclick="closeModal('modal-maintenance-detail')" class="px-5 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold">
        Cerrar Ficha
      </button>
    </div>
  `;
  openModal('modal-maintenance-detail');
}

function updateMaintenanceStatus(mntId, newStatus) {
  const mnt = state.maintenances.find(m => m.id === mntId);
  if (mnt) {
    mnt.status = newStatus;
    if (newStatus === 'Completada') {
      mnt.completedDate = '2026-08-28';
    }
    saveState();
    openMaintenanceDetail(mntId);
  }
}

function openAssetDetail(assetId, tab = 'ficha') {
  selectedAssetTab = tab;
  const asset = state.assets.find(a => a.id === assetId);
  if (!asset) return;

  const wInfo = calculateWarrantyStatus(asset.warranty);
  const content = document.getElementById('asset-modal-content');

  content.innerHTML = `
    <div class="flex items-center justify-between pb-4 border-b border-slate-100">
      <div class="flex items-center space-x-3">
        <div class="w-12 h-12 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center text-2xl font-bold">
          🏷️
        </div>
        <div>
          <div class="flex items-center space-x-2">
            <h3 class="text-lg font-extrabold text-slate-900">${asset.name}</h3>
            <span class="text-xs font-bold px-2.5 py-0.5 rounded-full ${wInfo.status === 'Vigente' ? 'bg-emerald-100 text-emerald-800' : wInfo.status === 'Proxima' ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'}">
              ${wInfo.badge}
            </span>
          </div>
          <p class="text-xs text-slate-500">${asset.brand} • Modelo ${asset.model} • N° Serie: ${asset.serialNumber}</p>
        </div>
      </div>
      <button onclick="closeModal('modal-asset-detail')" class="text-slate-400 hover:text-slate-600 text-2xl font-bold p-1">&times;</button>
    </div>

    <div class="flex items-center space-x-2 border-b border-slate-200 mt-4 pb-2">
      <button onclick="openAssetDetail('${asset.id}', 'ficha')" class="px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${selectedAssetTab === 'ficha' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'}">
        📋 Ficha Técnica
      </button>
      <button onclick="openAssetDetail('${asset.id}', 'garantia')" class="px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${selectedAssetTab === 'garantia' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'}">
        🛡️ Garantía & Documentos
      </button>
      <button onclick="openAssetDetail('${asset.id}', 'plan')" class="px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${selectedAssetTab === 'plan' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'}">
        🔄 Plan de Mantenimiento
      </button>
      <button onclick="openAssetDetail('${asset.id}', 'historial')" class="px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${selectedAssetTab === 'historial' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'}">
        📜 Historial Cronológico
      </button>
    </div>

    <div class="mt-5">
      ${renderAssetTabContent(asset, selectedAssetTab, wInfo)}
    </div>
  `;
  openModal('modal-asset-detail');
}

function renderAssetTabContent(asset, tab, wInfo) {
  if (tab === 'ficha') {
    return `
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="space-y-3 text-xs">
          <div class="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
            <div class="flex justify-between">
              <span class="text-slate-500 font-bold">Categoría:</span>
              <span class="font-bold text-slate-800">${asset.category}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-500 font-bold">Ubicación:</span>
              <span class="font-bold text-slate-800">${asset.areaName} (${asset.location})</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-500 font-bold">Proveedor:</span>
              <span class="font-bold text-slate-800">${asset.provider}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-500 font-bold">Fecha de Compra:</span>
              <span class="font-bold text-slate-800">${formatDate(asset.purchaseDate)}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-500 font-bold">Valor de Adquisición:</span>
              <span class="font-extrabold text-blue-700">${formatCLP(asset.purchaseValue)}</span>
            </div>
          </div>
        </div>
        <div>
          <img src="${asset.photo}" alt="${asset.name}" class="w-full h-48 object-cover rounded-2xl border border-slate-200">
        </div>
      </div>
    `;
  } else if (tab === 'garantia') {
    return `
      <div class="space-y-4 text-xs">
        <div class="p-4 bg-amber-50/70 border border-amber-200 rounded-2xl">
          <h4 class="font-extrabold text-amber-900 text-sm">Estado de Garantía: ${wInfo.badge}</h4>
          <p class="text-slate-700 mt-1">${wInfo.text}</p>
          <div class="mt-3 grid grid-cols-2 gap-2 text-slate-700">
            <div>Proveedor: <strong>${asset.warranty.provider || asset.provider}</strong></div>
            <div>Póliza / Ref: <strong>${asset.warranty.referenceDoc || 'S/N'}</strong></div>
          </div>
          <p class="mt-2 text-slate-600"><em>${asset.warranty.notes || ''}</em></p>
        </div>

        <div>
          <h4 class="font-bold text-slate-800 mb-2">Documentos Adjuntos (Facturas, Manuales, Pólizas)</h4>
          <div class="space-y-2">
            ${(asset.documents || []).map(doc => `
              <div class="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                <div class="flex items-center space-x-2">
                  <span class="text-base">📄</span>
                  <div>
                    <p class="font-bold text-slate-800">${doc.name}</p>
                    <p class="text-[10px] text-slate-500">${doc.size} • Subido el ${formatDate(doc.date)}</p>
                  </div>
                </div>
                <button class="text-xs font-bold text-blue-600 hover:underline">Descargar</button>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;
  } else if (tab === 'plan') {
    return `
      <div class="space-y-4 text-xs">
        <div class="p-4 bg-blue-50/70 border border-blue-200 rounded-2xl">
          <h4 class="font-extrabold text-blue-900 text-sm">Pauta Preventiva: ${asset.maintenancePlan.type}</h4>
          <div class="mt-3 grid grid-cols-2 gap-3 text-slate-700">
            <div>Frecuencia: <strong>${asset.maintenancePlan.frequencyLabel}</strong></div>
            <div>Responsable: <strong>${asset.maintenancePlan.responsible}</strong></div>
            <div>Última Mantención: <strong>${formatDate(asset.maintenancePlan.lastDate)}</strong></div>
            <div class="text-blue-800 font-bold">Próxima Mantención: <strong>${formatDate(asset.maintenancePlan.nextDate)}</strong></div>
          </div>
          <p class="mt-2 text-slate-600"><em>Instrucciones: ${asset.maintenancePlan.notes}</em></p>
        </div>
      </div>
    `;
  } else if (tab === 'historial') {
    return `
      <div class="space-y-3">
        <h4 class="text-xs font-bold text-slate-400 uppercase">Línea de Tiempo del Activo (Historial Perpetuo)</h4>
        <div class="space-y-3 pl-2 border-l-2 border-slate-200">
          ${(asset.history || []).map(h => `
            <div class="relative pl-4 text-xs">
              <div class="absolute -left-[21px] top-1 w-3 h-3 rounded-full bg-blue-600 border-2 border-white"></div>
              <div class="flex items-center justify-between">
                <span class="font-extrabold text-slate-800">${h.type}</span>
                <span class="text-slate-500 font-semibold">${formatDate(h.date)}</span>
              </div>
              <p class="text-slate-600 mt-0.5">${h.description}</p>
              <div class="mt-1 text-[11px] text-slate-400 flex items-center justify-between">
                <span>Registrado por: ${h.user}</span>
                ${h.cost > 0 ? `<span class="font-bold text-slate-800">Costo: ${formatCLP(h.cost)}</span>` : ''}
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }
}

function openRenovationDetail(renId) {
  const ren = state.renovations.find(r => r.id === renId);
  if (!ren) return;

  const totalCost = (ren.materials || []).reduce((acc, m) => acc + (m.subtotal || 0), 0);
  const content = document.getElementById('renovation-modal-content');

  content.innerHTML = `
    <div class="flex items-center justify-between pb-4 border-b border-slate-100">
      <div>
        <span class="text-xs font-extrabold bg-purple-100 text-purple-800 px-2.5 py-1 rounded-md uppercase">
          Remodelación: ${ren.space}
        </span>
        <h3 class="text-xl font-extrabold text-slate-900 mt-2">${ren.name}</h3>
      </div>
      <button onclick="closeModal('modal-renovation-detail')" class="text-slate-400 hover:text-slate-600 text-2xl font-bold p-1">&times;</button>
    </div>

    <div class="mt-4 space-y-4">
      <p class="text-xs text-slate-700 leading-relaxed">${ren.description}</p>

      <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200">
        <div class="flex items-center justify-between mb-3">
          <h4 class="text-xs font-extrabold text-slate-800 uppercase">Lista y Cómputo de Materiales</h4>
          <span class="text-xs font-black text-purple-700">Total: ${formatCLP(totalCost)}</span>
        </div>

        <div class="space-y-2 max-h-60 overflow-y-auto custom-scrollbar pr-1">
          ${(ren.materials || []).map(mat => `
            <div class="p-2.5 bg-white rounded-xl border border-slate-200 text-xs flex items-center justify-between">
              <div>
                <p class="font-bold text-slate-800">${mat.name}</p>
                <p class="text-[11px] text-slate-500">${mat.quantity} ${mat.unit} × ${formatCLP(mat.unitCost)}</p>
              </div>
              <span class="font-extrabold text-slate-900">${formatCLP(mat.subtotal)}</span>
            </div>
          `).join('')}
        </div>

        <form onsubmit="handleAddMaterial(event, '${ren.id}')" class="mt-4 pt-3 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-4 gap-2">
          <input type="text" id="new-mat-name" required placeholder="Nombre de material" class="sm:col-span-2 bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs">
          <input type="number" id="new-mat-qty" required placeholder="Cant." value="1" class="bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs">
          <input type="number" id="new-mat-price" required placeholder="Costo Unit." class="bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs">
          <button type="submit" class="sm:col-span-4 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs py-2 rounded-xl">
            + Agregar Insumo a la Calculadora
          </button>
        </form>
      </div>
    </div>
  `;
  openModal('modal-renovation-detail');
}

function handleAddMaterial(e, renId) {
  e.preventDefault();
  const name = document.getElementById('new-mat-name').value;
  const qty = parseFloat(document.getElementById('new-mat-qty').value) || 1;
  const price = parseFloat(document.getElementById('new-mat-price').value) || 0;

  const ren = state.renovations.find(r => r.id === renId);
  if (ren) {
    if (!ren.materials) ren.materials = [];
    ren.materials.push({
      id: `mat_${Date.now()}`,
      name,
      quantity: qty,
      unit: 'unidades',
      unitCost: price,
      subtotal: qty * price
    });
    saveState();
    openRenovationDetail(renId);
  }
}

function openImprovementDetail(impId) {
  const imp = state.improvements.find(i => i.id === impId);
  if (!imp) return;
  const content = document.getElementById('improvement-modal-content');
  content.innerHTML = `
    <div class="flex items-center justify-between pb-4 border-b border-slate-100">
      <div>
        <span class="text-xs font-extrabold bg-emerald-100 text-emerald-800 px-2.5 py-1 rounded-md uppercase">
          Proyecto de Mejora
        </span>
        <h3 class="text-xl font-extrabold text-slate-900 mt-2">${imp.name}</h3>
      </div>
      <button onclick="closeModal('modal-improvement-detail')" class="text-slate-400 hover:text-slate-600 text-2xl font-bold p-1">&times;</button>
    </div>
    <div class="mt-4 space-y-3 text-xs">
      <p class="text-slate-700 leading-relaxed">${imp.description}</p>
      <div class="p-3 bg-emerald-50 rounded-xl border border-emerald-200">
        <div class="flex justify-between font-bold">
          <span>Presupuesto Aprobado: ${formatCLP(imp.budget)}</span>
          <span>Avance: ${imp.progressPercent}%</span>
        </div>
      </div>
    </div>
  `;
  openModal('modal-improvement-detail');
}

function toggleRoleDropdown() {
  const dropdown = document.getElementById('role-dropdown');
  dropdown.classList.toggle('hidden');
}

function switchRole(roleName) {
  const user = state.users.find(u => u.role === roleName) || state.users[0];
  state.currentUser = user;
  document.getElementById('sidebar-user-name').textContent = user.name;
  document.getElementById('sidebar-user-role').textContent = user.role;
  document.getElementById('sidebar-user-avatar').textContent = user.avatar;
  document.getElementById('topbar-role-badge').textContent = user.role;
  document.getElementById('role-dropdown').classList.add('hidden');
  saveState();
}

function toggleNotificationDropdown() {
  const dropdown = document.getElementById('notification-dropdown');
  dropdown.classList.toggle('hidden');
  if (typeof renderTopbarNotifications === 'function') renderTopbarNotifications();
}
