// ==========================================================
// VISTA: ÁREAS DEL HOTEL - HOTEL EL ALMENDRO
// ==========================================================

function renderAreasView() {
  return `
    <div class="space-y-6 max-w-7xl mx-auto pb-10">
      
      <div class="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h3 class="text-base font-bold text-slate-800">Sectores e Instalaciones de El Almendro</h3>
          <p class="text-xs text-slate-600">Presiona cualquier área para explorar sus actividades de mantención y activos fijos asignados.</p>
        </div>
        <div class="text-xs font-bold text-blue-700 bg-blue-50 border border-blue-200 px-3 py-1.5 rounded-xl">
          ${state.areas.length} Áreas Operativas
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        ${state.areas.map(area => {
          const areaMaintenances = state.maintenances.filter(m => m.areaId === area.id && m.status !== 'Completada');
          const areaAssets = state.assets.filter(a => a.areaId === area.id);
          const areaRequests = state.requests.filter(r => r.areaId === area.id && r.status === 'Pendiente');

          return `
            <div onclick="drillDownArea('${area.id}')" class="bg-white rounded-3xl p-6 border-2 border-slate-200 hover:border-blue-500 hover:shadow-xl transition-all cursor-pointer card-hover flex flex-col justify-between group">
              
              <div>
                <div class="flex items-center justify-between">
                  <div class="w-16 h-16 rounded-2xl bg-slate-100 group-hover:bg-blue-50 flex items-center justify-center text-4xl shadow-inner transition-colors">
                    ${area.icon}
                  </div>
                  ${area.alerts > 0 ? `
                    <span class="bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold px-2.5 py-1 rounded-full flex items-center space-x-1">
                      <span>⚠️</span>
                      <span>${area.alerts} Alertas</span>
                    </span>
                  ` : `
                    <span class="bg-emerald-100 text-emerald-700 text-xs font-bold px-2.5 py-1 rounded-full">
                      ✓ Al día
                    </span>
                  `}
                </div>

                <h4 class="text-xl font-extrabold text-slate-800 mt-4 group-hover:text-blue-600 transition-colors">
                  ${area.name}
                </h4>
                <p class="text-xs text-slate-600 mt-1 leading-relaxed">
                  ${area.description}
                </p>

                <div class="grid grid-cols-3 gap-2 mt-5 pt-4 border-t border-slate-100">
                  <div class="bg-slate-50 rounded-xl p-2.5 text-center">
                    <p class="text-[10px] text-slate-600 font-bold uppercase">Mantenciones</p>
                    <p class="text-base font-extrabold text-blue-600">${areaMaintenances.length}</p>
                  </div>
                  <div class="bg-slate-50 rounded-xl p-2.5 text-center">
                    <p class="text-[10px] text-slate-600 font-bold uppercase">Activos</p>
                    <p class="text-base font-extrabold text-slate-800">${areaAssets.length}</p>
                  </div>
                  <div class="bg-slate-50 rounded-xl p-2.5 text-center">
                    <p class="text-[10px] text-slate-600 font-bold uppercase">Solicitudes</p>
                    <p class="text-base font-extrabold ${areaRequests.length > 0 ? 'text-amber-600 font-black' : 'text-slate-400'}">${areaRequests.length}</p>
                  </div>
                </div>
              </div>

              <div class="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-blue-600 group-hover:text-blue-700">
                <span>Ver actividades y equipamiento</span>
                <span class="group-hover:translate-x-1 transition-transform">→</span>
              </div>

            </div>
          `;
        }).join('')}
      </div>

    </div>
  `;
}

function drillDownArea(areaId) {
  activeAreaFilter = areaId;
  maintenanceAreaFilter = areaId;
  navigateTo('mantenciones', areaId);
}
