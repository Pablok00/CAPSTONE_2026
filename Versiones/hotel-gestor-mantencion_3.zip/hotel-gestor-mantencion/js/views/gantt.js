// ==========================================================
// VISTA: CARTA GANTT & LÍNEA DE TIEMPO (100% VISUAL)
// ==========================================================

function renderGanttView() {
  let allItems = [
    ...state.improvements.map(i => ({
      id: i.id,
      module: 'mejoras',
      title: i.name,
      start: i.startDate,
      end: i.endDate,
      type: 'Mejora',
      category: 'Obra / Proyecto',
      icon: '🌿',
      area: i.areaName,
      responsible: i.responsible,
      progress: i.progressPercent,
      budget: i.budget,
      status: i.status,
      phase: i.progressPercent === 100 ? 'Completada' : (new Date(i.startDate) <= new Date('2026-08-28') ? 'En Curso Ahora' : 'Próximas Semanas'),
      color: 'emerald'
    })),
    ...state.renovations.map(r => ({
      id: r.id,
      module: 'remodelaciones',
      title: r.name,
      start: r.startDate,
      end: r.endDate,
      type: 'Remodelación',
      category: 'Espacio / Obra',
      icon: '🏗️',
      area: r.areaName,
      responsible: r.responsible,
      progress: r.progressPercent,
      budget: r.budget,
      status: r.status,
      phase: r.progressPercent === 100 ? 'Completada' : (new Date(r.startDate) <= new Date('2026-08-28') ? 'En Curso Ahora' : 'Próximas Semanas'),
      color: 'purple'
    })),
    ...state.maintenances.filter(m => m.startDate && m.limitDate).map(m => ({
      id: m.id,
      module: 'mantenciones',
      title: m.title,
      start: m.startDate,
      end: m.limitDate,
      type: m.type,
      category: 'Mantención',
      icon: '🔧',
      area: m.areaName,
      responsible: m.responsible,
      progress: m.status === 'Completada' ? 100 : (m.status === 'En proceso' ? 50 : 15),
      budget: m.estimatedCost,
      status: m.status,
      phase: m.status === 'Completada' ? 'Completada' : (new Date(m.startDate) <= new Date('2026-08-28') ? 'En Curso Ahora' : 'Próximas Semanas'),
      color: m.type === 'Preventiva' ? 'blue' : (m.type === 'Correctiva' ? 'amber' : 'indigo')
    }))
  ];

  if (ganttCategoryFilter !== 'TODAS') {
    allItems = allItems.filter(item => item.type === ganttCategoryFilter);
  }

  const timeSlots = [
    { label: 'Ago 15 - Ago 21', short: 'Ago Sem 3', start: '2026-08-15', end: '2026-08-21' },
    { label: 'Ago 22 - Ago 31', short: 'Ago Sem 4', start: '2026-08-22', end: '2026-08-31' },
    { label: 'Sep 01 - Sep 10', short: 'Sep Inicial', start: '2026-09-01', end: '2026-09-10' },
    { label: 'Sep 11 - Sep 20', short: 'Sep Medio', start: '2026-09-11', end: '2026-09-20' },
    { label: 'Sep 21 - Sep 30', short: 'Sep Cierre', start: '2026-09-21', end: '2026-09-30' },
    { label: 'Oct 01 - Oct 15', short: 'Octubre', start: '2026-10-01', end: '2026-10-15' }
  ];

  const activeNow = allItems.filter(i => i.phase === 'En Curso Ahora');
  const upcomingWeeks = allItems.filter(i => i.phase === 'Próximas Semanas');
  const completedWorks = allItems.filter(i => i.phase === 'Completada');

  return `
    <div class="space-y-6 max-w-7xl mx-auto pb-10">
      
      <!-- ENCABEZADO Y CONTROLES DEL GANTT VISUAL -->
      <div class="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-4 border border-slate-700">
        <div>
          <div class="flex items-center space-x-2">
            <span class="text-2xl">📈</span>
            <h3 class="text-xl font-extrabold">Cronograma Visual de Obras & Mantenciones</h3>
          </div>
          <p class="text-slate-300 text-xs mt-1">Diagrama gráfico interactivo de barras de tiempo y tarjetas por horizontes (cero tablas ni listas).</p>
        </div>

        <div class="flex items-center space-x-2 bg-slate-950/80 p-1.5 rounded-2xl border border-slate-700">
          <button onclick="ganttViewMode='timeline'; renderCurrentView();" class="px-4 py-2 rounded-xl text-xs font-extrabold transition-all flex items-center space-x-1.5 ${ganttViewMode === 'timeline' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white'}">
            <span>📊</span>
            <span>Diagrama Visual Gantt</span>
          </button>
          <button onclick="ganttViewMode='horizontes'; renderCurrentView();" class="px-4 py-2 rounded-xl text-xs font-extrabold transition-all flex items-center space-x-1.5 ${ganttViewMode === 'horizontes' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white'}">
            <span>🗂️</span>
            <span>Tarjetas por Fase</span>
          </button>
        </div>
      </div>

      <!-- BARRA DE FILTROS RÁPIDOS -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
        <div class="flex flex-wrap items-center gap-2">
          <span class="text-xs font-extrabold text-slate-600 uppercase mr-1">Filtrar:</span>
          <button onclick="ganttCategoryFilter='TODAS'; renderCurrentView();" class="px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${ganttCategoryFilter === 'TODAS' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}">
            Todos (${allItems.length})
          </button>
          <button onclick="ganttCategoryFilter='Mejora'; renderCurrentView();" class="px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${ganttCategoryFilter === 'Mejora' ? 'bg-emerald-600 text-white' : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'}">
            🌿 Mejoras
          </button>
          <button onclick="ganttCategoryFilter='Remodelación'; renderCurrentView();" class="px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${ganttCategoryFilter === 'Remodelación' ? 'bg-purple-600 text-white' : 'bg-purple-50 text-purple-800 hover:bg-purple-100'}">
            🏗️ Remodelaciones
          </button>
          <button onclick="ganttCategoryFilter='Preventiva'; renderCurrentView();" class="px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${ganttCategoryFilter === 'Preventiva' ? 'bg-blue-600 text-white' : 'bg-blue-50 text-blue-800 hover:bg-blue-100'}">
            🔧 Preventivas
          </button>
        </div>

        <div class="flex items-center space-x-3 text-xs font-semibold text-slate-600">
          <span class="flex items-center space-x-1.5"><span class="w-3 h-3 rounded-full bg-emerald-500"></span><span>Mejoras</span></span>
          <span class="flex items-center space-x-1.5"><span class="w-3 h-3 rounded-full bg-purple-500"></span><span>Remodelaciones</span></span>
          <span class="flex items-center space-x-1.5"><span class="w-3 h-3 rounded-full bg-blue-500"></span><span>Mantenciones</span></span>
        </div>
      </div>

      <!-- VISTA 1: CANVAS DIAGRAMA GANTT VISUAL -->
      ${ganttViewMode === 'timeline' ? `
        <div class="bg-white rounded-3xl p-6 border border-slate-200 shadow-lg overflow-x-auto custom-scrollbar">
          
          <div class="min-w-[760px]">
            <div class="grid grid-cols-6 gap-2 mb-4 text-center">
              ${timeSlots.map(slot => `
                <div class="p-3 bg-slate-900 text-white rounded-2xl shadow-sm border border-slate-800">
                  <p class="text-xs font-extrabold">${slot.short}</p>
                  <p class="text-[10px] text-slate-400 font-medium mt-0.5">${slot.label}</p>
                </div>
              `).join('')}
            </div>

            <div class="space-y-4 pt-2">
              ${allItems.map(item => {
                let colStart = 1;
                let colSpan = 2;
                const sDate = item.start;
                
                if (sDate < '2026-08-22') { colStart = 1; colSpan = 3; }
                else if (sDate < '2026-09-01') { colStart = 2; colSpan = 2; }
                else if (sDate < '2026-09-11') { colStart = 3; colSpan = 3; }
                else if (sDate < '2026-09-21') { colStart = 4; colSpan = 2; }
                else { colStart = 5; colSpan = 2; }

                const bgColors = {
                  'emerald': 'from-emerald-600 to-teal-700 border-emerald-500/40 text-white',
                  'purple': 'from-purple-600 to-indigo-700 border-purple-500/40 text-white',
                  'blue': 'from-blue-600 to-indigo-600 border-blue-500/40 text-white',
                  'amber': 'from-amber-600 to-orange-700 border-amber-500/40 text-white',
                  'indigo': 'from-indigo-600 to-purple-600 border-indigo-500/40 text-white'
                };

                return `
                  <div class="grid grid-cols-6 gap-2 items-center">
                    <div onclick="${item.module === 'mejoras' ? `openImprovementDetail('${item.id}')` : (item.module === 'remodelaciones' ? `openRenovationDetail('${item.id}')` : `openMaintenanceDetail('${item.id}')`)}" 
                         class="col-start-${colStart} col-span-${colSpan} bg-gradient-to-r ${bgColors[item.color]} rounded-2xl p-3.5 shadow-md hover:shadow-xl cursor-pointer transition-all transform hover:-translate-y-1 group border">
                      
                      <div class="flex items-center justify-between gap-2">
                        <div class="flex items-center space-x-2 min-w-0">
                          <span class="text-xl flex-shrink-0">${item.icon}</span>
                          <div class="min-w-0">
                            <h5 class="text-xs font-black truncate text-white leading-tight group-hover:text-amber-200 transition-colors">${item.title}</h5>
                            <p class="text-[10px] text-white/80 font-medium truncate">${item.area} • ${item.responsible.split(' ')[0]}</p>
                          </div>
                        </div>

                        <div class="flex items-center space-x-2 flex-shrink-0">
                          <span class="bg-black/25 backdrop-blur-sm text-white font-extrabold text-[10px] px-2 py-0.5 rounded-lg">
                            ${item.progress}%
                          </span>
                        </div>
                      </div>

                      <div class="mt-2.5 pt-2 border-t border-white/20 flex items-center justify-between text-[10px] font-semibold text-white/90">
                        <span>📅 ${formatDate(item.start)} al ${formatDate(item.end)}</span>
                        <span class="bg-white/20 px-1.5 py-0.5 rounded uppercase font-bold text-[9px]">${item.status}</span>
                      </div>

                      <div class="w-full bg-black/30 rounded-full h-1.5 mt-2 overflow-hidden">
                        <div class="bg-white h-1.5 rounded-full" style="width: ${item.progress}%"></div>
                      </div>

                    </div>
                  </div>
                `;
              }).join('')}
            </div>
          </div>

        </div>
      ` : `
        <!-- VISTA 2: TABLERO POR FASES / HORIZONTES -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          <div class="bg-slate-50/80 rounded-3xl p-5 border-2 border-emerald-200 shadow-sm flex flex-col space-y-4">
            <div class="flex items-center justify-between pb-3 border-b border-emerald-200">
              <div class="flex items-center space-x-2">
                <span class="w-3.5 h-3.5 rounded-full bg-emerald-500 animate-ping"></span>
                <h4 class="font-extrabold text-sm text-slate-800 uppercase">En Ejecución Esta Semana</h4>
              </div>
              <span class="bg-emerald-100 text-emerald-800 text-xs font-black px-2.5 py-0.5 rounded-full">${activeNow.length}</span>
            </div>

            <div class="space-y-3.5">
              ${activeNow.map(item => `
                <div onclick="${item.module === 'mejoras' ? `openImprovementDetail('${item.id}')` : (item.module === 'remodelaciones' ? `openRenovationDetail('${item.id}')` : `openMaintenanceDetail('${item.id}')`)}" 
                     class="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm hover:shadow-md cursor-pointer card-hover transition-all">
                  <div class="flex items-center justify-between mb-2">
                    <span class="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md bg-${item.color}-100 text-${item.color}-800">
                      ${item.icon} ${item.type}
                    </span>
                    <span class="text-xs font-bold text-slate-500">${item.area.split(' ')[0]}</span>
                  </div>
                  <h5 class="text-sm font-bold text-slate-900 leading-snug">${item.title}</h5>
                  
                  <div class="mt-3">
                    <div class="flex justify-between text-xs font-semibold text-slate-600 mb-1">
                      <span>Avance</span>
                      <span class="font-extrabold text-${item.color}-700">${item.progress}%</span>
                    </div>
                    <div class="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                      <div class="bg-${item.color}-600 h-2 rounded-full" style="width: ${item.progress}%"></div>
                    </div>
                  </div>

                  <div class="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                    <span>📅 Hasta: ${formatDate(item.end)}</span>
                    <span class="font-bold text-blue-600">Ver Ficha →</span>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>

          <div class="bg-slate-50/80 rounded-3xl p-5 border-2 border-blue-200 shadow-sm flex flex-col space-y-4">
            <div class="flex items-center justify-between pb-3 border-b border-blue-200">
              <div class="flex items-center space-x-2">
                <span class="w-3.5 h-3.5 rounded-full bg-blue-500"></span>
                <h4 class="font-extrabold text-sm text-slate-800 uppercase">Próximas Obras (Septiembre)</h4>
              </div>
              <span class="bg-blue-100 text-blue-800 text-xs font-black px-2.5 py-0.5 rounded-full">${upcomingWeeks.length}</span>
            </div>

            <div class="space-y-3.5">
              ${upcomingWeeks.map(item => `
                <div onclick="${item.module === 'mejoras' ? `openImprovementDetail('${item.id}')` : (item.module === 'remodelaciones' ? `openRenovationDetail('${item.id}')` : `openMaintenanceDetail('${item.id}')`)}" 
                     class="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm hover:shadow-md cursor-pointer card-hover transition-all">
                  <div class="flex items-center justify-between mb-2">
                    <span class="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md bg-${item.color}-100 text-${item.color}-800">
                      ${item.icon} ${item.type}
                    </span>
                    <span class="text-xs font-bold text-slate-500">${item.area.split(' ')[0]}</span>
                  </div>
                  <h5 class="text-sm font-bold text-slate-900 leading-snug">${item.title}</h5>

                  <div class="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                    <span>📅 Inicia: ${formatDate(item.start)}</span>
                    <span class="font-bold text-blue-600">Ver Ficha →</span>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>

          <div class="bg-slate-50/80 rounded-3xl p-5 border-2 border-slate-200 shadow-sm flex flex-col space-y-4">
            <div class="flex items-center justify-between pb-3 border-b border-slate-200">
              <div class="flex items-center space-x-2">
                <span class="text-base">✅</span>
                <h4 class="font-extrabold text-sm text-slate-800 uppercase">Completadas Recientes</h4>
              </div>
              <span class="bg-slate-200 text-slate-800 text-xs font-black px-2.5 py-0.5 rounded-full">${completedWorks.length}</span>
            </div>

            <div class="space-y-3.5">
              ${completedWorks.map(item => `
                <div onclick="${item.module === 'mejoras' ? `openImprovementDetail('${item.id}')` : (item.module === 'remodelaciones' ? `openRenovationDetail('${item.id}')` : `openMaintenanceDetail('${item.id}')`)}" 
                     class="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm hover:shadow-md cursor-pointer card-hover transition-all opacity-90">
                  <div class="flex items-center justify-between mb-2">
                    <span class="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800">
                      ✓ Finalizado (100%)
                    </span>
                    <span class="text-xs font-bold text-slate-500">${item.area.split(' ')[0]}</span>
                  </div>
                  <h5 class="text-sm font-bold text-slate-900 leading-snug">${item.title}</h5>

                  <div class="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                    <span>Finalizado: ${formatDate(item.end)}</span>
                    <span class="font-bold text-slate-600">Detalles →</span>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>

        </div>
      `}

    </div>
  `;
}
