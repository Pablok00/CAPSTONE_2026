// ==========================================================
// VISTA: DASHBOARD PRINCIPAL - HOTEL EL ALMENDRO
// ==========================================================

function renderDashboardView() {
  const activeMnt = state.maintenances.filter(m => m.status !== 'Completada' && m.status !== 'Cancelada').length;
  const pendingMnt = state.maintenances.filter(m => m.status === 'Pendiente').length;
  const overdueMnt = state.maintenances.filter(m => m.status === 'Atrasada').length;
  
  const activeImp = state.improvements.filter(i => i.status !== 'Completado').length;
  const totalBudgetImp = state.improvements.reduce((acc, cur) => acc + (cur.budget || 0), 0);

  const activeRen = state.renovations.filter(r => r.status !== 'Completado').length;
  const totalBudgetRen = state.renovations.reduce((acc, cur) => acc + (cur.budget || 0), 0);

  const upcomingMaintenances = state.maintenances
    .filter(m => m.status === 'Programada' || m.status === 'Pendiente')
    .slice(0, 3);

  const expiringWarranties = state.assets
    .map(a => ({ asset: a, wInfo: calculateWarrantyStatus(a.warranty) }))
    .filter(item => item.wInfo.status === 'Proxima' || item.wInfo.status === 'Vencida')
    .slice(0, 3);

  const overdueTasks = state.maintenances
    .filter(m => m.status === 'Atrasada')
    .slice(0, 3);

  const newRequests = state.requests
    .filter(r => r.status === 'Pendiente')
    .slice(0, 3);

  return `
    <div class="space-y-8 max-w-7xl mx-auto pb-10">
      
      <!-- BIENVENIDA LIMPIA -->
      <div class="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-4 border border-slate-800">
        <div class="flex items-center space-x-4">
          <div class="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-400 to-amber-200 text-slate-950 flex items-center justify-center text-3xl font-extrabold shadow-lg shadow-amber-400/20">
            🌳
          </div>
          <div>
            <h3 class="text-xl font-bold">Hotel & Centro de Eventos El Almendro</h3>
            <p class="text-slate-300 text-xs mt-0.5">Gestión visual simplificada • 9 Áreas • 12 Activos Fijos • 15 Mantenciones registradas</p>
          </div>
        </div>
        <div class="flex items-center space-x-3 w-full md:w-auto">
          <button onclick="navigateTo('gantt')" class="bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold px-4 py-3 rounded-xl text-xs flex items-center justify-center space-x-1.5 transition-colors border border-slate-700">
            <span>📈</span>
            <span>Ver Gantt Visual</span>
          </button>
        </div>
      </div>

      <!-- ============================================================ -->
      <!-- TRES GRANDES TARJETAS HERO (PILAR 1, 2 Y 3) -->
      <!-- ============================================================ -->
      <div>
        <div class="flex items-center justify-between mb-4">
          <div>
            <h3 class="text-base font-extrabold text-slate-900 tracking-tight uppercase">Módulos Principales</h3>
            <p class="text-xs text-slate-600 font-medium">Haz clic en cualquier cuadro para abrir sus actividades y detalles</p>
          </div>
          <span class="text-xs font-semibold text-slate-600 bg-slate-200/80 px-2.5 py-1 rounded-lg">Navegación Visual Directa</span>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          <!-- 1. MANTENCIÓN GENERAL -->
          <div onclick="navigateTo('mantenciones')" class="hero-card-hover cursor-pointer rounded-3xl p-6 bg-gradient-to-br from-blue-700 via-blue-800 to-indigo-900 text-white shadow-xl shadow-blue-900/20 border border-blue-600/30 relative overflow-hidden flex flex-col justify-between group">
            <div class="absolute -right-6 -bottom-6 text-9xl text-white/5 font-black select-none pointer-events-none">🔧</div>
            
            <div>
              <div class="flex items-center justify-between">
                <div class="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-3xl shadow-inner group-hover:scale-110 transition-transform">
                  🔧
                </div>
                <span class="bg-blue-400/20 text-blue-200 border border-blue-300/30 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                  Preventiva • Correctiva
                </span>
              </div>

              <h4 class="text-2xl font-black mt-5 tracking-tight group-hover:text-blue-200 transition-colors">MANTENCIÓN GENERAL</h4>
              <p class="text-blue-100/80 text-xs mt-1">Control de fallas, inspecciones periódicas y mantenciones esporádicas del hotel.</p>

              <div class="grid grid-cols-3 gap-2 mt-6 pt-5 border-t border-white/10">
                <div class="bg-white/10 rounded-xl p-2.5 text-center">
                  <p class="text-[11px] text-blue-200 font-medium">Activas</p>
                  <p class="text-xl font-extrabold text-white">${activeMnt}</p>
                </div>
                <div class="bg-white/10 rounded-xl p-2.5 text-center">
                  <p class="text-[11px] text-blue-200 font-medium">Pendientes</p>
                  <p class="text-xl font-extrabold text-amber-300">${pendingMnt}</p>
                </div>
                <div class="bg-white/10 rounded-xl p-2.5 text-center ${overdueMnt > 0 ? 'ring-2 ring-rose-400/60 bg-rose-900/40' : ''}">
                  <p class="text-[11px] text-rose-200 font-medium">Atrasadas</p>
                  <p class="text-xl font-extrabold text-rose-300">${overdueMnt}</p>
                </div>
              </div>
            </div>

            <div class="mt-6 flex items-center justify-between pt-4 border-t border-white/10">
              <div class="flex items-center space-x-2">
                <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                <span class="text-xs text-blue-100 font-medium">Próx: 31 Ago (Generador)</span>
              </div>
              <span class="text-xs font-bold text-white group-hover:translate-x-1 transition-transform flex items-center space-x-1">
                <span>Ver Cuadrícula</span>
                <span>→</span>
              </span>
            </div>
          </div>

          <!-- 2. MEJORAS / PROYECTOS -->
          <div onclick="navigateTo('mejoras')" class="hero-card-hover cursor-pointer rounded-3xl p-6 bg-gradient-to-br from-emerald-700 via-teal-800 to-emerald-950 text-white shadow-xl shadow-emerald-900/20 border border-emerald-600/30 relative overflow-hidden flex flex-col justify-between group">
            <div class="absolute -right-6 -bottom-6 text-9xl text-white/5 font-black select-none pointer-events-none">🌿</div>
            
            <div>
              <div class="flex items-center justify-between">
                <div class="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-3xl shadow-inner group-hover:scale-110 transition-transform">
                  🌿
                </div>
                <span class="bg-emerald-400/20 text-emerald-200 border border-emerald-300/30 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                  Obras Nuevas
                </span>
              </div>

              <h4 class="text-2xl font-black mt-5 tracking-tight group-hover:text-emerald-200 transition-colors">MEJORAS / PROYECTOS</h4>
              <p class="text-emerald-100/80 text-xs mt-1">Pérgolas, nueva zona de parrillas, iluminación de parque, riego y redes.</p>

              <div class="grid grid-cols-2 gap-2 mt-6 pt-5 border-t border-white/10">
                <div class="bg-white/10 rounded-xl p-2.5 text-center">
                  <p class="text-[11px] text-emerald-200 font-medium">Obras en Ejecución</p>
                  <p class="text-xl font-extrabold text-white">${activeImp}</p>
                </div>
                <div class="bg-white/10 rounded-xl p-2.5 text-center">
                  <p class="text-[11px] text-emerald-200 font-medium">Presupuesto Total</p>
                  <p class="text-base font-extrabold text-emerald-300">${formatCLP(totalBudgetImp)}</p>
                </div>
              </div>
            </div>

            <div class="mt-6 flex items-center justify-between pt-4 border-t border-white/10">
              <div class="flex items-center space-x-2">
                <span class="w-2 h-2 rounded-full bg-amber-400"></span>
                <span class="text-xs text-emerald-100 font-medium">Pérgola Comedor (45% avance)</span>
              </div>
              <span class="text-xs font-bold text-white group-hover:translate-x-1 transition-transform flex items-center space-x-1">
                <span>Ver Proyectos</span>
                <span>→</span>
              </span>
            </div>
          </div>

          <!-- 3. REMODELACIONES -->
          <div onclick="navigateTo('remodelaciones')" class="hero-card-hover cursor-pointer rounded-3xl p-6 bg-gradient-to-br from-purple-800 via-indigo-900 to-purple-950 text-white shadow-xl shadow-purple-900/20 border border-purple-600/30 relative overflow-hidden flex flex-col justify-between group">
            <div class="absolute -right-6 -bottom-6 text-9xl text-white/5 font-black select-none pointer-events-none">🏗️</div>
            
            <div>
              <div class="flex items-center justify-between">
                <div class="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-3xl shadow-inner group-hover:scale-110 transition-transform">
                  🏗️
                </div>
                <span class="bg-purple-400/20 text-purple-200 border border-purple-300/30 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                  Espacios & Materiales
                </span>
              </div>

              <h4 class="text-2xl font-black mt-5 tracking-tight group-hover:text-purple-200 transition-colors">REMODELACIONES</h4>
              <p class="text-purple-100/80 text-xs mt-1">Intervención en recintos con control de materiales y cómputo de costos.</p>

              <div class="grid grid-cols-2 gap-2 mt-6 pt-5 border-t border-white/10">
                <div class="bg-white/10 rounded-xl p-2.5 text-center">
                  <p class="text-[11px] text-purple-200 font-medium">En Remodelación</p>
                  <p class="text-xl font-extrabold text-white">${activeRen}</p>
                </div>
                <div class="bg-white/10 rounded-xl p-2.5 text-center">
                  <p class="text-[11px] text-purple-200 font-medium">Inversión Espacios</p>
                  <p class="text-base font-extrabold text-purple-300">${formatCLP(totalBudgetRen)}</p>
                </div>
              </div>
            </div>

            <div class="mt-6 flex items-center justify-between pt-4 border-t border-white/10">
              <div class="flex items-center space-x-2">
                <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
                <span class="text-xs text-purple-100 font-medium">Suite 104 (Piso & Baño)</span>
              </div>
              <span class="text-xs font-bold text-white group-hover:translate-x-1 transition-transform flex items-center space-x-1">
                <span>Ver Remodelaciones</span>
                <span>→</span>
              </span>
            </div>
          </div>

        </div>
      </div>

      <!-- RESÚMENES INFERIORES EN TARJETAS -->
      <div>
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-base font-extrabold text-slate-900 tracking-tight uppercase">Resúmenes Rápidos en Tarjetas</h3>
          <span class="text-xs text-slate-600 font-medium">Tarjetas directas sin listas saturadas</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          
          <!-- Mantenciones Próximas -->
          <div class="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-col justify-between">
            <div>
              <div class="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                <h5 class="text-xs font-extrabold text-blue-900 uppercase flex items-center space-x-1.5">
                  <span>📅</span>
                  <span>Mantenciones Próximas</span>
                </h5>
                <button onclick="navigateTo('fechas-proximas')" class="text-[11px] text-blue-600 font-bold hover:underline">Ver todas</button>
              </div>
              <div class="space-y-2.5">
                ${upcomingMaintenances.map(m => `
                  <div onclick="openMaintenanceDetail('${m.id}')" class="p-2.5 rounded-xl bg-slate-50 hover:bg-blue-50/50 border border-slate-200/80 cursor-pointer card-hover">
                    <div class="flex items-center justify-between text-[11px] mb-1">
                      <span class="font-bold text-blue-700 bg-blue-100 px-1.5 py-0.5 rounded">${formatDate(m.startDate)}</span>
                      <span class="text-slate-600 font-semibold">${m.areaName.split(' ')[0]}</span>
                    </div>
                    <p class="text-xs font-bold text-slate-800 leading-snug truncate">${m.title}</p>
                  </div>
                `).join('')}
              </div>
            </div>
            <button onclick="navigateTo('mantenciones')" class="w-full mt-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-colors text-center">
              Ir a Mantenciones →
            </button>
          </div>

          <!-- Garantías por Vencer -->
          <div class="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-col justify-between">
            <div>
              <div class="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                <h5 class="text-xs font-extrabold text-amber-900 uppercase flex items-center space-x-1.5">
                  <span>🛡️</span>
                  <span>Garantías por Vencer</span>
                </h5>
                <button onclick="navigateTo('activos')" class="text-[11px] text-amber-600 font-bold hover:underline">Ver activos</button>
              </div>
              <div class="space-y-2.5">
                ${expiringWarranties.map(item => `
                  <div onclick="openAssetDetail('${item.asset.id}')" class="p-2.5 rounded-xl bg-amber-50/60 border border-amber-200/80 cursor-pointer card-hover">
                    <div class="flex items-center justify-between text-[11px] mb-1">
                      <span class="font-bold text-amber-800 bg-amber-200/80 px-1.5 py-0.5 rounded">${item.wInfo.badge}</span>
                      <span class="text-slate-600 font-semibold">${item.asset.brand}</span>
                    </div>
                    <p class="text-xs font-bold text-slate-800 leading-snug truncate">${item.asset.name}</p>
                  </div>
                `).join('')}
              </div>
            </div>
            <button onclick="navigateTo('activos')" class="w-full mt-4 py-2 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded-xl text-xs font-bold transition-colors text-center">
              Control de Garantías →
            </button>
          </div>

          <!-- Trabajos Atrasados -->
          <div class="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-col justify-between">
            <div>
              <div class="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                <h5 class="text-xs font-extrabold text-rose-900 uppercase flex items-center space-x-1.5">
                  <span>⚠️</span>
                  <span>Trabajos Atrasados</span>
                </h5>
                <span class="bg-rose-100 text-rose-700 text-[10px] font-extrabold px-2 py-0.5 rounded-full">${overdueTasks.length} urgentes</span>
              </div>
              <div class="space-y-2.5">
                ${overdueTasks.map(m => `
                  <div onclick="openMaintenanceDetail('${m.id}')" class="p-2.5 rounded-xl bg-rose-50/70 border border-rose-200 cursor-pointer card-hover">
                    <div class="flex items-center justify-between text-[11px] mb-1">
                      <span class="font-bold text-rose-700 bg-rose-200/80 px-1.5 py-0.5 rounded">Atrasada</span>
                      <span class="text-slate-600 font-medium">${m.areaName.split(' ')[0]}</span>
                    </div>
                    <p class="text-xs font-bold text-slate-800 leading-snug truncate">${m.title}</p>
                  </div>
                `).join('')}
              </div>
            </div>
            <button onclick="navigateTo('mantenciones')" class="w-full mt-4 py-2 bg-rose-100 hover:bg-rose-200 text-rose-900 rounded-xl text-xs font-bold transition-colors text-center">
              Resolver Atrasadas →
            </button>
          </div>

          <!-- Solicitudes Nuevas -->
          <div class="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-col justify-between">
            <div>
              <div class="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                <h5 class="text-xs font-extrabold text-indigo-900 uppercase flex items-center space-x-1.5">
                  <span>📩</span>
                  <span>Solicitudes Nuevas</span>
                </h5>
                <button onclick="navigateTo('solicitudes')" class="text-[11px] text-indigo-600 font-bold hover:underline">Ver todas</button>
              </div>
              <div class="space-y-2.5">
                ${newRequests.map(r => `
                  <div onclick="openConvertRequestModal('${r.id}')" class="p-2.5 rounded-xl bg-indigo-50/60 border border-indigo-200/80 cursor-pointer card-hover">
                    <div class="flex items-center justify-between text-[11px] mb-1">
                      <span class="font-bold text-indigo-700 bg-indigo-200/80 px-1.5 py-0.5 rounded">Pendiente</span>
                      <span class="text-slate-600 font-medium">${r.areaName.split(' ')[0]}</span>
                    </div>
                    <p class="text-xs font-bold text-slate-800 leading-snug truncate">${r.title}</p>
                  </div>
                `).join('')}
              </div>
            </div>
            <button onclick="navigateTo('solicitudes')" class="w-full mt-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md transition-all text-center">
              Ir a Solicitudes →
            </button>
          </div>

        </div>
      </div>

    </div>
  `;
}
