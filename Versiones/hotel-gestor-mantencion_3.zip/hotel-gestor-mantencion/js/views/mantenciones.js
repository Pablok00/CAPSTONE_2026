// ==========================================================
// VISTA: MANTENCIONES - HOTEL EL ALMENDRO
// ==========================================================

function renderMaintenancesView() {
  let filtered = state.maintenances.filter(m => {
    if (maintenanceCategoryFilter !== 'TODAS' && m.type !== maintenanceCategoryFilter) return false;
    if (maintenanceAreaFilter !== 'TODAS' && m.areaId !== maintenanceAreaFilter) return false;
    if (maintenanceStatusFilter !== 'TODAS' && m.status !== maintenanceStatusFilter) return false;
    if (activeAreaFilter && m.areaId !== activeAreaFilter) return false;
    return true;
  });

  const countPrev = state.maintenances.filter(m => m.type === 'Preventiva').length;
  const countCorr = state.maintenances.filter(m => m.type === 'Correctiva').length;
  const countEsp = state.maintenances.filter(m => m.type === 'Esporádica').length;

  return `
    <div class="space-y-6 max-w-7xl mx-auto pb-10">
      
      <div class="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <button onclick="setMaintenanceCategory('TODAS')" class="p-4 rounded-2xl text-left border-2 transition-all card-hover ${maintenanceCategoryFilter === 'TODAS' ? 'border-blue-600 bg-blue-50/70 shadow-md ring-2 ring-blue-500/20' : 'border-slate-200 bg-white hover:border-slate-300'}">
          <div class="flex items-center justify-between">
            <span class="text-2xl">📋</span>
            <span class="text-xs font-extrabold px-2.5 py-0.5 rounded-full ${maintenanceCategoryFilter === 'TODAS' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-700'}">${state.maintenances.length}</span>
          </div>
          <p class="font-bold text-slate-800 text-sm mt-2">Todas las Mantenciones</p>
          <p class="text-[11px] text-slate-600">Vista general unificada</p>
        </button>

        <button onclick="setMaintenanceCategory('Preventiva')" class="p-4 rounded-2xl text-left border-2 transition-all card-hover ${maintenanceCategoryFilter === 'Preventiva' ? 'border-blue-600 bg-blue-50/70 shadow-md ring-2 ring-blue-500/20' : 'border-slate-200 bg-white hover:border-slate-300'}">
          <div class="flex items-center justify-between">
            <span class="text-2xl">🛡️</span>
            <span class="text-xs font-extrabold px-2.5 py-0.5 rounded-full ${maintenanceCategoryFilter === 'Preventiva' ? 'bg-blue-600 text-white' : 'bg-blue-100 text-blue-800'}">${countPrev}</span>
          </div>
          <p class="font-bold text-slate-800 text-sm mt-2">Mantención Preventiva</p>
          <p class="text-[11px] text-slate-600">Periódicas y planificadas</p>
        </button>

        <button onclick="setMaintenanceCategory('Correctiva')" class="p-4 rounded-2xl text-left border-2 transition-all card-hover ${maintenanceCategoryFilter === 'Correctiva' ? 'border-amber-600 bg-amber-50/70 shadow-md ring-2 ring-amber-500/20' : 'border-slate-200 bg-white hover:border-slate-300'}">
          <div class="flex items-center justify-between">
            <span class="text-2xl">⚠️</span>
            <span class="text-xs font-extrabold px-2.5 py-0.5 rounded-full ${maintenanceCategoryFilter === 'Correctiva' ? 'bg-amber-600 text-white' : 'bg-amber-100 text-amber-800'}">${countCorr}</span>
          </div>
          <p class="font-bold text-slate-800 text-sm mt-2">Mantención Correctiva</p>
          <p class="text-[11px] text-slate-600">Reparaciones por falla</p>
        </button>

        <button onclick="setMaintenanceCategory('Esporádica')" class="p-4 rounded-2xl text-left border-2 transition-all card-hover ${maintenanceCategoryFilter === 'Esporádica' ? 'border-purple-600 bg-purple-50/70 shadow-md ring-2 ring-purple-500/20' : 'border-slate-200 bg-white hover:border-slate-300'}">
          <div class="flex items-center justify-between">
            <span class="text-2xl">⚡</span>
            <span class="text-xs font-extrabold px-2.5 py-0.5 rounded-full ${maintenanceCategoryFilter === 'Esporádica' ? 'bg-purple-600 text-white' : 'bg-purple-100 text-purple-800'}">${countEsp}</span>
          </div>
          <p class="font-bold text-slate-800 text-sm mt-2">Mantención Esporádica</p>
          <p class="text-[11px] text-slate-600">Imprevistos en operación</p>
        </button>
      </div>

      <!-- BARRA DE FILTROS -->
      <div class="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-3">
        <div class="flex flex-wrap items-center gap-3">
          <div class="flex items-center space-x-2">
            <label class="text-xs font-bold text-slate-600 uppercase">Área:</label>
            <select onchange="maintenanceAreaFilter = this.value; renderCurrentView();" class="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-700">
              <option value="TODAS">Todas las áreas</option>
              ${state.areas.map(a => `<option value="${a.id}" ${maintenanceAreaFilter === a.id || activeAreaFilter === a.id ? 'selected' : ''}>${a.name}</option>`).join('')}
            </select>
          </div>

          <div class="flex items-center space-x-2">
            <label class="text-xs font-bold text-slate-600 uppercase">Estado:</label>
            <select onchange="maintenanceStatusFilter = this.value; renderCurrentView();" class="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-700">
              <option value="TODAS" ${maintenanceStatusFilter === 'TODAS' ? 'selected' : ''}>Todos los estados</option>
              <option value="Pendiente" ${maintenanceStatusFilter === 'Pendiente' ? 'selected' : ''}>Pendiente</option>
              <option value="Programada" ${maintenanceStatusFilter === 'Programada' ? 'selected' : ''}>Programada</option>
              <option value="En proceso" ${maintenanceStatusFilter === 'En proceso' ? 'selected' : ''}>En proceso</option>
              <option value="Completada" ${maintenanceStatusFilter === 'Completada' ? 'selected' : ''}>Completada</option>
              <option value="Atrasada" ${maintenanceStatusFilter === 'Atrasada' ? 'selected' : ''}>Atrasada</option>
            </select>
          </div>

          ${activeAreaFilter ? `
            <button onclick="activeAreaFilter = null; renderCurrentView();" class="bg-blue-100 text-blue-700 text-xs font-bold px-3 py-1 rounded-xl flex items-center space-x-1">
              <span>Filtro de área activo</span>
              <span>✕</span>
            </button>
          ` : ''}
        </div>

        <div class="text-xs font-bold text-slate-600">
          Mostrando <span class="text-blue-600 font-extrabold">${filtered.length}</span> tarjetas de mantención
        </div>
      </div>

      <!-- CUADRÍCULA DE TARJETAS DE MANTENCIÓN -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        ${filtered.length === 0 ? `
          <div class="col-span-full bg-white rounded-3xl p-12 text-center border border-slate-200">
            <span class="text-4xl block mb-2">🔍</span>
            <p class="text-base font-bold text-slate-700">No hay mantenciones con los filtros seleccionados</p>
            <button onclick="maintenanceCategoryFilter='TODAS'; maintenanceAreaFilter='TODAS'; maintenanceStatusFilter='TODAS'; activeAreaFilter=null; renderCurrentView();" class="mt-3 text-xs font-bold text-blue-600 hover:underline">
              Restablecer todos los filtros
            </button>
          </div>
        ` : filtered.map(m => {
          const statusBadges = {
            'Pendiente': 'bg-amber-100 text-amber-800 border-amber-200',
            'Programada': 'bg-blue-100 text-blue-800 border-blue-200',
            'En proceso': 'bg-indigo-100 text-indigo-800 border-indigo-200 animate-pulse',
            'Completada': 'bg-emerald-100 text-emerald-800 border-emerald-200',
            'Atrasada': 'bg-rose-100 text-rose-800 border-rose-200 font-black',
            'Cancelada': 'bg-slate-100 text-slate-800 border-slate-200'
          };

          const typeColors = {
            'Preventiva': 'text-blue-700 bg-blue-50 border-blue-200',
            'Correctiva': 'text-amber-700 bg-amber-50 border-amber-200',
            'Esporádica': 'text-purple-700 bg-purple-50 border-purple-200'
          };

          const priorityColors = {
            'Baja': 'text-slate-600 bg-slate-100',
            'Media': 'text-blue-700 bg-blue-100',
            'Alta': 'text-amber-800 bg-amber-100 font-bold',
            'Crítica': 'text-rose-800 bg-rose-100 font-black'
          };

          return `
            <div onclick="openMaintenanceDetail('${m.id}')" class="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm hover:shadow-lg transition-all cursor-pointer flex flex-col justify-between card-hover group ${m.status === 'Atrasada' ? 'ring-2 ring-rose-400/50' : ''}">
              
              <div>
                <div class="flex items-center justify-between mb-3">
                  <span class="text-[11px] font-extrabold uppercase px-2.5 py-1 rounded-lg border ${typeColors[m.type]}">
                    ${m.type}
                  </span>
                  <span class="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${priorityColors[m.priority]}">
                    Prioridad: ${m.priority}
                  </span>
                </div>

                <h4 class="text-base font-bold text-slate-800 leading-snug group-hover:text-blue-600 transition-colors">
                  ${m.title}
                </h4>

                <div class="mt-3 flex flex-wrap items-center gap-1.5 text-xs">
                  <span class="bg-slate-100 text-slate-700 font-medium px-2 py-0.5 rounded-md flex items-center space-x-1">
                    <span>📍</span>
                    <span>${m.areaName}</span>
                  </span>
                  ${m.assetName ? `
                    <span class="bg-blue-50 text-blue-800 font-semibold px-2 py-0.5 rounded-md truncate max-w-[200px] flex items-center space-x-1">
                      <span>🏷️</span>
                      <span class="truncate">${m.assetName}</span>
                    </span>
                  ` : ''}
                </div>

                <p class="text-xs text-slate-600 mt-2.5 line-clamp-2 leading-relaxed">
                  ${m.description}
                </p>
              </div>

              <div class="mt-5 pt-4 border-t border-slate-100">
                <div class="grid grid-cols-2 gap-2 text-xs mb-3">
                  <div>
                    <p class="text-[10px] text-slate-600 font-medium uppercase">Fecha Límite</p>
                    <p class="font-bold ${m.status === 'Atrasada' ? 'text-rose-600' : 'text-slate-800'}">
                      ${formatDate(m.limitDate)}
                    </p>
                  </div>
                  <div class="text-right">
                    <p class="text-[10px] text-slate-600 font-medium uppercase">Costo Estimado</p>
                    <p class="font-bold text-slate-800">${formatCLP(m.estimatedCost)}</p>
                  </div>
                </div>

                <div class="flex items-center justify-between pt-2 border-t border-slate-50">
                  <div class="flex items-center space-x-2">
                    <div class="w-6 h-6 rounded-full bg-slate-200 text-xs flex items-center justify-center font-bold">
                      👷
                    </div>
                    <span class="text-xs text-slate-700 font-medium truncate max-w-[120px]">${m.responsible.split(' ')[0]}</span>
                  </div>

                  <span class="text-xs font-bold px-2.5 py-1 rounded-full border ${statusBadges[m.status]}">
                    ${m.status}
                  </span>
                </div>
              </div>

            </div>
          `;
        }).join('')}
      </div>

    </div>
  `;
}

function setMaintenanceCategory(category) {
  maintenanceCategoryFilter = category;
  renderCurrentView();
}
