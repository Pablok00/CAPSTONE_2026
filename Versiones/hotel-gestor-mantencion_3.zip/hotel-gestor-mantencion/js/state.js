// ==========================================================
// GESTOR DE ESTADO GLOBAL (STATE STORE) - HOTEL EL ALMENDRO
// ==========================================================

function loadInitialState() {
  const savedData = localStorage.getItem('EL_ALMENDRO_HOTEL_DATA');
  if (savedData) {
    try {
      return JSON.parse(savedData);
    } catch (e) {
      console.error("Error al cargar localStorage, usando datos iniciales", e);
    }
  }
  return window.INITIAL_HOTEL_DATA || {};
}

// Variables de estado global
let state = loadInitialState();
let currentView = 'dashboard';
let activeAreaFilter = null;
let activeConvertingRequestId = null;
let selectedAssetTab = 'ficha';
let ganttViewMode = 'timeline'; // 'timeline' (diagrama) o 'horizontes' (fases)
let ganttCategoryFilter = 'TODAS';
let maintenanceCategoryFilter = 'TODAS';
let maintenanceAreaFilter = 'TODAS';
let maintenanceStatusFilter = 'TODAS';
let assetCategoryFilter = 'TODAS';
let assetWarrantyFilter = 'TODAS';
let upcomingDateAreaFilter = 'TODAS';
let upcomingDateTypeFilter = 'TODAS';

// Persistencia en localStorage
function saveState() {
  localStorage.setItem('EL_ALMENDRO_HOTEL_DATA', JSON.stringify(state));
  if (typeof updateSidebarBadges === 'function') updateSidebarBadges();
  if (typeof renderCurrentView === 'function') renderCurrentView();
}

function resetToFactoryData() {
  if (confirm("¿Estás seguro de que deseas restablecer todos los datos del prototipo a su estado original?")) {
    localStorage.removeItem('EL_ALMENDRO_HOTEL_DATA');
    state = JSON.parse(JSON.stringify(window.INITIAL_HOTEL_DATA));
    saveState();
    alert("Datos restablecidos con éxito para Hotel El Almendro.");
  }
}

// Funciones de formato y utilidades
function formatCLP(amount) {
  return '$ ' + Number(amount || 0).toLocaleString('es-CL');
}

function formatDate(dateStr) {
  if (!dateStr) return 'No definida';
  const parts = dateStr.split('-');
  if (parts.length === 3) {
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
  }
  return dateStr;
}

function calculateWarrantyStatus(warranty) {
  if (!warranty || !warranty.endDate) {
    return { status: 'Sin Garantía', color: 'slate', badge: 'Sin Garantía', daysLeft: 0, text: 'No registra garantía' };
  }
  const today = new Date('2026-08-28');
  const endDate = new Date(warranty.endDate);
  const diffTime = endDate.getTime() - today.getTime();
  const daysLeft = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (daysLeft < 0) {
    return {
      status: 'Vencida',
      color: 'rose',
      badge: 'Garantía Vencida',
      daysLeft: daysLeft,
      text: `Venció el ${formatDate(warranty.endDate)}`
    };
  } else if (daysLeft <= 60) {
    return {
      status: 'Proxima',
      color: 'amber',
      badge: `Por vencer (${daysLeft} días)`,
      daysLeft: daysLeft,
      text: `Vence el ${formatDate(warranty.endDate)} (Quedan ${daysLeft} días)`
    };
  } else {
    return {
      status: 'Vigente',
      color: 'emerald',
      badge: 'En Garantía',
      daysLeft: daysLeft,
      text: `Vigente hasta ${formatDate(warranty.endDate)}`
    };
  }
}
