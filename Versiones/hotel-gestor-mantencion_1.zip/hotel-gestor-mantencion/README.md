# Prototipo Funcional: Gestor de Mantenciones, Obras y Activos Fijos
**Hotel & Centro de Eventos El Almendro**

Prototipo web visual e interactivo diseñado para reemplazar el formato de listas densas y tablas saturadas (estilo ClickUp) por una experiencia 100% basada en **tarjetas grandes**, navegación directa (máximo 2-3 clics) y claridad operativa para personal del hotel.

---

## 🚀 Cómo Ejecutar el Prototipo

1. Abre directamente el archivo [**`index.html`**](file:///C:/Users/B.Salinas/.gemini/antigravity/scratch/hotel-gestor-mantencion/index.html) en cualquier navegador web.
2. Ruta local: `C:\Users\B.Salinas\.gemini\antigravity\scratch\hotel-gestor-mantencion\index.html`

---

## 🧭 Recorridos Principales

### 1. Carta Gantt & Línea de Tiempo 100% Visual (Cero Listas)
- Ingresa a **📈 Línea de Tiempo / Gantt**.
- Disfruta de una experiencia 100% gráfica:
  - **Diagrama Visual Gantt**: Columnas de tiempo por semanas (`Ago Sem 3`, `Ago Sem 4`, `Sep Inicial`, `Sep Medio`, `Sep Cierre`, `Octubre`) con **barras flotantes de colores** según categoría (🌿 Mejoras en verde, 🏗️ Remodelaciones en púrpura, 🔧 Mantenciones en azul) que muestran ícono, responsable, fechas y medidor de avance integrado.
  - **Tablero Visual por Horizontes / Fases**: Selector superior para alternar a 3 columnas de tarjetas grandes (*En Ejecución Esta Semana*, *Próximas Obras*, *Completadas Recientes*).
  - Al hacer clic en cualquier barra o tarjeta se abre su ficha detallada.

### 2. Dashboard con los Tres Grandes Pilares
- 🔧 **MANTENCIÓN GENERAL**: Preventiva, Correctiva y Esporádica con contadores y acceso a cuadrícula.
- 🌿 **MEJORAS / PROYECTOS**: Pérgolas, Quincho, Riego Tecnificado, Redes y control presupuestario.
- 🏗️ **REMODELACIONES**: Intervención de espacios con Calculadora de Materiales en vivo.

### 3. Activos Fijos & Garantías Automatizadas
- Cálculo de estado con alertas automáticas (🟢 En Garantía, 🟡 Por Vencer, 🔴 Vencida).
- Pauta preventiva periódica e historial cronológico perpetuo.

### 4. Solicitudes & Conversión con 1 Clic
- Botón permanente **+ NUEVA SOLICITUD** y conversión ágil en la bandeja de solicitudes.
