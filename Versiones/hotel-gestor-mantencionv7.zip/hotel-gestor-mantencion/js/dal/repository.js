// ==========================================================
// CAPA 3: ACCESO A DATOS (DAL - DATA ACCESS LAYER)
// ARCHIVO: repository.js - PATRÓN REPOSITORIO (DATA REPOSITORIES)
// ==========================================================
// El patrón Repository actúa como intermediario entre la capa de
// dominio/negocio y la capa de acceso a datos, proveyendo una
// colección de objetos en memoria y abstrayendo las consultas.
//
// Cada repositorio expone operaciones asíncronas/síncronas estándar:
// getAll(), getById(), create(), update(), delete(), etc.
// ==========================================================

/**
 * Repositorio para la entidad Mantención (Preventiva, Correctiva, Esporádica).
 */
const MaintenanceRepository = {
  getAll() {
    /* 
     * [FUTURO SUPABASE FASE 2]:
     * const { data, error } = await supabase.from('maintenances').select('*, materials(*)').order('limitDate');
     * if (error) throw error;
     * return data;
     */
    return state.maintenances || [];
  },

  getById(id) {
    /* 
     * [FUTURO SUPABASE FASE 2]:
     * const { data, error } = await supabase.from('maintenances').select('*, materials(*)').eq('id', id).single();
     * return data;
     */
    return (state.maintenances || []).find(m => m.id === id);
  },

  create(maintenance) {
    /* 
     * [FUTURO SUPABASE FASE 2]:
     * const { data, error } = await supabase.from('maintenances').insert([maintenance]).select().single();
     * return data;
     */
    state.maintenances.unshift(maintenance);
    saveState();
    return maintenance;
  },

  update(id, updates) {
    /* 
     * [FUTURO SUPABASE FASE 2]:
     * const { data, error } = await supabase.from('maintenances').update(updates).eq('id', id).select().single();
     * return data;
     */
    const index = state.maintenances.findIndex(m => m.id === id);
    if (index !== -1) {
      state.maintenances[index] = { ...state.maintenances[index], ...updates };
      saveState();
      return state.maintenances[index];
    }
    return null;
  },

  updateStatus(id, newStatus) {
    const mnt = this.getById(id);
    if (mnt) {
      mnt.status = newStatus;
      if (newStatus === 'Completada') {
        mnt.completedDate = '2026-08-28';
      }
      saveState();
      return mnt;
    }
    return null;
  }
};

/**
 * Repositorio para la entidad Activos Fijos (Maquinarias, Calderas, Equipos).
 */
const AssetRepository = {
  getAll() {
    /* 
     * [FUTURO SUPABASE FASE 2]:
     * const { data } = await supabase.from('assets').select('*');
     * return data;
     */
    return state.assets || [];
  },

  getById(id) {
    /* 
     * [FUTURO SUPABASE FASE 2]:
     * const { data } = await supabase.from('assets').select('*, history(*)').eq('id', id).single();
     * return data;
     */
    return (state.assets || []).find(a => a.id === id);
  }
};

/**
 * Repositorio para la entidad Áreas Operativas de Trabajo.
 */
const WorkAreaRepository = {
  getAll() {
    /* 
     * [FUTURO SUPABASE FASE 2]:
     * const { data } = await supabase.from('work_areas').select('*').order('id');
     * return data;
     */
    return state.workAreas || DEFAULT_WORK_AREAS;
  },

  getById(id) {
    return this.getAll().find(wa => wa.id === id);
  }
};

/**
 * Repositorio para la entidad Solicitudes de Incidentes (Mucamas / Recepción).
 */
const RequestRepository = {
  getAll() {
    /* 
     * [FUTURO SUPABASE FASE 2]:
     * const { data } = await supabase.from('requests').select('*').order('createdDate', { ascending: false });
     * return data;
     */
    return state.requests || [];
  },

  getById(id) {
    return (state.requests || []).find(r => r.id === id);
  },

  create(newRequest) {
    /* 
     * [FUTURO SUPABASE FASE 2]:
     * const { data } = await supabase.from('requests').insert([newRequest]).select().single();
     * return data;
     */
    state.requests.unshift(newRequest);
    saveState();
    return newRequest;
  }
};

/**
 * Repositorio para Proyectos de Mejora y Obras Nuevas.
 */
const ImprovementRepository = {
  getAll() {
    /* 
     * [FUTURO SUPABASE FASE 2]:
     * const { data } = await supabase.from('improvements').select('*, materials(*)');
     * return data;
     */
    return state.improvements || [];
  },

  getById(id) {
    return (state.improvements || []).find(i => i.id === id);
  },

  create(newImp) {
    state.improvements.unshift(newImp);
    saveState();
    return newImp;
  }
};

/**
 * Repositorio para Remodelaciones de Espacios.
 */
const RenovationRepository = {
  getAll() {
    /* 
     * [FUTURO SUPABASE FASE 2]:
     * const { data } = await supabase.from('renovations').select('*, materials(*)');
     * return data;
     */
    return state.renovations || [];
  },

  getById(id) {
    return (state.renovations || []).find(r => r.id === id);
  },

  create(newRen) {
    state.renovations.unshift(newRen);
    saveState();
    return newRen;
  }
};

/**
 * Repositorio para Notificaciones y Alertas del Sistema.
 */
const NotificationRepository = {
  getAll() {
    /* 
     * [FUTURO SUPABASE FASE 2]:
     * const { data } = await supabase.from('notifications').select('*').order('timestamp', { ascending: false });
     * return data;
     */
    return state.notifications || [];
  },

  add(notif) {
    state.notifications.unshift(notif);
    saveState();
    return notif;
  },

  markAllAsRead() {
    /* 
     * [FUTURO SUPABASE FASE 2]:
     * await supabase.from('notifications').update({ read: true }).eq('read', false);
     */
    state.notifications.forEach(n => n.read = true);
    saveState();
  }
};

// Exportar globalmente los repositorios
window.MaintenanceRepository = MaintenanceRepository;
window.AssetRepository = AssetRepository;
window.WorkAreaRepository = WorkAreaRepository;
window.RequestRepository = RequestRepository;
window.ImprovementRepository = ImprovementRepository;
window.RenovationRepository = RenovationRepository;
window.NotificationRepository = NotificationRepository;
