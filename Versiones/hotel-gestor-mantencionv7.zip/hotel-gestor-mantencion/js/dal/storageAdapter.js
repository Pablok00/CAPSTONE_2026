// ==========================================================
// CAPA 3: ACCESO A DATOS (DAL - DATA ACCESS LAYER)
// ARCHIVO: storageAdapter.js - ADAPTADOR DE PERSISTENCIA
// ==========================================================
// Este adaptador implementa el patrón Adapter para desacoplar
// la fuente física de almacenamiento del resto de la aplicación.
//
// ESTADO ACTUAL (FASE 1 - CAPSTONE):
// Persistencia en cliente mediante Web Storage API (localStorage)
// y carga de datos semilla desde mockData.js.
//
// PROYECCIÓN FUTURA (FASE 2 Y 3 - CAPSTONE):
// Conexión directa a PostgreSQL en la nube a través del SDK de Supabase.
// ==========================================================

const STORAGE_KEY = 'EL_ALMENDRO_HOTEL_DATA';

// ==========================================================
// CONFIGURACIÓN Y CONTRATOS PARA SUPABASE (FASE 2)
// ==========================================================
const SUPABASE_CONFIG = {
  // En Fase 2, se reemplazarán por las credenciales del proyecto Supabase:
  URL: 'https://xyzcompany.supabase.co', // URL del proyecto Supabase
  ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...', // Public Anonymous API Key
  BUCKET_PHOTOS: 'hotel-maintenance-photos', // Bucket para subida de fotos en terreno
  IS_ENABLED: false // Flag para alternar entre LocalStorage (false) y Supabase (true)
};

/**
 * Adaptador de almacenamiento que abstrae las operaciones CRUD
 * para que las capas superiores (Servicios y Vistas) no dependan
 * de la tecnología de almacenamiento subyacente.
 */
const StorageAdapter = {
  /**
   * Carga el estado completo de la aplicación.
   * En Fase 1 lee de localStorage o datos semilla.
   * En Fase 2 ejecutará las consultas SELECT a Supabase.
   */
  loadData() {
    if (SUPABASE_CONFIG.IS_ENABLED) {
      /* 
       * ==========================================================
       * IMPLEMENTACIÓN FUTURA SUPABASE (FASE 2):
       * ==========================================================
       * const { data: users } = await supabase.from('users').select('*');
       * const { data: maintenances } = await supabase.from('maintenances').select('*, materials(*)');
       * const { data: assets } = await supabase.from('assets').select('*');
       * const { data: areas } = await supabase.from('work_areas').select('*');
       * const { data: requests } = await supabase.from('requests').select('*');
       * const { data: notifications } = await supabase.from('notifications').select('*');
       * return { users, maintenances, assets, areas, requests, notifications };
       */
      console.log("[DAL/StorageAdapter] Supabase proyectado para Fase 2.");
    }

    // Fase 1: LocalStorage con respaldo en datos iniciales
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        return JSON.parse(raw);
      }
    } catch (err) {
      console.warn("[DAL/StorageAdapter] Error al leer localStorage, cargando datos semilla.", err);
    }

    return window.INITIAL_HOTEL_DATA ? JSON.parse(JSON.stringify(window.INITIAL_HOTEL_DATA)) : null;
  },

  /**
   * Guarda el estado completo de la aplicación.
   * @param {Object} stateData - Objeto de estado completo
   */
  saveData(stateData) {
    if (SUPABASE_CONFIG.IS_ENABLED) {
      /*
       * ==========================================================
       * IMPLEMENTACIÓN FUTURA SUPABASE (FASE 2):
       * ==========================================================
       * Cada cambio se sincronizará individualmente mediante mutations:
       * await supabase.from('table_name').upsert(record);
       */
    }

    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(stateData));
      return true;
    } catch (err) {
      console.error("[DAL/StorageAdapter] Error al escribir en localStorage:", err);
      return false;
    }
  },

  /**
   * Restablece los datos a su estado de fábrica (seed).
   */
  resetData() {
    try {
      localStorage.removeItem(STORAGE_KEY);
      return window.INITIAL_HOTEL_DATA ? JSON.parse(JSON.stringify(window.INITIAL_HOTEL_DATA)) : null;
    } catch (err) {
      console.error("[DAL/StorageAdapter] Error al restablecer datos:", err);
      return null;
    }
  },

  // ==========================================================
  // CONTRATOS DE SERVICIOS REMOTOS SUPABASE (STUBS PARA FASE 2)
  // ==========================================================

  /**
   * [FUTURO FASE 2] Subida de imágenes a Supabase Storage Bucket.
   * Permitirá a los técnicos subir fotografías de averías directamente
   * desde la cámara de sus teléfonos inteligentes a la nube de Supabase.
   * 
   * @param {File} fileBlob - Archivo capturado desde el dispositivo móvil
   * @param {string} destinationPath - Ruta dentro del bucket (ej: "mantenciones/mnt_123_antes.jpg")
   * @returns {Promise<string>} URL pública de la imagen alojada en la CDN
   */
  async uploadPhotoToCloud(fileBlob, destinationPath) {
    /* 
     * const { data, error } = await supabase.storage
     *   .from(SUPABASE_CONFIG.BUCKET_PHOTOS)
     *   .upload(destinationPath, fileBlob, { upsert: true });
     * if (error) throw error;
     * const { publicUrl } = supabase.storage.from(SUPABASE_CONFIG.BUCKET_PHOTOS).getPublicUrl(destinationPath);
     * return publicUrl;
     */
    console.info(`[DAL/StorageAdapter: Futuro Supabase] uploadPhotoToCloud('${destinationPath}') preparado para Fase 2.`);
    return null;
  },

  /**
   * [FUTURO FASE 2] Suscripción en Tiempo Real (Supabase Realtime Channels).
   * Permitirá que cuando una recepcionista ingrese una solicitud,
   * el teléfono del técnico reciba una notificación push instantánea mediante WebSockets.
   * 
   * @param {string} table - Nombre de la tabla a escuchar (ej: "requests", "maintenances")
   * @param {Function} callback - Función a ejecutar al recibir evento INSERT/UPDATE
   */
  subscribeToRealtimeChanges(table, callback) {
    /*
     * const channel = supabase.channel(`public:${table}`)
     *   .on('postgres_changes', { event: '*', schema: 'public', table }, payload => {
     *     callback(payload);
     *   })
     *   .subscribe();
     * return channel;
     */
    console.info(`[DAL/StorageAdapter: Futuro Supabase] Suscripción Realtime a tabla '${table}' preparada para Fase 2.`);
  }
};

window.StorageAdapter = StorageAdapter;
