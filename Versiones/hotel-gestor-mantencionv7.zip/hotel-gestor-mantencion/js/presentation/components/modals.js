// ==========================================================
// MODALES Y ACCIONES INTERACTIVAS - HOTEL EL ALMENDRO
// ==========================================================

function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (!modal) return;
  modal.classList.remove('hidden');

  // Reset scroll al inicio en el contenedor del modal
  modal.scrollTop = 0;

  // Reset scroll en todos los contenedores internos con scroll
  const scrollables = modal.querySelectorAll('.overflow-y-auto, [id$="-modal-content"], form');
  scrollables.forEach(el => {
    el.scrollTop = 0;
  });

  // Asegurar scroll al tope tras renderizado en el siguiente cuadro de animación
  requestAnimationFrame(() => {
    modal.scrollTop = 0;
    scrollables.forEach(el => {
      el.scrollTop = 0;
    });
  });
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (!modal) return;
  modal.classList.add('hidden');

  // Dejar reseteado el scroll a 0 para la próxima apertura
  modal.scrollTop = 0;
  const scrollables = modal.querySelectorAll('.overflow-y-auto, [id$="-modal-content"], form');
  scrollables.forEach(el => {
    el.scrollTop = 0;
  });

  // Limpiar cualquier referencia residual de navegación para cerrar completamente
  openedFromAreaDetail = null;
}

function handleModalBackdropClick(event, modalId) {
  if (!event) return;
  // Si el usuario hace clic fuera de la tarjeta (directamente en el fondo oscuro/espacios en blanco)
  if (event.target && event.target.id === modalId) {
    closeModal(modalId);
  }
}

function populateSelectAreas() {
  const select = document.getElementById('req-area');
  if (select) {
    select.innerHTML = state.areas.map(a => `<option value="${a.id}">${a.icon} ${a.name}</option>`).join('');
  }
  const reqRequester = document.getElementById('req-requester');
  if (reqRequester && state.currentUser) {
    reqRequester.value = `${state.currentUser.name} (${state.currentUser.title})`;
  }
}

function openNewRequestModal() {
  populateSelectAreas();
  openModal('modal-new-request');
}

function handleCreateRequest(e) {
  e.preventDefault();
  const title = document.getElementById('req-title').value;
  const areaId = document.getElementById('req-area').value;
  const location = document.getElementById('req-location').value;
  const description = document.getElementById('req-description').value;
  const priority = document.getElementById('req-priority').value;
  const requester = document.getElementById('req-requester').value;

  const areaObj = state.areas.find(a => a.id === areaId);

  const newReq = {
    id: `req_${Date.now()}`,
    title,
    areaId,
    areaName: areaObj ? areaObj.name : 'General',
    location,
    description,
    priority,
    requesterName: requester,
    requesterEmail: state.currentUser ? state.currentUser.email : 'contacto@elalmendro.cl',
    createdDate: '2026-08-28 ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    photo: null,
    status: 'Pendiente',
    convertedTo: null
  };

  state.requests.unshift(newReq);

  state.notifications.unshift({
    id: `notif_${Date.now()}`,
    type: 'info',
    title: `Nueva Solicitud: ${title}`,
    message: `${requester} ingresó solicitud en ${newReq.areaName} (${location}).`,
    timestamp: 'Recién',
    linkModule: 'solicitudes',
    read: false
  });

  saveState();
  closeModal('modal-new-request');
  document.getElementById('form-new-request').reset();
  alert("✅ Solicitud ingresada correctamente.");
}

function openConvertRequestModal(reqId) {
  activeConvertingRequestId = reqId;
  const req = state.requests.find(r => r.id === reqId);
  if (req) {
    document.getElementById('convert-req-title').textContent = req.title;
    openModal('modal-convert-request');
  }
}

function executeConversion(targetType) {
  if (!activeConvertingRequestId) return;
  const req = state.requests.find(r => r.id === activeConvertingRequestId);
  if (!req) return;

  if (targetType === 'Preventiva' || targetType === 'Correctiva' || targetType === 'Esporádica') {
    const newMnt = {
      id: `mnt_${Date.now()}`,
      title: req.title,
      description: req.description + ` (Originado desde solicitud de ${req.requesterName} en ${req.location})`,
      areaId: req.areaId,
      areaName: req.areaName,
      assetId: null,
      assetName: req.location,
      type: targetType,
      priority: req.priority,
      responsible: "Manuel Pérez",
      createdDate: "2026-08-28",
      startDate: "2026-08-29",
      limitDate: "2026-08-30",
      completedDate: null,
      status: "Pendiente",
      estimatedCost: 30000,
      actualCost: 0,
      photosBefore: [],
      photosAfter: [],
      documents: [],
      observations: "Solicitud convertida."
    };
    state.maintenances.unshift(newMnt);
  } else if (targetType === 'Mejora') {
    const newImp = {
      id: `imp_${Date.now()}`,
      name: req.title,
      description: req.description,
      areaId: req.areaId,
      areaName: req.areaName,
      responsible: state.currentUser?.name || "Roberto Silva",
      startDate: "2026-09-01",
      endDate: "2026-09-30",
      priority: req.priority,
      status: "Planificación",
      budget: 1000000,
      actualCost: 0,
      progressPercent: 0,
      materials: [],
      photos: [],
      documents: []
    };
    state.improvements.unshift(newImp);
  } else if (targetType === 'Remodelacion') {
    const newRen = {
      id: `ren_${Date.now()}`,
      name: req.title,
      space: req.location,
      areaId: req.areaId,
      areaName: req.areaName,
      description: req.description,
      responsible: state.currentUser?.name || "Roberto Silva",
      startDate: "2026-09-01",
      endDate: "2026-09-30",
      status: "Planificación",
      budget: 2000000,
      progressPercent: 0,
      materials: []
    };
    state.renovations.unshift(newRen);
  }

  req.status = 'Convertida';
  req.convertedTo = { type: targetType, id: `gen_${Date.now()}` };

  saveState();
  closeModal('modal-convert-request');
  alert(`✅ Solicitud convertida exitosamente a ${targetType}.`);
}

let openedFromAreaDetail = null;

function returnToAreaDetail() {
  const areaId = openedFromAreaDetail;
  closeModal('modal-maintenance-detail');
  closeModal('modal-renovation-detail');
  closeModal('modal-improvement-detail');
  if (areaId) {
    setTimeout(() => {
      openAreaDetail(areaId);
    }, 50);
  }
}

function closeMaintenanceModalWithReturn() {
  closeModal('modal-maintenance-detail');
}

function openMaintenanceDetail(mntId, fromAreaId = null) {
  const mnt = state.maintenances.find(m => m.id === mntId);
  if (!mnt) return;

  openedFromAreaDetail = (fromAreaId && fromAreaId !== 'null' && fromAreaId !== 'undefined') ? fromAreaId : null;

  const alert = getMaintenanceAlert(mnt);
  const content = document.getElementById('maintenance-modal-content');
  if (content) content.scrollTop = 0;

  content.innerHTML = `
    <div class="flex items-center justify-between pb-4 border-b border-slate-100">
      <div>
        <div class="flex items-center space-x-2 flex-wrap gap-y-1">
          <span class="text-xs font-extrabold px-2.5 py-1 rounded-md uppercase bg-blue-100 text-blue-800">
            Mantención ${mnt.type}
          </span>
          ${alert ? `
            <span class="text-xs font-extrabold px-2.5 py-0.5 rounded-md ${alert.badgeClass}">
              🔔 ${alert.badge} • ${alert.text}
            </span>
          ` : ''}
          ${openedFromAreaDetail ? `
            <button onclick="returnToAreaDetail()" class="text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 px-2.5 py-1 rounded-xl flex items-center space-x-1 transition-colors">
              <span>← Volver a Ficha de Área</span>
            </button>
          ` : ''}
        </div>
        <h3 class="text-xl font-extrabold text-slate-900 mt-2">${mnt.title}</h3>
      </div>
      <button onclick="closeModal('modal-maintenance-detail')" class="text-slate-400 hover:text-slate-600 text-2xl font-bold p-1">&times;</button>
    </div>

    <div class="mt-5 grid grid-cols-1 md:grid-cols-2 gap-6">
      <div class="space-y-4">
        <div>
          <p class="text-xs font-bold text-slate-400 uppercase">Descripción</p>
          <p class="text-xs text-slate-700 mt-1 leading-relaxed">${mnt.description}</p>
        </div>

        <div class="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
          <div>
            <p class="text-[10px] text-slate-400 uppercase font-bold">Área de Trabajo</p>
            <p class="font-bold text-slate-800">${mnt.workAreaName || 'Mantención General'}</p>
          </div>
          <div>
            <p class="text-[10px] text-slate-400 uppercase font-bold">Ubicación Hotel / Activo</p>
            <p class="font-bold text-blue-700">${mnt.areaName} (${mnt.assetName || 'Instalación General'})</p>
          </div>
        </div>

        <div class="grid grid-cols-2 gap-3 text-xs">
          <div>
            <p class="text-[10px] text-slate-400 uppercase font-bold">Fecha Inicio</p>
            <p class="font-bold text-slate-800">${formatDate(mnt.startDate)}</p>
          </div>
          <div>
            <p class="text-[10px] text-slate-400 uppercase font-bold">Fecha Límite</p>
            <p class="font-bold text-slate-800">${formatDate(mnt.limitDate)}</p>
          </div>
        </div>

        <div>
          <label class="block text-xs font-bold text-slate-400 uppercase mb-1">Estado de la Mantención</label>
          <select onchange="updateMaintenanceStatus('${mnt.id}', this.value)" class="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-bold text-slate-800">
            <option value="Pendiente" ${mnt.status === 'Pendiente' ? 'selected' : ''}>Pendiente</option>
            <option value="Programada" ${mnt.status === 'Programada' ? 'selected' : ''}>Programada</option>
            <option value="En proceso" ${mnt.status === 'En proceso' ? 'selected' : ''}>En proceso</option>
            <option value="Completada" ${mnt.status === 'Completada' ? 'selected' : ''}>Completada</option>
            <option value="Atrasada" ${mnt.status === 'Atrasada' ? 'selected' : ''}>Atrasada</option>
            <option value="Cancelada" ${mnt.status === 'Cancelada' ? 'selected' : ''}>Cancelada</option>
          </select>
        </div>

        <div>
          <p class="text-xs font-bold text-slate-400 uppercase mb-1">Observaciones Técnicas</p>
          <p class="text-xs text-slate-700 bg-slate-50 p-3 rounded-xl border border-slate-200">
            ${mnt.observations || 'Sin observaciones adicionales.'}
          </p>
        </div>
      </div>

      <div class="space-y-4">
        <!-- Calculadora y Registro de Materiales Reutilizable -->
        ${renderMaterialsManager({
          parentType: 'mantencion',
          parentId: mnt.id,
          materials: mnt.materials || [],
          budget: mnt.estimatedCost || 0,
          actualCost: mnt.actualCost || 0,
          title: 'Materiales & Costos de la Mantención'
        })}

        ${mnt.photosBefore && mnt.photosBefore.length > 0 ? `
          <div>
            <p class="text-xs font-bold text-slate-400 uppercase mb-1">Fotografías del Trabajo</p>
            <div class="grid grid-cols-2 gap-2">
              <div>
                <p class="text-[10px] text-slate-500 font-bold mb-0.5">Antes:</p>
                <img src="${mnt.photosBefore[0]}" class="rounded-xl h-24 w-full object-cover border border-slate-200">
              </div>
              ${mnt.photosAfter && mnt.photosAfter.length > 0 ? `
                <div>
                  <p class="text-[10px] text-slate-500 font-bold mb-0.5">Después:</p>
                  <img src="${mnt.photosAfter[0]}" class="rounded-xl h-24 w-full object-cover border border-slate-200">
                </div>
              ` : ''}
            </div>
          </div>
        ` : ''}
      </div>
    </div>

    <div class="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
      <span class="text-xs text-slate-500">Responsable asignado: <strong>${mnt.responsible}</strong></span>
      <div class="flex items-center space-x-2">
        ${openedFromAreaDetail ? `
          <button onclick="returnToAreaDetail()" class="px-4 py-2 bg-blue-50 text-blue-700 border border-blue-200 rounded-xl text-xs font-bold hover:bg-blue-100 transition-colors">
            ← Volver a Ficha de Área
          </button>
        ` : ''}
        <button onclick="closeModal('modal-maintenance-detail')" class="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-colors">
          Cerrar Ficha
        </button>
      </div>
    </div>
  `;
  openModal('modal-maintenance-detail');
}

function updateMaintenanceStatus(mntId, newStatus) {
  const mnt = state.maintenances.find(m => m.id === mntId);
  if (mnt) {
    mnt.status = newStatus;
    if (newStatus === 'Completada') {
      mnt.completedDate = '2026-08-28';
    }
    saveState();
    openMaintenanceDetail(mntId);
  }
}

function openAssetDetail(assetId, tab = 'ficha') {
  selectedAssetTab = tab;
  const asset = state.assets.find(a => a.id === assetId);
  if (!asset) return;

  const wInfo = calculateWarrantyStatus(asset.warranty);
  const content = document.getElementById('asset-modal-content');
  if (content) content.scrollTop = 0;

  content.innerHTML = `
    <div class="flex items-center justify-between pb-4 border-b border-slate-100">
      <div class="flex items-center space-x-3">
        <div class="w-12 h-12 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center text-2xl font-bold">
          🏷️
        </div>
        <div>
          <div class="flex items-center space-x-2">
            <h3 class="text-lg font-extrabold text-slate-900">${asset.name}</h3>
            <span class="text-xs font-bold px-2.5 py-0.5 rounded-full ${wInfo.status === 'Vigente' ? 'bg-emerald-100 text-emerald-800' : wInfo.status === 'Proxima' ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'}">
              ${wInfo.badge}
            </span>
          </div>
          <p class="text-xs text-slate-500">${asset.brand} • Modelo ${asset.model} • N° Serie: ${asset.serialNumber}</p>
        </div>
      </div>
      <button onclick="closeModal('modal-asset-detail')" class="text-slate-400 hover:text-slate-600 text-2xl font-bold p-1">&times;</button>
    </div>

    <div class="flex items-center space-x-2 border-b border-slate-200 mt-4 pb-2">
      <button onclick="openAssetDetail('${asset.id}', 'ficha')" class="px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${selectedAssetTab === 'ficha' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'}">
        📋 Ficha Técnica
      </button>
      <button onclick="openAssetDetail('${asset.id}', 'garantia')" class="px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${selectedAssetTab === 'garantia' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'}">
        🛡️ Garantía & Documentos
      </button>
      <button onclick="openAssetDetail('${asset.id}', 'plan')" class="px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${selectedAssetTab === 'plan' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'}">
        🔄 Plan de Mantenimiento
      </button>
      <button onclick="openAssetDetail('${asset.id}', 'historial')" class="px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${selectedAssetTab === 'historial' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'}">
        📜 Historial Cronológico
      </button>
    </div>

    <div class="mt-5">
      ${renderAssetTabContent(asset, selectedAssetTab, wInfo)}
    </div>

    <!-- FOOTER DE CIERRE -->
    <div class="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
      <span class="text-xs text-slate-500">Activo: <strong>${asset.name}</strong> • Hotel El Almendro</span>
      <button onclick="closeModal('modal-asset-detail')" class="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-colors">
        Cerrar Ficha
      </button>
    </div>
  `;
  openModal('modal-asset-detail');
  if (content) content.scrollTop = 0;
}

function renderAssetTabContent(asset, tab, wInfo) {
  if (tab === 'ficha') {
    return `
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="space-y-3 text-xs">
          <div class="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
            <div class="flex justify-between">
              <span class="text-slate-500 font-bold">Categoría:</span>
              <span class="font-bold text-slate-800">${asset.category}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-500 font-bold">Ubicación:</span>
              <span class="font-bold text-slate-800">${asset.areaName} (${asset.location})</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-500 font-bold">Proveedor:</span>
              <span class="font-bold text-slate-800">${asset.provider}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-500 font-bold">Fecha de Compra:</span>
              <span class="font-bold text-slate-800">${formatDate(asset.purchaseDate)}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-500 font-bold">Valor de Adquisición:</span>
              <span class="font-extrabold text-blue-700">${formatCLP(asset.purchaseValue)}</span>
            </div>
          </div>
        </div>
        <div>
          <img src="${asset.photo}" alt="${asset.name}" class="w-full h-48 object-cover rounded-2xl border border-slate-200">
        </div>
      </div>
    `;
  } else if (tab === 'garantia') {
    return `
      <div class="space-y-4 text-xs">
        <div class="p-4 bg-amber-50/70 border border-amber-200 rounded-2xl">
          <h4 class="font-extrabold text-amber-900 text-sm">Estado de Garantía: ${wInfo.badge}</h4>
          <p class="text-slate-700 mt-1">${wInfo.text}</p>
          <div class="mt-3 grid grid-cols-2 gap-2 text-slate-700">
            <div>Proveedor: <strong>${asset.warranty.provider || asset.provider}</strong></div>
            <div>Póliza / Ref: <strong>${asset.warranty.referenceDoc || 'S/N'}</strong></div>
          </div>
          <p class="mt-2 text-slate-600"><em>${asset.warranty.notes || ''}</em></p>
        </div>

        <div>
          <h4 class="font-bold text-slate-800 mb-2">Documentos Adjuntos (Facturas, Manuales, Pólizas)</h4>
          <div class="space-y-2">
            ${(asset.documents || []).map(doc => `
              <div class="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                <div class="flex items-center space-x-2">
                  <span class="text-base">📄</span>
                  <div>
                    <p class="font-bold text-slate-800">${doc.name}</p>
                    <p class="text-[10px] text-slate-500">${doc.size} • Subido el ${formatDate(doc.date)}</p>
                  </div>
                </div>
                <button class="text-xs font-bold text-blue-600 hover:underline">Descargar</button>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;
  } else if (tab === 'plan') {
    return `
      <div class="space-y-4 text-xs">
        <div class="p-4 bg-blue-50/70 border border-blue-200 rounded-2xl">
          <h4 class="font-extrabold text-blue-900 text-sm">Pauta Preventiva: ${asset.maintenancePlan.type}</h4>
          <div class="mt-3 grid grid-cols-2 gap-3 text-slate-700">
            <div>Frecuencia: <strong>${asset.maintenancePlan.frequencyLabel}</strong></div>
            <div>Responsable: <strong>${asset.maintenancePlan.responsible}</strong></div>
            <div>Última Mantención: <strong>${formatDate(asset.maintenancePlan.lastDate)}</strong></div>
            <div class="text-blue-800 font-bold">Próxima Mantención: <strong>${formatDate(asset.maintenancePlan.nextDate)}</strong></div>
          </div>
          <p class="mt-2 text-slate-600"><em>Instrucciones: ${asset.maintenancePlan.notes}</em></p>
        </div>
      </div>
    `;
  } else if (tab === 'historial') {
    return `
      <div class="space-y-3">
        <h4 class="text-xs font-bold text-slate-400 uppercase">Línea de Tiempo del Activo (Historial Perpetuo)</h4>
        <div class="space-y-3 pl-2 border-l-2 border-slate-200">
          ${(asset.history || []).map(h => `
            <div class="relative pl-4 text-xs">
              <div class="absolute -left-[21px] top-1 w-3 h-3 rounded-full bg-blue-600 border-2 border-white"></div>
              <div class="flex items-center justify-between">
                <span class="font-extrabold text-slate-800">${h.type}</span>
                <span class="text-slate-500 font-semibold">${formatDate(h.date)}</span>
              </div>
              <p class="text-slate-600 mt-0.5">${h.description}</p>
              <div class="mt-1 text-[11px] text-slate-400 flex items-center justify-between">
                <span>Registrado por: ${h.user}</span>
                ${h.cost > 0 ? `<span class="font-bold text-slate-800">Costo: ${formatCLP(h.cost)}</span>` : ''}
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }
}

// ==========================================================
// COMPONENTE REUTILIZABLE: GESTOR DE MATERIALES Y COSTOS
// ==========================================================
function renderMaterialsManager(options) {
  const { parentType, parentId, materials = [], budget = 0, actualCost = 0, title = "Cómputo y Control de Materiales" } = options;

  // Cálculo automático del total general: suma de subtotales
  const calculatedTotal = materials.reduce((acc, m) => {
    const sub = (Number(m.quantity) || 0) * (Number(m.unitCost) || 0);
    m.subtotal = sub; // asegurar sincronización
    return acc + sub;
  }, 0);

  const effectiveCost = actualCost > 0 ? actualCost : calculatedTotal;
  const difference = budget - effectiveCost;

  return `
    <div class="bg-slate-50 p-4 sm:p-5 rounded-2xl border border-slate-200 space-y-4">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-200">
        <div>
          <h4 class="text-xs font-black text-slate-900 uppercase tracking-tight flex items-center space-x-1.5">
            <span>📦</span>
            <span>${title}</span>
          </h4>
          <p class="text-[11px] text-slate-500">Cálculo automático de subtotales (Cantidad × Costo Unitario) y costo total del proyecto.</p>
        </div>
        <div class="flex items-center space-x-3 text-xs self-start sm:self-auto">
          <div>
            <span class="text-slate-500 font-bold block text-[10px] uppercase">Total Materiales:</span>
            <span class="font-black text-slate-900 text-sm">${formatCLP(calculatedTotal)}</span>
          </div>
        </div>
      </div>

      <!-- Resumen de Costos y Presupuesto -->
      ${budget > 0 ? `
        <div class="grid grid-cols-3 gap-2 p-3 bg-white rounded-xl border border-slate-200 text-xs text-center shadow-xs">
          <div>
            <p class="text-[10px] text-slate-500 uppercase font-bold">Presupuesto Estimado</p>
            <p class="font-extrabold text-slate-800 text-sm">${formatCLP(budget)}</p>
          </div>
          <div>
            <p class="text-[10px] text-slate-500 uppercase font-bold">Gasto / Total Real</p>
            <p class="font-extrabold text-blue-700 text-sm">${formatCLP(effectiveCost)}</p>
          </div>
          <div>
            <p class="text-[10px] text-slate-500 uppercase font-bold">Diferencia</p>
            <p class="font-extrabold text-sm ${difference >= 0 ? 'text-emerald-700' : 'text-rose-700'}">
              ${difference >= 0 ? '+' : ''}${formatCLP(difference)}
            </p>
          </div>
        </div>
      ` : ''}

      <!-- Lista de Materiales / Cuadrícula de Ítems -->
      <div class="space-y-2 max-h-56 overflow-y-auto custom-scrollbar pr-1">
        ${materials.length === 0 ? `
          <div class="p-4 text-center text-xs text-slate-400 bg-white rounded-xl border border-dashed border-slate-200">
            No se han registrado materiales todavía. Ingresa insumos en el formulario inferior.
          </div>
        ` : materials.map((mat, index) => {
          const subtotal = (Number(mat.quantity) || 0) * (Number(mat.unitCost) || 0);
          return `
            <div class="p-3 bg-white rounded-xl border border-slate-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs hover:border-blue-300 transition-colors">
              <div class="flex-1 min-w-0">
                <p class="font-extrabold text-slate-800 truncate">${mat.name}</p>
                <div class="flex items-center space-x-2 text-[11px] text-slate-500 mt-0.5">
                  <span>${mat.quantity} ${mat.unit || 'unid'}</span>
                  <span>×</span>
                  <span class="font-semibold text-slate-700">${formatCLP(mat.unitCost)}</span>
                  <span class="text-slate-300">•</span>
                  <span class="font-black text-blue-800">Subtotal: ${formatCLP(subtotal)}</span>
                </div>
              </div>

              <!-- Controles de Edición Rápida y Eliminación -->
              <div class="flex items-center space-x-2 self-end sm:self-auto flex-shrink-0">
                <input type="number" min="0.1" step="any" value="${mat.quantity}" title="Editar Cantidad"
                  onchange="handleUpdateMaterialQty('${parentType}', '${parentId}', '${mat.id || index}', this.value)"
                  class="w-16 bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-xs font-bold text-slate-800 text-center">
                <button type="button" onclick="handleDeleteMaterial('${parentType}', '${parentId}', '${mat.id || index}')"
                  class="text-rose-500 hover:text-rose-700 hover:bg-rose-50 p-1.5 rounded-lg text-xs font-bold transition-colors" title="Eliminar Insumo">
                  🗑️
                </button>
              </div>
            </div>
          `;
        }).join('')}
      </div>

      <!-- Formulario para Agregar Nuevo Material -->
      <form onsubmit="handleAddMaterialGeneric(event, '${parentType}', '${parentId}')" 
            class="pt-3 border-t border-slate-200 grid grid-cols-12 gap-2.5 bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
        
        <!-- Fila 1: Nombre Insumo con ancho completo -->
        <div class="col-span-12">
          <label class="block text-[10px] font-bold text-slate-600 uppercase mb-1">Nombre Insumo *</label>
          <input type="text" id="mat-input-name-${parentId}" required placeholder="Ej: Pintura, Grifería, Tubo PVC, Foco LED..."
            class="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs text-slate-800 focus:ring-1 focus:ring-blue-500 focus:bg-white transition-all">
        </div>

        <!-- Fila 2: Cantidad, Unidad y Costo Unitario espaciados holgadamente sin colisiones -->
        <div class="col-span-4">
          <label class="block text-[10px] font-bold text-slate-600 uppercase mb-1">Cantidad *</label>
          <input type="number" id="mat-input-qty-${parentId}" required min="0.1" step="any" value="1"
            class="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-1.5 text-xs font-bold text-slate-800 text-center focus:ring-1 focus:ring-blue-500 focus:bg-white transition-all">
        </div>

        <div class="col-span-3">
          <label class="block text-[10px] font-bold text-slate-600 uppercase mb-1">Unidad</label>
          <input type="text" id="mat-input-unit-${parentId}" placeholder="unid" value="unid"
            class="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-1.5 text-xs text-slate-800 text-center focus:ring-1 focus:ring-blue-500 focus:bg-white transition-all">
        </div>

        <div class="col-span-5">
          <label class="block text-[10px] font-bold text-slate-600 uppercase mb-1 truncate" title="Costo Unitario ($)">Costo Unit. ($) *</label>
          <input type="number" id="mat-input-price-${parentId}" required min="0" step="any" placeholder="0"
            class="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-800 text-right focus:ring-1 focus:ring-blue-500 focus:bg-white transition-all">
        </div>

        <!-- Fila 3: Información y Botón de Envío -->
        <div class="col-span-12 flex flex-col sm:flex-row items-center justify-between gap-2 pt-2 border-t border-slate-100">
          <span class="text-[11px] text-slate-500 font-medium">El subtotal se calculará automáticamente.</span>
          <button type="submit" 
            class="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-4 py-2 rounded-xl transition-all shadow-sm flex items-center justify-center space-x-1 flex-shrink-0">
            <span>+ Agregar Material</span>
          </button>
        </div>
      </form>
    </div>
  `;
}

function findParentContainer(parentType, parentId) {
  if (parentType === 'mantencion') {
    return state.maintenances.find(m => m.id === parentId);
  } else if (parentType === 'remodelacion') {
    return state.renovations.find(r => r.id === parentId);
  } else if (parentType === 'mejora') {
    return state.improvements.find(i => i.id === parentId);
  }
  return null;
}

function refreshParentModal(parentType, parentId) {
  if (parentType === 'mantencion') openMaintenanceDetail(parentId);
  else if (parentType === 'remodelacion') openRenovationDetail(parentId);
  else if (parentType === 'mejora') openImprovementDetail(parentId);
}

function handleAddMaterialGeneric(e, parentType, parentId) {
  e.preventDefault();
  const nameInput = document.getElementById(`mat-input-name-${parentId}`);
  const qtyInput = document.getElementById(`mat-input-qty-${parentId}`);
  const unitInput = document.getElementById(`mat-input-unit-${parentId}`);
  const priceInput = document.getElementById(`mat-input-price-${parentId}`);

  if (!nameInput || !qtyInput || !priceInput) return;

  const name = nameInput.value.trim();
  const qty = parseFloat(qtyInput.value) || 1;
  const unit = unitInput ? unitInput.value.trim() || 'unid' : 'unid';
  const price = parseFloat(priceInput.value) || 0;

  const parent = findParentContainer(parentType, parentId);
  if (parent) {
    if (!parent.materials) parent.materials = [];
    const subtotal = qty * price;
    parent.materials.push({
      id: `mat_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      name,
      quantity: qty,
      unit,
      unitCost: price,
      subtotal
    });

    // Actualizar gasto real si es remodelación o mantención
    parent.actualCost = parent.materials.reduce((acc, m) => acc + (m.subtotal || 0), 0);

    saveState();
    refreshParentModal(parentType, parentId);
  }
}

function handleUpdateMaterialQty(parentType, parentId, matId, newQty) {
  const qty = parseFloat(newQty) || 1;
  const parent = findParentContainer(parentType, parentId);
  if (parent && parent.materials) {
    const mat = parent.materials.find((m, idx) => m.id === matId || String(idx) === String(matId));
    if (mat) {
      mat.quantity = qty;
      mat.subtotal = qty * (Number(mat.unitCost) || 0);
      parent.actualCost = parent.materials.reduce((acc, m) => acc + (m.subtotal || 0), 0);
      saveState();
      refreshParentModal(parentType, parentId);
    }
  }
}

function handleDeleteMaterial(parentType, parentId, matId) {
  const parent = findParentContainer(parentType, parentId);
  if (parent && parent.materials) {
    parent.materials = parent.materials.filter((m, idx) => m.id !== matId && String(idx) !== String(matId));
    parent.actualCost = parent.materials.reduce((acc, m) => acc + (m.subtotal || 0), 0);
    saveState();
    refreshParentModal(parentType, parentId);
  }
}

function openRenovationDetail(renId, fromAreaId = null) {
  const ren = state.renovations.find(r => r.id === renId);
  if (!ren) return;

  openedFromAreaDetail = (fromAreaId && fromAreaId !== 'null' && fromAreaId !== 'undefined') ? fromAreaId : null;

  const content = document.getElementById('renovation-modal-content');
  if (content) content.scrollTop = 0;

  content.innerHTML = `
    <div class="flex items-center justify-between pb-4 border-b border-slate-100">
      <div>
        <div class="flex items-center space-x-2 flex-wrap gap-y-1">
          <span class="text-xs font-extrabold bg-purple-100 text-purple-800 px-2.5 py-1 rounded-md uppercase">
            Remodelación: ${ren.space}
          </span>
          ${openedFromAreaDetail ? `
            <button onclick="returnToAreaDetail()" class="text-xs font-bold text-purple-700 bg-purple-50 hover:bg-purple-100 border border-purple-200 px-2.5 py-1 rounded-xl flex items-center space-x-1 transition-colors">
              <span>← Volver a Ficha de Área</span>
            </button>
          ` : ''}
        </div>
        <h3 class="text-xl font-extrabold text-slate-900 mt-2">${ren.name}</h3>
      </div>
      <button onclick="closeModal('modal-renovation-detail')" class="text-slate-400 hover:text-slate-600 text-2xl font-bold p-1">&times;</button>
    </div>

    <div class="mt-4 space-y-4">
      <p class="text-xs text-slate-700 leading-relaxed">${ren.description}</p>

      ${renderMaterialsManager({
        parentType: 'remodelacion',
        parentId: ren.id,
        materials: ren.materials || [],
        budget: ren.budget || 0,
        actualCost: ren.actualCost || 0,
        title: 'Cómputo Automatizado de Materiales'
      })}
    </div>

    <div class="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
      <span class="text-xs text-slate-500">Responsable: <strong>${ren.responsible}</strong></span>
      <div class="flex items-center space-x-2">
        ${openedFromAreaDetail ? `
          <button onclick="returnToAreaDetail()" class="px-4 py-2 bg-purple-50 text-purple-700 border border-purple-200 rounded-xl text-xs font-bold hover:bg-purple-100 transition-colors">
            ← Volver a Ficha de Área
          </button>
        ` : ''}
        <button onclick="closeModal('modal-renovation-detail')" class="px-5 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800">
          Cerrar Ficha
        </button>
      </div>
    </div>
  `;
  openModal('modal-renovation-detail');
  if (content) content.scrollTop = 0;
}

function openImprovementDetail(impId, fromAreaId = null) {
  const imp = state.improvements.find(i => i.id === impId);
  if (!imp) return;

  openedFromAreaDetail = (fromAreaId && fromAreaId !== 'null' && fromAreaId !== 'undefined') ? fromAreaId : null;

  const content = document.getElementById('improvement-modal-content');
  if (content) content.scrollTop = 0;

  content.innerHTML = `
    <div class="flex items-center justify-between pb-4 border-b border-slate-100">
      <div>
        <div class="flex items-center space-x-2 flex-wrap gap-y-1">
          <span class="text-xs font-extrabold bg-emerald-100 text-emerald-800 px-2.5 py-1 rounded-md uppercase">
            Proyecto de Mejora
          </span>
          ${openedFromAreaDetail ? `
            <button onclick="returnToAreaDetail()" class="text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-2.5 py-1 rounded-xl flex items-center space-x-1 transition-colors">
              <span>← Volver a Ficha de Área</span>
            </button>
          ` : ''}
        </div>
        <h3 class="text-xl font-extrabold text-slate-900 mt-2">${imp.name}</h3>
      </div>
      <button onclick="closeModal('modal-improvement-detail')" class="text-slate-400 hover:text-slate-600 text-2xl font-bold p-1">&times;</button>
    </div>
    <div class="mt-4 space-y-4 text-xs">
      <p class="text-slate-700 leading-relaxed">${imp.description}</p>
      
      <div class="grid grid-cols-2 gap-3 p-3.5 bg-emerald-50 rounded-2xl border border-emerald-200">
        <div>
          <span class="text-[10px] text-emerald-800 font-bold uppercase block">Presupuesto Aprobado</span>
          <span class="text-base font-extrabold text-slate-900">${formatCLP(imp.budget)}</span>
        </div>
        <div>
          <span class="text-[10px] text-emerald-800 font-bold uppercase block">Avance de Obra</span>
          <span class="text-base font-extrabold text-emerald-700">${imp.progressPercent}%</span>
        </div>
      </div>

      ${renderMaterialsManager({
        parentType: 'mejora',
        parentId: imp.id,
        materials: imp.materials || [],
        budget: imp.budget || 0,
        actualCost: imp.actualCost || 0,
        title: 'Materiales & Insumos de la Obra'
      })}
    </div>

    <div class="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
      <span class="text-xs text-slate-500">Responsable: <strong>${imp.responsible}</strong></span>
      <div class="flex items-center space-x-2">
        ${openedFromAreaDetail ? `
          <button onclick="returnToAreaDetail()" class="px-4 py-2 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-xl text-xs font-bold hover:bg-emerald-100 transition-colors">
            ← Volver a Ficha de Área
          </button>
        ` : ''}
        <button onclick="closeModal('modal-improvement-detail')" class="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-colors">
          Cerrar Ficha
        </button>
      </div>
    </div>
  `;
  openModal('modal-improvement-detail');
  if (content) content.scrollTop = 0;
}

// ==========================================================
// REQUISITO 5, 3 & 15: FICHA DE ÁREA REUTILIZABLE (AreaDetail)
// Estructura única para las 6 áreas con encabezado oscuro,
// apartados estructurados y 100% cuadrícula de cuadros.
// ==========================================================

function openTaskFromArea(module, id, areaId) {
  openedFromAreaDetail = areaId;
  if (module === 'mejoras') {
    openImprovementDetail(id, areaId);
  } else if (module === 'remodelaciones') {
    openRenovationDetail(id, areaId);
  } else {
    openMaintenanceDetail(id, areaId);
  }
}

function goToGanttForArea(areaId) {
  closeModal('modal-area-detail');
  navigateTo('gantt');
  ganttAreaFilter = areaId;
  renderCurrentView();
}

function openAreaDetail(areaId) {
  const s = getWorkAreaStats(areaId);
  const area = s.area;
  const isMainArea = area.id === 'workarea_general' || area.isPrincipal;

  const content = document.getElementById('area-modal-content');
  if (!content) return;

  // Áreas relacionadas (Requisito 3: solo para Mantención General)
  const relatedAreasHtml = isMainArea ? `
    <div class="mt-4 p-4 rounded-2xl bg-blue-50/70 border border-blue-200">
      <div class="flex items-center justify-between mb-3">
        <h5 class="text-xs font-black text-blue-900 uppercase tracking-tight flex items-center space-x-1.5">
          <span>🔗</span>
          <span>Áreas Relacionadas (Acceso Rápido)</span>
        </h5>
        <span class="text-[10px] font-semibold text-blue-700">Sub-unidades operativas</span>
      </div>
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div onclick="openAreaDetail('workarea_reactiva')" 
             class="p-3 bg-white rounded-xl border border-blue-200 hover:border-blue-500 hover:shadow-md cursor-pointer transition-all flex items-center space-x-3 group">
          <span class="text-2xl group-hover:scale-110 transition-transform">⚡</span>
          <div class="min-w-0">
            <p class="text-xs font-bold text-slate-900 group-hover:text-blue-600 truncate">Mantención Reactiva</p>
            <p class="text-[10px] text-slate-500">Averías e imprevistos</p>
          </div>
        </div>

        <div onclick="openAreaDetail('workarea_maquinas')" 
             class="p-3 bg-white rounded-xl border border-blue-200 hover:border-blue-500 hover:shadow-md cursor-pointer transition-all flex items-center space-x-3 group">
          <span class="text-2xl group-hover:scale-110 transition-transform">⚙️</span>
          <div class="min-w-0">
            <p class="text-xs font-bold text-slate-900 group-hover:text-blue-600 truncate">Mantención de Máquinas</p>
            <p class="text-[10px] text-slate-500">Calderas y equipos</p>
          </div>
        </div>

        <div onclick="openAreaDetail('workarea_jardineria')" 
             class="p-3 bg-white rounded-xl border border-blue-200 hover:border-blue-500 hover:shadow-md cursor-pointer transition-all flex items-center space-x-3 group">
          <span class="text-2xl group-hover:scale-110 transition-transform">🌳</span>
          <div class="min-w-0">
            <p class="text-xs font-bold text-slate-900 group-hover:text-blue-600 truncate">Mantención de Jardinería</p>
            <p class="text-[10px] text-slate-500">Parques y piscina</p>
          </div>
        </div>
      </div>
    </div>
  ` : '';

  content.innerHTML = `
    <!-- ENCABEZADO OSCURO CON EL NOMBRE DEL ÁREA -->
    <div class="bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950 text-white rounded-t-3xl p-6 sm:p-7 border-b border-slate-800 flex items-start justify-between">
      <div class="flex items-center space-x-4">
        <div class="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-3xl shadow-inner flex-shrink-0">
          ${area.icon}
        </div>
        <div>
          <div class="flex items-center space-x-2.5 flex-wrap">
            <h2 class="text-xl sm:text-2xl font-black text-white tracking-tight">Ficha de Área: ${area.name}</h2>
            ${isMainArea ? `
              <span class="bg-blue-600 text-white text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full shadow-sm">
                ⭐ Área Principal
              </span>
            ` : ''}
          </div>
          <p class="text-xs text-slate-300 mt-1 flex items-center space-x-2 flex-wrap">
            <span>🏢 Unidad Operativa • Hotel El Almendro</span>
            <span>•</span>
            <span>Responsable: <strong class="text-white">${area.responsible}</strong></span>
          </p>
        </div>
      </div>
      <button onclick="closeModal('modal-area-detail')" class="text-slate-400 hover:text-white text-3xl font-bold p-1 leading-none transition-colors">&times;</button>
    </div>

    <!-- TARJETA GRANDE BLANCA CON APARTADOS ESTRUCTURADOS -->
    <div class="bg-white rounded-b-3xl p-6 sm:p-8 space-y-8">
      
      <!-- APARTADO 1: 📌 DESCRIPCIÓN DEL ÁREA -->
      <div class="space-y-3">
        <div class="flex items-center space-x-2">
          <span class="text-xl">📌</span>
          <div>
            <h4 class="text-base font-black text-slate-900">Descripción del área</h4>
            <p class="text-xs text-slate-500">Objetivo y alcance de esta unidad operativa dentro de la gestión de El Almendro.</p>
          </div>
        </div>

        <div class="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs text-slate-700 leading-relaxed">
          <p class="font-bold text-slate-900 mb-2">${area.description}</p>
          ${area.bullets && area.bullets.length > 0 ? `
            <ul class="space-y-1.5 mt-2 pt-2 border-t border-slate-200/80">
              ${area.bullets.map(b => `
                <li class="flex items-start space-x-2 text-slate-700 font-medium">
                  <span class="text-blue-600 font-black">✓</span>
                  <span>${b}</span>
                </li>
              `).join('')}
            </ul>
          ` : ''}
        </div>

        ${relatedAreasHtml}
      </div>

      <!-- APARTADO 2: 📊 RESUMEN OPERATIVO Y ESTADOS -->
      <div class="space-y-3 pt-4 border-t border-slate-100">
        <div class="flex items-center space-x-2">
          <span class="text-xl">📊</span>
          <div>
            <h4 class="text-base font-black text-slate-900">Resumen operativo y estados</h4>
            <p class="text-xs text-slate-500">Distribución en tiempo real de actividades en ${area.name}.</p>
          </div>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-5 gap-3">
          <div class="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 text-center shadow-xs">
            <p class="text-[10px] font-bold text-slate-500 uppercase">Activas</p>
            <p class="text-2xl font-black text-blue-600 mt-0.5">${s.active}</p>
          </div>
          <div class="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 text-center shadow-xs">
            <p class="text-[10px] font-bold text-slate-500 uppercase">Pendientes</p>
            <p class="text-2xl font-black text-amber-600 mt-0.5">${s.pending}</p>
          </div>
          <div class="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 text-center shadow-xs">
            <p class="text-[10px] font-bold text-slate-500 uppercase">En Curso</p>
            <p class="text-2xl font-black text-indigo-600 mt-0.5">${s.inProgress}</p>
          </div>
          <div class="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 text-center shadow-xs">
            <p class="text-[10px] font-bold text-slate-500 uppercase">Resueltas</p>
            <p class="text-2xl font-black text-emerald-600 mt-0.5">${s.completed}</p>
          </div>
          <div class="bg-slate-50 p-3.5 rounded-2xl border ${s.delayed > 0 ? 'border-rose-300 bg-rose-50/70 text-rose-700' : 'border-slate-200'} text-center shadow-xs col-span-2 sm:col-span-1">
            <p class="text-[10px] font-bold ${s.delayed > 0 ? 'text-rose-700 font-extrabold' : 'text-slate-500'} uppercase">Atrasadas</p>
            <p class="text-2xl font-black ${s.delayed > 0 ? 'text-rose-700' : 'text-slate-700'} mt-0.5">${s.delayed}</p>
          </div>
        </div>
      </div>

      <!-- APARTADO 3: 📋 TAREAS ACTIVAS Y SU ESTADO (100% CUADROS EN GRID, CERO LISTAS PLANAS) -->
      <div class="space-y-3 pt-4 border-t border-slate-100">
        <div class="flex items-center justify-between">
          <div class="flex items-center space-x-2">
            <span class="text-xl">📋</span>
            <div>
              <h4 class="text-base font-black text-slate-900">Tareas activas y su estado</h4>
              <p class="text-xs text-slate-500">Cuadrícula de actividades operativas pertenecientes a esta área.</p>
            </div>
          </div>
          <span class="text-xs font-extrabold text-blue-700 bg-blue-50 border border-blue-200 px-3 py-1 rounded-xl">
            ${s.tasks.length} Tareas Totales
          </span>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          ${s.tasks.length === 0 ? `
            <div class="col-span-full p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200">
              <p class="text-xs font-bold text-slate-500">No hay tareas registradas actualmente en esta área.</p>
            </div>
          ` : s.tasks.map(t => {
            let displayStatus = t.status;
            if (t.status === 'En proceso') displayStatus = 'En curso';
            if (t.status === 'Completada') displayStatus = 'Resuelta';

            const statusClasses = {
              'Pendiente': 'bg-amber-100 text-amber-800 border-amber-200',
              'En curso': 'bg-indigo-100 text-indigo-800 border-indigo-200 font-bold',
              'Programada': 'bg-blue-100 text-blue-800 border-blue-200',
              'Resuelta': 'bg-emerald-100 text-emerald-800 border-emerald-200',
              'Atrasada': 'bg-rose-100 text-rose-800 border-rose-200 font-black'
            };

            return `
              <div onclick="openTaskFromArea('${t.module}', '${t.id}', '${area.id}')"
                   class="bg-white rounded-2xl p-4 border-2 border-slate-200 hover:border-blue-500 shadow-xs hover:shadow-lg transition-all cursor-pointer flex flex-col justify-between group">
                <div>
                  <div class="flex items-center justify-between gap-1 mb-2">
                    <span class="text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-lg border ${statusClasses[displayStatus] || 'bg-slate-100 text-slate-700'}">
                      ${displayStatus}
                    </span>
                    ${t.alert ? `
                      <span class="text-[9px] font-extrabold px-2 py-0.5 rounded-md ${t.alert.badgeClass} flex items-center space-x-1">
                        <span>🔔</span>
                        <span>${t.alert.badge}</span>
                      </span>
                    ` : ''}
                  </div>

                  <h5 class="text-sm font-extrabold text-slate-900 group-hover:text-blue-600 transition-colors leading-snug">
                    ${t.title}
                  </h5>

                  <div class="mt-2 flex items-center space-x-1 text-xs text-slate-600">
                    <span>📍</span>
                    <span class="truncate font-medium text-slate-700">${t.areaName}</span>
                  </div>

                  <p class="text-xs text-slate-600 mt-2 line-clamp-2 leading-relaxed bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    ${t.description || 'Sin descripción adicional.'}
                  </p>
                </div>

                <div class="mt-4 pt-3 border-t border-slate-100">
                  <div class="grid grid-cols-2 gap-1 text-[11px] mb-2.5">
                    <div>
                      <span class="text-slate-600 font-bold block text-[10px] uppercase">Límite:</span>
                      <span class="font-extrabold ${displayStatus === 'Atrasada' ? 'text-rose-600' : 'text-slate-800'}">${formatDate(t.limitDate)}</span>
                    </div>
                    <div class="text-right">
                      <span class="text-slate-600 font-bold block text-[10px] uppercase">Responsable:</span>
                      <span class="font-bold text-slate-700 truncate block">${t.responsible.split(' ')[0]}</span>
                    </div>
                  </div>

                  <button class="w-full py-2 bg-blue-50 group-hover:bg-blue-600 text-blue-700 group-hover:text-white font-bold text-xs rounded-xl transition-all flex items-center justify-center space-x-1 shadow-xs">
                    <span>Abrir Ficha de la Tarea</span>
                    <span class="group-hover:translate-x-1 transition-transform">→</span>
                  </button>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      </div>

      <!-- APARTADO 4: 📈 LÍNEA DE TIEMPO / CARTA GANTT -->
      <div class="space-y-3 pt-4 border-t border-slate-100">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div class="flex items-center space-x-2">
            <span class="text-xl">📈</span>
            <div>
              <h4 class="text-base font-black text-slate-900">Línea de tiempo / Carta Gantt</h4>
              <p class="text-xs text-slate-500">Ubicación y cronograma de ejecución de las actividades dentro de la planificación general.</p>
            </div>
          </div>
          <button onclick="goToGanttForArea('${area.id}')" 
            class="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center space-x-1.5 self-start sm:self-auto">
            <span>📊</span>
            <span>Abrir en Carta Gantt General</span>
            <span>→</span>
          </button>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          ${s.tasks.map(t => `
            <div class="bg-slate-50 rounded-2xl p-4 border border-slate-200 flex flex-col justify-between space-y-3">
              <div>
                <div class="flex items-center justify-between text-xs mb-1">
                  <span class="font-extrabold text-slate-800 truncate">${t.title}</span>
                  <span class="text-[10px] font-bold text-blue-700 bg-blue-100 px-2 py-0.5 rounded-md">${t.status}</span>
                </div>
                <p class="text-[11px] text-slate-500">📅 ${formatDate(t.startDate)} → ${formatDate(t.limitDate)}</p>
              </div>

              <div>
                <div class="flex justify-between text-[11px] font-bold text-slate-600 mb-1">
                  <span>Progreso</span>
                  <span class="text-blue-700">${t.status === 'Completada' ? '100%' : (t.status === 'En proceso' ? '50%' : '15%')}</span>
                </div>
                <div class="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                  <div class="bg-blue-600 h-2 rounded-full" style="width: ${t.status === 'Completada' ? '100%' : (t.status === 'En proceso' ? '50%' : '15%')}"></div>
                </div>
                <p class="text-[10px] text-slate-400 mt-2 text-right">Resp: ${t.responsible}</p>
              </div>
            </div>
          `).join('')}
        </div>
      </div>

      <!-- APARTADO 5: 💰 COSTOS Y MATERIALES ASOCIADOS (CÁLCULO AUTOMÁTICO) -->
      <div class="space-y-3 pt-4 border-t border-slate-100">
        <div class="flex items-center space-x-2">
          <span class="text-xl">💰</span>
          <div>
            <h4 class="text-base font-black text-slate-900">Costos y materiales asociados</h4>
            <p class="text-xs text-slate-500">Materiales utilizados, cálculo automático de subtotales (Cantidad × Costo Unitario) y balance presupuestario.</p>
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-200 text-center">
          <div>
            <p class="text-[10px] text-slate-500 uppercase font-bold">Presupuesto Estimado</p>
            <p class="text-xl font-black text-slate-900">${formatCLP(s.totalEstimatedCost)}</p>
          </div>
          <div>
            <p class="text-[10px] text-slate-500 uppercase font-bold">Gasto / Costo Real</p>
            <p class="text-xl font-black text-blue-700">${formatCLP(s.totalActualCost)}</p>
          </div>
          <div>
            <p class="text-[10px] text-slate-500 uppercase font-bold">Diferencia Presupuestaria</p>
            <p class="text-xl font-black ${s.totalEstimatedCost - s.totalActualCost >= 0 ? 'text-emerald-700' : 'text-rose-700'}">
              ${s.totalEstimatedCost - s.totalActualCost >= 0 ? '+' : ''}${formatCLP(s.totalEstimatedCost - s.totalActualCost)}
            </p>
          </div>
        </div>

        <div>
          <div class="flex items-center justify-between mb-2">
            <span class="text-xs font-black text-slate-800 uppercase">Detalle de Insumos Utilizados</span>
            <span class="text-xs font-extrabold text-blue-700">Total: ${formatCLP(s.totalActualCost)}</span>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            ${s.materials.length === 0 ? `
              <div class="col-span-full p-6 text-center text-xs text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                No se han registrado materiales todavía en las tareas de esta área.
              </div>
            ` : s.materials.map(m => {
              const subtotal = (Number(m.quantity) || 0) * (Number(m.unitCost) || 0);
              return `
                <div class="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
                  <div>
                    <p class="font-extrabold text-slate-900 text-xs">${m.name}</p>
                    <p class="text-[10px] text-slate-500 mt-0.5">Tarea: <span class="font-medium text-slate-700">${m.taskTitle}</span></p>
                  </div>
                  
                  <div class="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span class="text-slate-600">${m.quantity} ${m.unit || 'unid'} × ${formatCLP(m.unitCost)}</span>
                    <span class="font-black text-blue-800">Subtotal: ${formatCLP(subtotal)}</span>
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        </div>
      </div>

      <!-- APARTADO 6: 👷 RESPONSABLE E HISTORIAL -->
      <div class="space-y-3 pt-4 border-t border-slate-100">
        <div class="flex items-center space-x-2">
          <span class="text-xl">👷</span>
          <div>
            <h4 class="text-base font-black text-slate-900">Responsable e historial</h4>
            <p class="text-xs text-slate-500">Supervisión a cargo y registro cronológico de mantenciones e intervenciones anteriores.</p>
          </div>
        </div>

        <div class="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-center space-x-3.5">
          <div class="w-12 h-12 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center text-2xl font-bold flex-shrink-0">
            👷
          </div>
          <div>
            <p class="text-xs font-bold text-slate-500 uppercase">Encargado Asignado del Área</p>
            <h5 class="text-sm font-extrabold text-slate-900">${area.responsible}</h5>
            <p class="text-[11px] text-slate-500 mt-0.5">A cargo de la ejecución, control de materiales y cierre de órdenes en esta unidad operativa.</p>
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          ${s.tasks.map(t => `
            <div class="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
              <div>
                <div class="flex items-center justify-between text-xs mb-1">
                  <span class="font-extrabold text-slate-800">${t.title}</span>
                  <span class="text-[10px] font-bold px-2 py-0.5 rounded-md ${t.status === 'Completada' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700'}">${t.status}</span>
                </div>
                <p class="text-xs text-slate-600 line-clamp-2">${t.description}</p>
              </div>
              <div class="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                <span>📅 ${formatDate(t.startDate)}</span>
                <span>Resp: ${t.responsible}</span>
              </div>
            </div>
          `).join('')}
        </div>
      </div>

      <!-- FOOTER DE CIERRE -->
      <div class="mt-8 pt-4 border-t border-slate-200 flex items-center justify-between">
        <span class="text-xs text-slate-500">Unidad: <strong>${area.name}</strong> • Hotel El Almendro</span>
        <button onclick="closeModal('modal-area-detail')" class="px-6 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-colors">
          Cerrar Ficha
        </button>
      </div>

    </div>
  `;

  openModal('modal-area-detail');
  if (content) content.scrollTop = 0;
}


function renderRoleDropdown() {
  const container = document.getElementById('role-dropdown-items');
  if (!container) return;
  const currentRole = state.currentUser?.role || 'ADMINISTRADOR';
  const rolesList = window.SYSTEM_ROLES || (typeof SYSTEM_ROLES !== 'undefined' ? SYSTEM_ROLES : []);

  container.innerHTML = rolesList.map(r => {
    const isCurrent = currentRole === r.id;
    return `
      <button onclick="switchRole('${r.id}')"
        class="w-full text-left px-3.5 py-2.5 text-xs hover:bg-slate-50 flex items-center space-x-3 transition-colors ${isCurrent ? 'bg-blue-50/80 border-l-4 border-blue-600 font-bold' : ''}">
        <span class="text-xl flex-shrink-0">${r.avatar}</span>
        <div class="truncate">
          <div class="flex items-center space-x-1.5">
            <p class="font-bold text-slate-800 truncate text-xs">${r.name}</p>
            ${isCurrent ? '<span class="text-[9px] bg-blue-600 text-white px-1.5 py-0.5 rounded font-black">ACTIVO</span>' : ''}
          </div>
          <p class="text-[10px] text-slate-500 truncate mt-0.5">${r.description}</p>
        </div>
      </button>
    `;
  }).join('');
}

function toggleRoleDropdown(event) {
  if (event && typeof event.stopPropagation === 'function') event.stopPropagation();
  const dropdown = document.getElementById('role-dropdown');
  const notifDropdown = document.getElementById('notification-dropdown');
  if (!dropdown) return;

  const isHidden = dropdown.classList.contains('hidden');
  if (isHidden) {
    // Si la campana de notificaciones está abierta, cerrarla inmediatamente
    if (notifDropdown) notifDropdown.classList.add('hidden');
    renderRoleDropdown();
    dropdown.classList.remove('hidden');
  } else {
    dropdown.classList.add('hidden');
  }
}

function switchRole(roleId) {
  const rolesList = window.SYSTEM_ROLES || (typeof SYSTEM_ROLES !== 'undefined' ? SYSTEM_ROLES : []);
  const roleConfig = rolesList.find(r => r.id === roleId) || rolesList[0];
  if (!roleConfig) return;

  // Buscar usuario o generar perfil asociado al rol
  let user = state.users.find(u => u.role === roleId);
  if (!user) {
    user = {
      id: `usr_${roleId.toLowerCase()}`,
      name: roleConfig.name,
      role: roleId,
      email: `${roleId.toLowerCase()}@elalmendro.cl`,
      avatar: roleConfig.avatar,
      title: roleConfig.title
    };
    state.users.push(user);
  }

  state.currentUser = user;

  const sName = document.getElementById('sidebar-user-name');
  const sRole = document.getElementById('sidebar-user-role');
  const sAvatar = document.getElementById('sidebar-user-avatar');
  const topBadge = document.getElementById('topbar-role-badge');

  if (sName) sName.textContent = user.name;
  if (sRole) sRole.textContent = user.role;
  if (sAvatar) sAvatar.textContent = user.avatar;
  if (topBadge) {
    topBadge.textContent = user.role;
    topBadge.className = `font-bold px-2 py-0.5 rounded-md text-xs truncate ${roleConfig.badgeClass || 'bg-blue-100 text-blue-700'}`;
  }

  const dropdown = document.getElementById('role-dropdown');
  if (dropdown) dropdown.classList.add('hidden');

  if (typeof updateSidebarVisibility === 'function') updateSidebarVisibility();

  if (typeof hasAccess === 'function' && typeof currentView !== 'undefined' && !hasAccess(currentView, user.role)) {
    currentView = 'dashboard';
    renderCurrentView();
  }

  saveState();
}

function toggleNotificationDropdown(event) {
  if (event && typeof event.stopPropagation === 'function') event.stopPropagation();
  const dropdown = document.getElementById('notification-dropdown');
  const roleDropdown = document.getElementById('role-dropdown');
  if (!dropdown) return;

  const isHidden = dropdown.classList.contains('hidden');
  if (isHidden) {
    // Si el menú de roles está abierto, cerrarlo inmediatamente
    if (roleDropdown) roleDropdown.classList.add('hidden');
    dropdown.classList.remove('hidden');
    if (typeof renderTopbarNotifications === 'function') renderTopbarNotifications();
  } else {
    dropdown.classList.add('hidden');
  }
}
