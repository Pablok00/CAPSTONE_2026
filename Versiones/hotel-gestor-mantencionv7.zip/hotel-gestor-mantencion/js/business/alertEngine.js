// ==========================================================
// CAPA 2: LÓGICA DE NEGOCIO Y DOMINIO (BUSINESS LOGIC LAYER)
// ARCHIVO: alertEngine.js - MOTOR DE SEMÁFORO Y ALERTAS OPERATIVAS
// ==========================================================
// Implementa las reglas de negocio de urgencia, semáforos de
// vencimiento y métricas agregadas por área operativa del hotel.
// ==========================================================

const AlertEngine = {
  /**
   * Fecha de referencia del sistema para el contexto del prototipo.
   */
  getSystemDate() {
    return new Date('2026-08-28T00:00:00');
  },

  /**
   * Formatea una fecha ISO (YYYY-MM-DD) al estándar chileno (DD/MM/YYYY).
   */
  formatDate(dateStr) {
    if (!dateStr) return 'No registrada';
    const [year, month, day] = dateStr.split('T')[0].split('-');
    return `${day}/${month}/${year}`;
  },

  /**
   * Motor de Reglas de Semáforo de Mantenciones:
   * Evalúa la fecha límite contra la fecha del sistema y determina
   * el nivel de criticidad visual (Atrasada, Urgente, Próxima o Normal).
   * 
   * @param {Object} mnt - Objeto de mantención
   * @returns {Object|null} Información de insignia, color y texto de alerta
   */
  getMaintenanceAlert(mnt) {
    if (!mnt || mnt.status === 'Completada' || mnt.status === 'Cancelada') {
      return null;
    }

    const today = this.getSystemDate();
    const limit = new Date(mnt.limitDate + 'T23:59:59');
    const diffTime = limit - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) {
      const daysOverdue = Math.abs(diffDays);
      return {
        level: 'Atrasada',
        badge: daysOverdue === 0 ? 'Vence hoy' : `Atrasada`,
        text: `Venció hace ${daysOverdue} día(s)`,
        badgeClass: 'bg-rose-100 text-rose-800 font-black border border-rose-200'
      };
    } else if (diffDays === 0) {
      return {
        level: 'Urgente',
        badge: 'Vence hoy',
        text: 'Vence hoy mismo',
        badgeClass: 'bg-rose-100 text-rose-800 font-extrabold border border-rose-200'
      };
    } else if (diffDays <= 2) {
      return {
        level: 'Urgente',
        badge: `Urgente (${diffDays}d)`,
        text: `Urgente: faltan ${diffDays} día(s)`,
        badgeClass: 'bg-amber-100 text-amber-800 font-bold border border-amber-200'
      };
    } else if (diffDays <= 7) {
      return {
        level: 'Proxima',
        badge: `Próxima (${diffDays}d)`,
        text: `Próxima: faltan ${diffDays} día(s)`,
        badgeClass: 'bg-blue-100 text-blue-800 font-semibold border border-blue-200'
      };
    }

    return null;
  },

  /**
   * Evalúa la vigencia de la garantía técnica de un activo fijo.
   */
  calculateWarrantyStatus(warranty) {
    if (!warranty || !warranty.validUntil) {
      return { status: 'SinGarantia', badge: 'Sin Garantía', text: 'No registra póliza activa.' };
    }

    const today = this.getSystemDate();
    const end = new Date(warranty.validUntil + 'T23:59:59');
    const diffDays = Math.ceil((end - today) / (1000 * 60 * 60 * 24));

    if (diffDays < 0) {
      return { status: 'Vencida', badge: 'Garantía Vencida', text: `Expiró el ${this.formatDate(warranty.validUntil)}.` };
    } else if (diffDays <= 45) {
      return { status: 'Proxima', badge: 'Por Vencer', text: `Vence pronto (${diffDays} días restantes).` };
    }

    return { status: 'Vigente', badge: 'Garantía Vigente', text: `Amparado hasta el ${this.formatDate(warranty.validUntil)}.` };
  },

  /**
   * Calcula métricas operativas y financieras agregadas para un Área de Trabajo.
   * Agrupa tareas, clasifica por estados y consolida costos de materiales.
   */
  getWorkAreaStats(areaId) {
    const area = (state.workAreas || DEFAULT_WORK_AREAS).find(a => a.id === areaId) || {
      id: areaId,
      name: 'Área',
      icon: '🛠️',
      description: 'Área de trabajo del hotel',
      responsible: 'Roberto Silva'
    };

    const tasks = [];
    let totalEstimatedCost = 0;
    let totalActualCost = 0;
    const materials = [];

    // 1. Mantenciones asignadas
    (state.maintenances || []).forEach(m => {
      if (m.areaId === areaId || m.workAreaId === areaId) {
        tasks.push({
          id: m.id,
          title: m.title,
          type: m.type,
          status: m.status,
          priority: m.priority,
          responsible: m.responsible,
          startDate: m.startDate || m.createdDate,
          limitDate: m.limitDate,
          description: m.description,
          areaName: m.areaName || area.name,
          module: 'mantenciones',
          alert: this.getMaintenanceAlert(m)
        });
        totalEstimatedCost += Number(m.estimatedCost) || 0;
        totalActualCost += Number(m.actualCost) || 0;
        (m.materials || []).forEach(mat => {
          materials.push({ ...mat, taskTitle: m.title, parentType: 'mantencion' });
        });
      }
    });

    // 2. Mejoras asignadas
    if (areaId === 'workarea_mejoras') {
      (state.improvements || []).forEach(imp => {
        tasks.push({
          id: imp.id,
          title: imp.name,
          type: 'Mejora',
          status: imp.status,
          priority: imp.priority || 'Alta',
          responsible: imp.responsible,
          startDate: imp.startDate,
          limitDate: imp.endDate,
          description: imp.description,
          areaName: area.name,
          module: 'mejoras',
          alert: null
        });
        totalEstimatedCost += Number(imp.budget) || 0;
        totalActualCost += Number(imp.actualCost) || 0;
        (imp.materials || []).forEach(mat => {
          materials.push({ ...mat, taskTitle: imp.name, parentType: 'mejora' });
        });
      });
    }

    // 3. Remodelaciones asignadas
    if (areaId === 'workarea_remodelacion') {
      (state.renovations || []).forEach(ren => {
        tasks.push({
          id: ren.id,
          title: `Remodelación: ${ren.space}`,
          type: 'Remodelación',
          status: ren.status,
          priority: 'Alta',
          responsible: ren.responsible,
          startDate: ren.startDate,
          limitDate: ren.endDate,
          description: ren.description,
          areaName: area.name,
          module: 'remodelaciones',
          alert: null
        });
        totalEstimatedCost += Number(ren.budget) || 0;
        totalActualCost += Number(ren.actualCost) || 0;
        (ren.materials || []).forEach(mat => {
          materials.push({ ...mat, taskTitle: ren.space, parentType: 'remodelacion' });
        });
      });
    }

    const counts = {
      active: tasks.filter(t => t.status !== 'Completada' && t.status !== 'Cancelada').length,
      pending: tasks.filter(t => t.status === 'Pendiente').length,
      inProcess: tasks.filter(t => t.status === 'En proceso').length,
      resolved: tasks.filter(t => t.status === 'Completada').length,
      delayed: tasks.filter(t => t.alert && t.alert.level === 'Atrasada').length
    };

    return {
      area,
      tasks,
      counts,
      totalEstimatedCost,
      totalActualCost,
      materials
    };
  }
};

// Exposición global y compatibilidad
window.AlertEngine = AlertEngine;
window.getSystemDate = () => AlertEngine.getSystemDate();
window.formatDate = (d) => AlertEngine.formatDate(d);
window.getMaintenanceAlert = (m) => AlertEngine.getMaintenanceAlert(m);
window.calculateWarrantyStatus = (w) => AlertEngine.calculateWarrantyStatus(w);
window.getWorkAreaStats = (id) => AlertEngine.getWorkAreaStats(id);
