// ==========================================================
// CAPA 2: LÓGICA DE NEGOCIO Y DOMINIO (BUSINESS LOGIC LAYER)
// ARCHIVO: costEngine.js - MOTOR FINANCIERO Y DE COSTOS
// ==========================================================
// Esta capa concentra las reglas de negocio estrictas del hotel:
// 1. Cálculo automático de subtotales (Cantidad × Costo Unitario).
// 2. Cálculo de presupuestos, costos reales y balances.
// 3. Formateo de moneda local oficial (CLP - Peso Chileno).
// ==========================================================

const CostEngine = {
  /**
   * Formatea un valor numérico a moneda local Peso Chileno ($ CLP).
   * @param {number|string} amount 
   * @returns {string} Ejemplo: "$ 1.250.000"
   */
  formatCLP(amount) {
    const num = Number(amount) || 0;
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      maximumFractionDigits: 0
    }).format(num);
  },

  /**
   * Calcula el subtotal exacto de un insumo o material: Cantidad × Costo Unitario.
   * Regla de negocio crítica: Previene errores manuales del operador en terreno.
   * @param {number} quantity 
   * @param {number} unitCost 
   * @returns {number}
   */
  calculateMaterialSubtotal(quantity, unitCost) {
    const qty = Math.max(0, Number(quantity) || 0);
    const cost = Math.max(0, Number(unitCost) || 0);
    return Math.round(qty * cost);
  },

  /**
   * Suma los subtotales de todos los materiales asignados a una orden u obra.
   * @param {Array} materialsList 
   * @returns {number}
   */
  calculateMaterialsTotal(materialsList = []) {
    return materialsList.reduce((acc, m) => {
      const subtotal = this.calculateMaterialSubtotal(m.quantity, m.unitCost);
      m.subtotal = subtotal; // asegurar coherencia en el objeto
      return acc + subtotal;
    }, 0);
  },

  /**
   * Realiza el balance presupuestario: Presupuesto - Costo Real.
   * Determina si hay ahorro (+ saldo favorable) o sobrecosto (- déficit).
   * @param {number} budget 
   * @param {number} actualCost 
   * @returns {{difference: number, isFavorable: boolean, formattedDiff: string}}
   */
  calculateBudgetBalance(budget = 0, actualCost = 0) {
    const b = Number(budget) || 0;
    const a = Number(actualCost) || 0;
    const difference = b - a;
    const isFavorable = difference >= 0;
    return {
      difference,
      isFavorable,
      formattedDiff: `${isFavorable ? '+' : ''}${this.formatCLP(difference)}`
    };
  }
};

// Exposición global y compatibilidad
window.CostEngine = CostEngine;
window.formatCLP = (amount) => CostEngine.formatCLP(amount);
