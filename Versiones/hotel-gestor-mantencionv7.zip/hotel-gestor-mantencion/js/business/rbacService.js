// ==========================================================
// CAPA 2: LÓGICA DE NEGOCIO Y DOMINIO (BUSINESS LOGIC LAYER)
// ARCHIVO: rbacService.js - SERVICIO DE ROLES Y CONTROL DE ACCESO (RBAC)
// ==========================================================
// Implementa el control de acceso basado en roles (Role-Based Access Control)
// garantizando la seguridad, visibilidad y permisos en toda la aplicación.
// ==========================================================

// Configuración Maestra y Escalable de Roles del Sistema
const SYSTEM_ROLES = [
  {
    id: "ADMINISTRADOR",
    name: "Administrador General",
    title: "Administrador General",
    avatar: "👨‍💼",
    badgeClass: "bg-blue-100 text-blue-700 border border-blue-200",
    description: "Acceso total a todo el sistema, presupuestos y configuración",
    defaultUserId: "usr_1",
    permissions: [
      'dashboard', 'mantenciones', 'mejoras', 'remodelaciones', 'activos', 
      'areas', 'fechas-proximas', 'gantt', 'solicitudes', 'notificaciones', 
      'importar', 'configuracion'
    ]
  },
  {
    id: "TECNICO",
    name: "Técnico Mantención",
    title: "Técnico Especialista en Terreno",
    avatar: "👷‍♂️",
    badgeClass: "bg-amber-100 text-amber-700 border border-amber-200",
    description: "Actualizar trabajos asignados, fotos y estados",
    defaultUserId: "usr_3",
    permissions: [
      'dashboard', 'mantenciones', 'mejoras', 'remodelaciones', 'activos', 
      'areas', 'fechas-proximas', 'gantt', 'solicitudes', 'notificaciones'
    ]
  },
  {
    id: "SOLICITANTE",
    name: "Solicitante (Recepción / Mucamas)",
    title: "Recepción / Gobernanta / Mucamas",
    avatar: "👩‍💼",
    badgeClass: "bg-purple-100 text-purple-700 border border-purple-200",
    description: "Ingresar incidentes de pasajeros y consultar estado",
    defaultUserId: "usr_4",
    permissions: [
      'dashboard', 'solicitudes'
    ]
  }
];

const DEFAULT_WORK_AREAS = [
  {
    id: "workarea_general",
    name: "Mantención General",
    icon: "🛠️",
    description: "Tareas rutinarias de mantenimiento integral en habitaciones, pasillos y salones del hotel.",
    bullets: [
      "Tareas rutinarias de mantenimiento.",
      "Habitaciones, pasillos y salones.",
      "Mantenciones generales programadas."
    ],
    color: "blue",
    isPrincipal: true,
    responsible: "Roberto Silva"
  },
  {
    id: "workarea_reactiva",
    name: "Mantención Reactiva",
    icon: "⚡",
    description: "Atención inmediata a fallas imprevistas, fugas, roturas y emergencias reportadas por huéspedes o mucamas.",
    bullets: [
      "Emergencias o fallas que requieren atención inmediata.",
      "Fugas, sifones, artefactos u otros problemas inesperados.",
      "Trabajos que no estaban previamente programados."
    ],
    color: "amber",
    isPrincipal: false,
    responsible: "Manuel Pérez"
  },
  {
    id: "workarea_mejoras",
    name: "Mejoras",
    icon: "🌿",
    description: "Obras nuevas, ampliación de terrazas, pérgolas, zona de quinchos campestres y proyectos de valor.",
    bullets: [
      "Proyectos nuevos o mejoras futuras.",
      "Ejemplo: zona de parrillas, pérgola, iluminación, nuevas instalaciones.",
      "Trabajos planificados para mejorar espacios existentes."
    ],
    color: "emerald",
    isPrincipal: false,
    responsible: "Roberto Silva"
  },
  {
    id: "workarea_remodelacion",
    name: "Remodelación",
    icon: "🏗️",
    description: "Intervención integral y renovación de recintos, suites, pasillos y cómputo automatizado de materiales.",
    bullets: [
      "Renovación o modificación de espacios existentes.",
      "Cambio de materiales, terminaciones o distribución.",
      "Control de materiales y costos asociados a la remodelación."
    ],
    color: "purple",
    isPrincipal: false,
    responsible: "Roberto Silva"
  },
  {
    id: "workarea_maquinas",
    name: "Mantención de Máquinas",
    icon: "⚙️",
    description: "Planta térmica, calderas, generadores eléctricos, cámaras de frío gastronómicas y sistemas de bombeo.",
    bullets: [
      "Revisión y mantenimiento de equipos y maquinaria.",
      "Mantenciones semanales, mensuales o anuales.",
      "Responsable y fechas de revisión asignadas."
    ],
    color: "slate",
    isPrincipal: false,
    responsible: "Manuel Pérez"
  },
  {
    id: "workarea_jardineria",
    name: "Mantención de Jardinería",
    icon: "🌳",
    description: "Cuidado continuo del parque, áreas verdes, piscina y labores de jardinería según estación climática.",
    bullets: [
      "Cuidado y mantenimiento de jardines y áreas verdes.",
      "Trabajos según temporada.",
      "Planificación de labores de invierno y verano."
    ],
    color: "teal",
    isPrincipal: false,
    responsible: "Manuel Pérez"
  }
];

const RbacService = {
  getRoles() {
    return SYSTEM_ROLES;
  },

  getRoleById(roleId) {
    return SYSTEM_ROLES.find(r => r.id === roleId) || SYSTEM_ROLES[0];
  },

  /**
   * Valida si un rol tiene permiso para acceder a una vista determinada.
   * @param {string} viewName 
   * @param {string} roleId 
   * @returns {boolean}
   */
  hasAccess(viewName, roleId) {
    const roleConfig = this.getRoleById(roleId);
    if (!roleConfig) {
      return roleId === 'ADMINISTRADOR' || viewName === 'dashboard';
    }
    return roleConfig.permissions.includes(viewName);
  },

  /**
   * Sincroniza la barra lateral y los elementos de navegación
   * según los permisos del usuario activo.
   */
  updateNavigationVisibility(currentUserRole) {
    document.querySelectorAll('.nav-item').forEach(btn => {
      const viewName = btn.id?.replace('nav-', '');
      if (viewName && !this.hasAccess(viewName, currentUserRole)) {
        btn.classList.add('hidden');
      } else {
        btn.classList.remove('hidden');
      }
    });
  }
};

// Exposición global
window.SYSTEM_ROLES = SYSTEM_ROLES;
window.DEFAULT_WORK_AREAS = DEFAULT_WORK_AREAS;
window.RbacService = RbacService;
window.hasAccess = (v, r) => RbacService.hasAccess(v, r);
