# INFORME TÉCNICO FASE 1: DEFINICIÓN PROYECTO APT

---

**INSTITUCIÓN:** DUOC UC  
**ESCUELA:** ESCUELA DE INFORMÁTICA Y TELECOMUNICACIONES  
**CARRERA:** INGENIERÍA EN INFORMÁTICA / DESARROLLO DE SOFTWARE  
**ASIGNATURA:** CAPSTONE (PROYECTO APLICADO A LA TECNOLOGÍA)  
**SIGLA:** PTY4614  
**SECCIÓN:** 001D  
**SEMANA EVALUATIVA:** SEMANA 4  
**PONDERACIÓN DE LA FASE:** 20% (INFORME 40% / PRESENTACIÓN 60%)  

---

# TÍTULO DEL PROYECTO
### **SISTEMA WEB DE GESTIÓN DE TAREAS, MANTENCIONES, OBRAS Y ACTIVOS FIJOS POR ÁREAS OPERATIVAS (OMM) PARA HOTEL & CENTRO DE EVENTOS EL ALMENDRO**

---

### **EQUIPO DE TRABAJO (GRUPO BPB):**
* **Pablo Gamboa** — Estudiante de Ingeniería en Informática, Duoc UC
* **Benjamín Salinas** — Estudiante de Ingeniería en Informática, Duoc UC
* **Bruno Carpio** — Estudiante de Ingeniería en Informática, Duoc UC

### **DOCENTE GUÍA / COMISIÓN EVALUADORA:**
* Profesor Asignatura Capstone PTY4614

**FECHA DE ENTREGA:** Septiembre de 2026  
**SEDE / CIUDAD:** Santiago de Chile  

---

<div style="page-break-after: always;"></div>

## ÍNDICE GENERAL

1. [RESUMEN EJECUTIVO / ABSTRACT](#abstract--resumen-ejecutivo)
   - 1.1 Resumen Ejecutivo (Español)
   - 1.2 Executive Summary (English)
2. [CAPÍTULO 1: DESCRIPCIÓN Y CONTEXTUALIZACIÓN DEL PROYECTO APT](#capítulo-1-descripción-y-contextualización-del-proyecto-apt)
   - 1.1 Contexto Organizacional de la Empresa: Hotel & Centro de Eventos El Almendro
   - 1.2 Contexto del Desafío y Problemática Operacional Detectada
   - 1.3 Justificación y Relevancia de la Solución Propuesta
   - 1.4 Alcance, Límites y Delimitación de la Solución TI
3. [CAPÍTULO 2: ALINEACIÓN ACADÉMICA, PROFESIONAL Y ESTUDIO DE FACTIBILIDAD](#capítulo-2-alineación-académica-profesional-y-estudio-de-factibilidad)
   - 2.1 Relación del Proyecto APT con las Competencias del Perfil de Egreso
   - 2.2 Relación del Proyecto con los Intereses Profesionales del Equipo
   - 2.3 Argumentación Exhaustiva sobre la Factibilidad del Proyecto
     - 2.3.1 Factibilidad Técnica
     - 2.3.2 Factibilidad Operativa y de Usabilidad
     - 2.3.3 Factibilidad Económica y de Recursos
     - 2.3.4 Factibilidad Temporal en el Marco Semestral Capstone
4. [CAPÍTULO 3: DEFINICIÓN DE OBJETIVOS DEL PROYECTO](#capítulo-3-definición-de-objetivos-del-proyecto)
   - 3.1 Objetivo General
   - 3.2 Objetivos Específicos (Taxonomía SMART)
5. [CAPÍTULO 4: PROPUESTA DE METODOLOGÍA DE TRABAJO Y PLANIFICACIÓN](#capítulo-4-propuesta-de-metodología-de-trabajo-y-planificación)
   - 4.1 Marco Metodológico: Enfoque Ágil Adaptado (Scrum Framework)
   - 4.2 Roles y Responsabilidades del Equipo BPB
   - 4.3 Plan de Trabajo y Cronograma de Ejecución (Carta Gantt 16 Semanas)
   - 4.4 Hitos y Entregables Clave por Fase
6. [CAPÍTULO 5: DETERMINACIÓN Y JUSTIFICACIÓN TÉCNICA DE EVIDENCIAS](#capítulo-5-determinación-y-justificación-técnica-de-evidencias)
   - 5.1 Matriz General de Evidencias de Ingeniería
   - 5.2 Justificación Técnica y Trazabilidad de las Evidencias
7. [CAPÍTULO 6: CUMPLIMIENTO DE INDICADORES DE CALIDAD EN EL DISEÑO DEL PROYECTO](#capítulo-6-cumplimiento-de-indicadores-de-calidad-en-el-diseño-del-proyecto)
   - 6.1 Modelo de Calidad de Software ISO/IEC 25010
   - 6.2 Reglas de Negocio Críticas y Criterios de Aceptación del Hotel
8. [CAPÍTULO 7: INDIVIDUAL CONCLUSIONS (IN ENGLISH)](#capítulo-7-individual-conclusions-strictly-in-english)
   - 7.1 Individual Conclusion: Pablo Gamboa
   - 7.2 Individual Conclusion: Benjamín Salinas
   - 7.3 Individual Conclusion: Bruno Carpio
9. [CAPÍTULO 8: INDIVIDUAL REFLECTIONS (IN ENGLISH)](#capítulo-8-individual-reflections-strictly-in-english)
   - 8.1 Professional Reflection: Pablo Gamboa
   - 8.2 Professional Reflection: Benjamín Salinas
   - 8.3 Professional Reflection: Bruno Carpio
10. [CAPÍTULO 9: REFERENCIAS BIBLIOGRÁFICAS](#capítulo-9-referencias-bibliográficas)
11. [CAPÍTULO 10: ANEXOS TÉCNICOS Y DE INGENIERÍA](#capítulo-10-anexos-técnicos-y-de-ingeniería)
   - Anexo A: Matriz Formal de Requisitos Funcionales y No Funcionales
   - Anexo B: Estructura Operativa de las 6 Áreas de Trabajo y Fichas de Detalle
   - Anexo C: Matriz de Usuarios, Roles y Permisos de Acceso
   - Anexo D: Especificación Visual de Pantallas, Mockups y Flujos de Navegación
   - Anexo E: Diccionario de Datos y Modelo Entidad-Relación (Supabase / PostgreSQL)

---

## ÍNDICE DE TABLAS

* **Tabla 1:** Ficha Técnica Organizacional del Hotel & Centro de Eventos El Almendro.
* **Tabla 2:** Matriz de Alineación entre Competencias del Perfil de Egreso y Componentes del Proyecto.
* **Tabla 3:** Matriz de Intereses Profesionales y Contribución al Proyecto por Integrante.
* **Tabla 4:** Matriz de Factibilidad Multidimensional del Proyecto.
* **Tabla 5:** Objetivos Específicos del Proyecto y Metas Medibles (SMART).
* **Tabla 6:** Distribución de Roles Scrum en el Equipo BPB.
* **Tabla 7:** Cronograma Maestro de Trabajo del Proyecto Capstone (16 Semanas).
* **Tabla 8:** Matriz de Determinación, Justificación y Trazabilidad de Evidencias de Ingeniería.
* **Tabla 9:** Aplicación Práctica del Modelo ISO/IEC 25010 en el Software de Gestión.
* **Tabla 10:** Matriz de Requisitos Funcionales (RF).
* **Tabla 11:** Matriz de Requisitos No Funcionales (RNF).
* **Tabla 12:** Estructura de las 6 Áreas de Trabajo del Sistema.
* **Tabla 13:** Matriz de Roles y Privilegios de Acceso del Sistema.

---

## ÍNDICE DE FIGURAS

* **Figura 1:** Diagrama Conceptual del Flujo de Información Actual vs. Solución Centralizada.
* **Figura 2:** Arquitectura Lógica de Información del Módulo de Gestión OMM.
* **Figura 3:** Diagrama de Transición de Estados de Tareas y Código Semafórico.
* **Figura 4:** Estructura de Navegación Visual por Cuadrícula de Tarjetas y Ficha Expandida.
* **Figura 5:** Diagrama Entidad-Relación del Modelo de Datos Relacional (PostgreSQL / Supabase).

---

<div style="page-break-after: always;"></div>

# ABSTRACT / RESUMEN EJECUTIVO

### 1.1 Resumen Ejecutivo (Español)

El presente informe técnico de ingeniería documenta la Fase 1 del Proyecto Aplicado a la Tecnología (APT), correspondiente a la asignatura Capstone (PTY4614), denominado **"Sistema Web de Gestión de Tareas, Mantenciones, Obras y Activos Fijos por Áreas Operativas"**, diseñado e implementado para la empresa **Hotel & Centro de Eventos El Almendro**. La organización, emplazada en un predio campestre de 31.000 m² en la zona de Buin-Paine, opera 25 habitaciones, salones para 250 personas, terrazas para 600 personas y múltiples subsistemas electromecánicos e hidráulicos.

Actualmente, el hotel enfrenta una severa problemática operativa caracterizada por una gestión 100% manual, dispersa y no estructurada, sustentada en planillas de cálculo estáticas (Excel), anotaciones en papel y mensajería informal vía WhatsApp. Esta condición genera una carencia crítica de trazabilidad en los costos directos de materiales, duplicidad en órdenes de trabajo, pérdida de garantías de maquinaria pesada, retrasos en la respuesta a solicitudes de huéspedes y una nula visibilidad ejecutiva sobre las actividades del Área de Obras, Mantención y Mejoras (OMM).

Para resolver esta problemática, el equipo de desarrollo **BPB** propone y diseña una solución tecnológica web interactiva, moderna y desacoplada, fundamentada en un paradigma de interfaz de usuario centrado en la ergonomía cognitiva y la usabilidad: **navegación visual estricta por cuadrículas de tarjetas interactivas**, prescindiendo de listas de texto convencionales propensas a la desorganización. La arquitectura de información segmenta la operación en **6 áreas especializadas de trabajo**: (1) Mantención General, (2) Mantención Reactiva, (3) Mejoras, (4) Remodelación, (5) Mantención de Máquinas y (6) Mantención de Jardinería. 

La solución incorpora un panel general de indicadores (Dashboard) con métricas en tiempo real, fichas de detalle expandibles por área con 5 módulos de información profunda, una Carta Gantt integrada que consolida proyectos de mantención y obras, cálculo automatizado de costos por insumos materiales (imposibilitando la manipulación arbitraria de cifras), un semáforo visual estandarizado de prioridades (rojo, amarillo y verde) y soporte nativo para Modo Oscuro. El informe demuestra la estricta alineación del proyecto con las 6 competencias del perfil de egreso de la carrera, justifica su factibilidad técnica, operativa, económica y temporal, y establece un marco de gestión ágil (Scrum) estructurado en 16 semanas para garantizar un producto de software robusto, escalable y con altos estándares de calidad ISO/IEC 25010.

---

### 1.2 Executive Summary (English)

This engineering report establishes the technical foundation for Phase 1 of the Capstone Applied Technology Project (APT, Course Code PTY4614), titled **"Web-Based Task, Maintenance, Works, and Fixed Asset Management System by Operational Work Areas"**, tailored for **Hotel & Centro de Eventos El Almendro**. Located within a 31,000 m² country estate in the Buin-Paine agricultural valley, the hotel operates 25 guest rooms, a banquet convention hall for 250 guests, event terraces accommodating up to 600 attendees, and extensive mechanical, hydraulic, and electrical facilities.

Presently, the hotel suffers from operational inefficiencies caused by an entirely manual, fragmented management model relying on isolated spreadsheets (Excel), verbal instructions, and informal messaging apps. This workflow results in a critical lack of material cost traceability, duplicated maintenance tickets, missed warranties on major equipment, sluggish resolution of room guest service requests, and a lack of real-time operational visibility for the Works, Maintenance, and Improvements division (OMM).

To address these vulnerabilities, engineering team **BPB** designed and engineered an interactive, high-performance web platform built upon a human-centered UI paradigm: **strict visual card-based navigation with expandable area sheets**, entirely discarding cluttered, unstructured text lists. The operational core is categorized into **6 specialized work areas**: (1) General Maintenance, (2) Reactive Maintenance, (3) Infrastructure Improvements, (4) Space Remodeling, (5) Machinery Maintenance, and (6) Grounds & Garden Maintenance.

The platform features an executive Dashboard displaying real-time Key Performance Indicators (KPIs), expandable cards with 5 comprehensive data tabs (overview, active tasks, timeline Gantt, itemized costs, and history log), an integrated multi-area Gantt chart, automated material and task cost calculations preventing manual data tampering, a standardized three-color priority status model (Red: Urgent/Critical; Yellow: In progress/Due soon; Green: Completed/Safe), and native Dark Mode support. This document rigorously aligns the project with the 6 graduation competencies of the Software Engineering degree, demonstrates multidimensional feasibility (technical, operational, economic, and schedule-based across a 16-week timeline), and sets up an agile Scrum development workflow targeting ISO/IEC 25010 quality standards.

---

<div style="page-break-after: always;"></div>

# CAPÍTULO 1: DESCRIPCIÓN Y CONTEXTUALIZACIÓN DEL PROYECTO APT

### 1.1 Contexto Organizacional de la Empresa: Hotel & Centro de Eventos El Almendro

El proyecto de ingeniería de software se desarrolla en vinculación directa con la empresa **Hotel & Centro de Eventos El Almendro**, una destacada organización hotelera y gastronómica perteneciente al sector turístico del Valle Central de Chile. La empresa combina servicios de hotelería campestre boutique con la producción masiva de eventos corporativos, matrimonios, seminarios y convenciones de alta concurrencia.

```
+---------------------------------------------------------------------------------------+
|                 HOTEL & CENTRO DE EVENTOS EL ALMENDRO - FICHA TÉCNICA                 |
+---------------------------------------------------------------------------------------+
| Razón Social / Giro:       Hotelería Campestre, Turismo, Centro de Convenciones       |
|                            y Producción Integral de Eventos Corporativos y Sociales   |
| Ubicación Geográfica:      Camino Los Almendros 850, límite comunal entre Buin        |
|                            y Paine, Región Metropolitana (a 40 minutos de Santiago)   |
| Dimensión Territorial:     31.000 m² de terreno (3,1 hectáreas de parque y recintos)  |
| Capacidad Habitacional:    25 habitaciones independientes (cabañas y suites equipadas)|
| Infraestructura Eventos:   • Salón de Eventos Principal con capacidad para 250 pax    |
|                            • Terraza panorámica exterior con capacidad para 600 pax   |
| Áreas de Recreación:       Piscina exterior de gran volumen, quincho central, pérgolas|
| Áreas Industriales:        Cocina industrial para banquetes, cámaras frigoríficas,    |
|                            sala de calderas, generadores diésel y sala de bombas      |
+---------------------------------------------------------------------------------------+
```
*Tabla 1: Ficha Técnica Organizacional del Hotel & Centro de Eventos El Almendro. Fuente: Elaboración propia a partir de datos del levantamiento.*

La envergadura física de 31.000 m² y la diversidad de su oferta comercial imponen una alta exigencia sobre las instalaciones físicas, equipos electrodomésticos, sistemas hidrosanitarios, bombas de impulsión de agua de pozo, calderas de calefacción centralizada, generadores eléctricos de respaldo, sistemas de climatización (HVAC) y conservación agronómica de áreas verdes. Una falla técnica imprevista en medio de un evento con 600 asistentes o en una habitación ocupada representa un severo perjuicio financiero, comercial y reputacional para la organización.

---

### 1.2 Contexto del Desafío y Problemática Operacional Detectada

A través del proceso de levantamiento de requisitos técnicos y entrevistas estructuradas con el personal administrativo, técnico y de recepción, se detectaron tres vectores de dolor críticos en la operación diaria del hotel:

1. **Gestión 100% Manual, Lenta y Desarticulada:**
   Actualmente, el registro de actividades, reportes de fallas y controles preventivos se ejecutan mediante libros de actas manuales en papel, planillas Microsoft Excel desarticuladas y grupos informales de WhatsApp. La información queda fragmentada en dispositivos móviles personales, sin persistencia centralizada, propiciando la pérdida de datos sobre trabajos ejecutados, garantías vencidas y proveedores involucrados.

2. **Falta Crítica de Organización por Áreas Operativas:**
   Las tareas de mantención se administran bajo el esquema de una "lista única de pendientes" (*to-do list* genérica). En esta lista se mezclan indiscriminadamente una fuga de agua crítica en una suite nupcial, el cambio estacional de bulbos florales en los jardines y la cotización de remodelación de un quincho. Esta mezcla desdibuja la urgencia real, sobrecarga al técnico asignado y dificulta evaluar el rendimiento de cada frente de trabajo.

3. **Baja Visibilidad de Gestión, Presupuestos y Trazabilidad de Costos:**
   La dirección del hotel no dispone de un consolidado en tiempo real que permita saber cuánto dinero se ha invertido en repuestos, insumos o contratos externos en el mes en curso. La compra de materiales (ladrillos refractarios, sacos de cemento, pinturas anticorrosivas, accesorios sanitarios) se digita manualmente o se calcula de memoria, impidiendo comparar el presupuesto planificado contra el gasto real de cada obra o reparación.

```
  [ SITUACIÓN ACTUAL: DISPERSIÓN ]                [ SOLUCIÓN PROPUESTA: SISTEMA WEB OMM ]
  
  +-------------------------------+
  | Planillas Excel Desconectadas |----+
  +-------------------------------+    |          +--------------------------------------+
                                       |          |     PLATAFORMA CENTRALIZADA WEB      |
  +-------------------------------+    |          |--------------------------------------|
  | WhatsApp / Llamadas Verbales  |----+---->     |  * Dashboard Ejecutivo con 4 KPIs    |
  +-------------------------------+    |          |  * 6 Áreas de Trabajo en Tarjetas    |
                                       |          |  * Trazabilidad Automática de Costos |
  +-------------------------------+    |          |  * Línea de Tiempo Gantt Unificada   |
  | Anotaciones en Libretas Papel |----+          |  * Alertas Preventivas de Vencimiento|
  +-------------------------------+               +--------------------------------------+
```
*Figura 1: Diagrama Conceptual del Flujo de Información Actual vs. Solución Centralizada. Fuente: Elaboración propia.*

---

### 1.3 Justificación y Relevancia de la Solución Propuesta

La concepción e implementación de este software reviste una relevancia estratégica y operacional de primer orden para el Hotel El Almendro por los siguientes motivos demostrables:

* **Continuidad Operativa y Mitigación de Riesgos:** El mantenimiento predictivo y preventivo de bombas y generadores evita cortes de suministro de agua potable o electricidad durante celebraciones masivas, protegiendo ingresos de alto valor contractual.
* **Trazabilidad Financiera y Transparencia en Materiales:** La automatización del cálculo de costos unitarios y subtotales por partida asegura que cada peso gastado quede imputado al área y tarea correspondiente, erradicando desvíos presupuestarios.
* **Eficiencia en la Respuesta a Huéspedes (SLA):** Al habilitar un módulo exclusivo para el personal de Recepción y Gobernanta, las fallas reportadas por pasajeros son canalizadas formalmente, categorizadas con niveles de urgencia y derivadas al técnico idóneo en segundos.
* **Preservación del Valor Patrimonial de Activos Fijos:** Al gestionar las fichas técnicas, números de serie y vigencia de garantías de los activos del hotel, la empresa evita costear reparaciones que están cubiertas por las pólizas vigentes de los proveedores.

---

### 1.4 Alcance, Límites y Delimitación de la Solución TI

El sistema propuesto cubre integralmente el ciclo de vida de las órdenes de trabajo del **Área de Obras, Mantención y Mejoras (OMM)**, dividiéndose en los siguientes componentes delimitados:

* **Módulo de Dashboard General:** Visualización ejecutiva previa al ingreso a cada área con 4 KPIs en vivo: Tareas Activas (conteo total), Mantenciones Próximas (a 30 días), Costo Acumulado del Mes (en CLP) y Porcentaje de Cumplimiento a Tiempo (%). Incluye gráfica comparativa de distribución de tareas entre las 6 áreas.
* **Módulo de 6 Áreas de Trabajo Estructuradas:** Cuadrícula de tarjetas que representan los 6 pilares de la operación:
  1. *Mantención General:* Tareas rutinarias en habitaciones, salones y pasillos.
  2. *Mantención Reactiva:* Atención inmediata de urgencias sanitarias, eléctricas o locativas.
  3. *Mejoras:* Obras nuevas planificadas (quincho, pérgola, iluminación exterior).
  4. *Remodelación:* Intervenciones en recintos existentes con calculadora de materiales.
  5. *Mantención de Máquinas:* Revisiones periódicas programadas (semanal, mensual, anual) a calderas, bombas y generadores.
  6. *Mantención de Jardinería:* Mantenimiento estacional de las 3,1 hectáreas de áreas verdes y piscinas.
* **Ficha de Detalle de Área Expandida:** Al pulsar cualquier tarjeta, el sistema despliega una ficha con 5 sub-vistas: Descripción y alcance, Tareas activas y estado, Línea de tiempo Gantt individual, Registro de materiales y costos, y Responsables con bitácora histórica.
* **Línea de Tiempo Gantt Unificada:** Cronograma visual interactivo que sincroniza mantenciones, obras y remodelaciones en un calendario continuo, destacando eventos con alertas de vencimiento y emergencias reactivas con prioridad alta.
* **Control de Costos y Materiales:** Módulo con cálculo aritmético automático de `Cantidad * Costo Unitario = Subtotal`, consolidando el presupuesto total del proyecto sin intervención manual en los totales.
* **Gestión de Solicitudes y Activos Fijos:** Bandeja de entrada de incidentes para recepción con conversión de solicitudes a órdenes de trabajo formales y módulo de inventario de activos con control de garantías.
* **Límites de la Fase 1:** La solución en esta primera etapa se enfoca en el prototipo arquitectural web funcional de alta fidelidad, la validación de la interfaz con usuarios reales y la modelación del esquema relacional en base de datos PostgreSQL, sin involucrar aún pasarelas de pago de terceros ni módulos de facturación contable tributaria directa (los cuales corresponden a sistemas ERP contables externos del hotel).

---

<div style="page-break-after: always;"></div>

# CAPÍTULO 2: ALINEACIÓN ACADÉMICA, PROFESIONAL Y ESTUDIO DE FACTIBILIDAD

### 2.1 Relación del Proyecto APT con las Competencias del Perfil de Egreso

El desarrollo del Sistema de Gestión para el Hotel El Almendro constituye una aplicación integral de las competencias terminales declaradas en el Perfil de Egreso de la carrera de Ingeniería en Informática / Desarrollo de Software de Duoc UC. A continuación, se detalla la correspondencia exacta entre cada competencia formal y la solución técnica desarrollada:

```
+-------------------------------------------------------------+-------------------------------------------------------------+
| COMPETENCIA DEL PERFIL DE EGRESO (DUOC UC)                  | APLICACIÓN PRÁCTICA Y TÉCNICA EN EL PROYECTO APT            |
+-------------------------------------------------------------+-------------------------------------------------------------+
| 1. "Diseñar y generar soluciones de software innovadoras    | • Concepción de una arquitectura de software limpia y       |
|    y de calidad, aplicando el ciclo de vida de éste, según  |   modularizada en capas (Vistas, Controladores de Estado,   |
|    las características del proyecto, las mejores prácticas  |   Modales y Almacenamiento desacoplado).                    |
|    de la industria y sus estándares de calidad."            | • Adopción de buenas prácticas de clean code, nombrado      |
|                                                             |   semántico, separación de responsabilidades y estándares    |
|                                                             |   de calidad ISO/IEC 25010 en usabilidad y mantenibilidad.  |
+-------------------------------------------------------------+-------------------------------------------------------------+
| 2. "Diseñar y generar soluciones que permitan resolver los  | • Diseño del esquema relacional en PostgreSQL / Supabase    |
|    requerimientos de información en el contexto de las      |   mediante `schema.json` con 8 entidades normalizadas:      |
|    organizaciones, considerando bases de datos relacionales |   `areas`, `assets`, `asset_history`, `maintenances`,       |
|    y no relacionales."                                      |   `improvements`, `renovations`, `renovation_materials` y   |
|                                                             |   `requests`, garantizando integridad referencial y ACID.   |
|                                                             | • Almacenamiento local desacoplado (LocalState) reactivo.   |
+-------------------------------------------------------------+-------------------------------------------------------------+
| 3. "Diseñar y adaptar los procesos de ingeniería de         | • Levantamiento exhaustivo de requisitos con metodologías   |
|    requisitos, a través del uso de metodologías de          |   ágiles: Historias de Usuario con Criterios de Aceptación  |
|    vanguardia y estándares de la industria, para el         |   en formato Gherkin (Dado-Cuando-Entonces).                |
|    desarrollo de soluciones TI complejas, innovadoras y     | • Especificación formal de requisitos bajo estándar IEEE 830|
|    de calidad."                                             |   (16 Requisitos Funcionales y 8 No Funcionales validados). |
+-------------------------------------------------------------+-------------------------------------------------------------+
| 4. "Evaluar y gestionar proyectos en su área de             | • Gestión integral del ciclo de vida bajo marco de trabajo  |
|    especialización profesional, durante todo el ciclo de    |   Scrum adaptado, con Sprints quincenales, planificación    |
|    vida, de acuerdo a buenas prácticas y utilizando         |   de entregables, reuniones de revisión y retrospectiva.    |
|    metodologías y herramientas de software, para cumplir con| • Plan de trabajo estructurado en 16 semanas mediante       |
|    los requerimientos de la organización en contextos       |   Carta Gantt, gestión de riesgos y control de avance.      |
|    tradicionales y ágiles."                                 |                                                             |
+-------------------------------------------------------------+-------------------------------------------------------------+
| 5. "Diseñar soluciones de software, abarcando todo el ciclo | • Implementación de un modelo de autenticación y roles de   |
|    de vida de éste, de acuerdo a estándares, marcos de      |   seguridad RBAC (Administrador, Jefa Mantención, Técnico,  |
|    trabajo y regulatorios, tecnologías y metodologías que   |   Solicitante Recepción) con permisos diferenciados.        |
|    promueven la innovación, con foco en la calidad,         | • Sistema de validación estricta que previene inconsistencias|
|    seguridad y sostenibilidad del proyecto."                |   financieras (cálculo de costos forzado por motor lógico). |
+-------------------------------------------------------------+-------------------------------------------------------------+
| 6. "Desarrollar proyectos de software innovadores para      | • Diseño de interfaz con enfoque "Mobile-First / Responsive |
|    plataformas y dispositivos móviles, por medio de marcos  |   Web Design" mediante Tailwind CSS, optimizado para tablets|
|    de trabajo, herramientas de desarrollo, lenguajes de     |   y teléfonos inteligentes de los técnicos en terreno.      |
|    programación y buenas prácticas de la industria del      | • Implementación de navegación basada en gestos táctiles y  |
|    desarrollo de software."                                 |   tarjetas de gran tamaño ergonómico con soporte Dark Mode. |
+-------------------------------------------------------------+-------------------------------------------------------------+
```
*Tabla 2: Matriz de Alineación entre Competencias del Perfil de Egreso y Componentes del Proyecto. Fuente: Elaboración propia.*

---

### 2.2 Relación del Proyecto con los Intereses Profesionales del Equipo

El proyecto APT representa una oportunidad sinérgica para consolidar los intereses de especialización profesional y los roles de carrera de los miembros del equipo **BPB**:

```
+-------------------+--------------------------------+---------------------------------------------------------------+
| INTEGRANTE        | INTERÉS PROFESIONAL            | ROL Y CONTRIBUCIÓN CLAVE EN EL PROYECTO                       |
+-------------------+--------------------------------+---------------------------------------------------------------+
| Pablo Gamboa      | Arquitectura de Software,      | Responsable de la estructura de datos relacional, modelamiento|
|                   | Backend & Modelamiento de Datos| en PostgreSQL/Supabase, definición del esquema `schema.json` y |
|                   |                                | diseño de los algoritmos de cálculo automatizado de costos.   |
+-------------------+--------------------------------+---------------------------------------------------------------+
| Benjamín Salinas  | Frontend Engineering, Diseño   | Encargado del diseño de interacción, ergonomía visual mediante|
|                   | de Sistemas UI/UX y Usabilidad | cuadrículas de tarjetas, implementación de Tailwind CSS,     |
|                   |                                | componentes modales interactivos y soporte para Modo Oscuro.  |
+-------------------+--------------------------------+---------------------------------------------------------------+
| Bruno Carpio      | Liderazgo Técnico, Gestión de  | Coordinador del ciclo de vida bajo marco Scrum, aseguramiento |
|                   | Proyectos Ágiles & QA Software | de la calidad según ISO 25010, definición de la Carta Gantt,   |
|                   |                                | pruebas de usuario en terreno y gestión de requerimientos.    |
+-------------------+--------------------------------+---------------------------------------------------------------+
```
*Tabla 3: Matriz de Intereses Profesionales y Contribución al Proyecto por Integrante. Fuente: Elaboración propia.*

---

### 2.3 Argumentación Exhaustiva sobre la Factibilidad del Proyecto

Para demostrar la viabilidad integral de la solución en el marco de la asignatura Capstone, se evaluaron cuatro dimensiones críticas de factibilidad:

```
                              ESTUDIO DE FACTIBILIDAD MULTIDIMENSIONAL
                                                 |
         +-------------------+-------------------+-------------------+-------------------+
         |                   |                   |                   |                   |
         v                   v                   v                   v                   v
   [ TÉCNICA ]         [ OPERATIVA ]       [ ECONÓMICA ]       [ TEMPORAL ]        [ AMBIENTAL ]
   HTML5/ES6/CSS3      Ergonomía UI        Cero Licencias      16 Semanas          Paperless
   PostgreSQL/Cloud    Curva Mínima        Costos Mínimos      Hitos Alineados     Sostenible
```

#### 2.3.1 Factibilidad Técnica
* **Stack Tecnológico Ligero y Maduro:** La arquitectura implementa HTML5 semántico, JavaScript moderno (ES6+ modular) y Tailwind CSS. No requiere librerías complejas que añadan deuda técnica o sobrecarga de procesamiento, lo cual garantiza una carga instantánea y compatibilidad universal con navegadores (Chrome, Safari, Edge, Firefox).
* **Persistencia Robusta y Escalable:** La base de datos está proyectada sobre PostgreSQL / Supabase, aprovechando relaciones con clave foránea, triggers para cálculo de totales y almacenamiento de fotografías de fallas técnicas en Cloud Storage.
* **Compatibilidad de Dispositivos:** El diseño es completamente adaptable (*responsive*), permitiendo al personal de recepción utilizarlo desde computadores de escritorio y a los técnicos de mantención desde sus teléfonos celulares o tablets en terreno mientras recorren las 3,1 hectáreas del hotel.

#### 2.3.2 Factibilidad Operativa y de Usabilidad
* **Superación de la Resistencia al Cambio:** El personal de mantención en hotelería suele mostrar rechazo a los sistemas informáticos tradicionales con menús jerárquicos complejos o planillas densas. Al sustituir las listas por **tarjetas cuadradas de navegación táctil con emojis semánticos y colores de semáforo intuitivos**, la curva de aprendizaje se reduce a menos de 30 minutos.
* **Alineación con el Organigrama Real:** Los flujos del sistema reflejan con exactitud los roles del hotel: la Gobernanta crea una solicitud sencilla con 3 clics; la Jefa de Operaciones la convierte en orden de trabajo y asigna recursos; el Técnico revisa sus órdenes asignadas y actualiza el estado a "Completado".

#### 2.3.3 Factibilidad Económica y de Recursos
* **Inexistencia de Costos de Licenciamiento:** El stack de desarrollo se fundamenta en tecnologías de código abierto (*Open Source*), lo que evita la adquisición de licencias comerciales gravosas de software privativo (como SAP o Microsoft Dynamics).
* **Infraestructura en la Nube de Bajo Costo:** Los servicios requeridos para el despliegue (Netlify / Vercel para frontend y capa gratuita/comunitaria de Supabase para backend) permiten operar el sistema con un costo financiero de $0 CLP durante la fase de desarrollo, y un costo operativo mensual despreciable durante la puesta en producción.

#### 2.3.4 Factibilidad Temporal en el Marco Semestral Capstone
* **Planificación Controlada:** El calendario de 16 semanas de la asignatura Capstone ha sido dimensionado con holguras en la fase de codificación. La Semana 4 consolida la arquitectura y definición del proyecto; las Semanas 5 a 8 completan el diseño detallado y backend; las Semanas 9 a 12 concentran la integración del prototipo navegable completo; y las Semanas 13 a 16 se destinan a pruebas de usabilidad, afinamiento y defensa del proyecto.

```
+-------------------+-----------------------------------+-----------------------------------+--------------------+
| DIMENSIÓN         | REQUERIMIENTO PRINCIPAL           | FACTOR RESOLUTIVO DEL EQUIPO      | ESTADO FACTIBILIDAD|
+-------------------+-----------------------------------+-----------------------------------+--------------------+
| Factibilidad      | Compatibilidad cross-browser y    | JavaScript Vanilla ES6 modular,   | VIABLE (100%)      |
| Técnica           | bajo consumo de recursos en móvil | Tailwind CSS y Supabase Cloud     |                    |
+-------------------+-----------------------------------+-----------------------------------+--------------------+
| Factibilidad      | Adopción por parte de personal no | UI basada en tarjetas visuales,   | VIABLE (100%)      |
| Operativa         | técnico de hotelería              | emojis y colores de advertencia   |                    |
+-------------------+-----------------------------------+-----------------------------------+--------------------+
| Factibilidad      | Presupuesto asignado al proyecto  | Stack Open Source sin costo de    | VIABLE (100%)      |
| Económica         | igual a $0 CLP en desarrollo      | licencias propietarias            |                    |
+-------------------+-----------------------------------+-----------------------------------+--------------------+
| Factibilidad      | Plazo de ejecución improrrogable  | Gestión ágil Scrum acotada a      | VIABLE (100%)      |
| Temporal          | de 16 semanas académicas          | 8 Sprints de dos semanas          |                    |
+-------------------+-----------------------------------+-----------------------------------+--------------------+
```
*Tabla 4: Matriz de Factibilidad Multidimensional del Proyecto. Fuente: Elaboración propia.*

---

<div style="page-break-after: always;"></div>

# CAPÍTULO 3: DEFINICIÓN DE OBJETIVOS DEL PROYECTO

### 3.1 Objetivo General

> **Diseñar, desarrollar e implementar un sistema web interactivo de gestión centralizada para el Área de Obras, Mantención y Mejoras (OMM) del Hotel & Centro de Eventos El Almendro, fundamentado en una arquitectura de navegación visual por cuadrícula de tarjetas, que permita digitalizar y automatizar el registro de tareas en 6 áreas operativas, el cálculo automático de costos de materiales, el seguimiento temporal mediante Carta Gantt y la gestión de garantías de activos fijos, optimizando los tiempos de respuesta y asegurando la continuidad operacional del recinto durante el segundo semestre de 2026.**

---

### 3.2 Objetivos Específicos (Taxonomía SMART)

Los objetivos específicos han sido estructurados de acuerdo con los criterios SMART (Específicos, Medibles, Alcanzables, Relevantes y Temporales) para guiar rigurosamente las cuatro fases de ingeniería:

```
+----+---------------------------------------------------------------+-------------------------------------------------+----------------+
| N° | OBJETIVO ESPECÍFICO                                           | INDICADOR DE LOGRO / META MEDIBLE               | SEMANA LÍMITE  |
+----+---------------------------------------------------------------+-------------------------------------------------+----------------+
| OE1| Diagnosticar los procesos actuales de levantamiento de fallas | Documento SRS (IEEE 830) aprobado con 100% de   | Semana 4       |
|    | y compras de materiales mediante entrevistas estructuradas    | los flujos operacionales levantados y validados | (Fase 1)       |
|    | con las jefaturas y personal del Hotel El Almendro.           | por el stakeholder.                             |                |
+----+---------------------------------------------------------------+-------------------------------------------------+----------------+
| OE2| Diseñar la arquitectura del sistema y el modelo de datos      | Esquema relacional `schema.json` estructurado   | Semana 7       |
|    | relacional en PostgreSQL/Supabase, normalizando las entidades | en 3ra Forma Normal (3NF) con integridad        | (Fase 2)       |
|    | de áreas, tareas, activos, materiales y solicitudes.          | referencial sin redundancias de datos.          |                |
+----+---------------------------------------------------------------+-------------------------------------------------+----------------+
| OE3| Construir una interfaz de usuario accesible y responsiva      | Prototipo con 100% de navegación por tarjetas,  | Semana 10      |
|    | orientada a tarjetas interactivas, integrando el Dashboard de | sin listas de texto plano, con semáforo de      | (Fase 3)       |
|    | 4 KPIs, las 6 fichas expandidas y el soporte de Modo Oscuro.  | estados y compatibilidad móvil comprobada.      |                |
+----+---------------------------------------------------------------+-------------------------------------------------+----------------+
| OE4| Implementar el motor de cálculo automático de presupuestos y  | Precisión del 100% en el cálculo de subtotales  | Semana 12      |
|    | costos de materiales, impidiendo la digitación manual de      | y totales, eliminando cualquier discrepancia    | (Fase 3)       |
|    | totales para garantizar trazabilidad contable fidedigna.      | aritmética en las órdenes de trabajo.           |                |
+----+---------------------------------------------------------------+-------------------------------------------------+----------------+
| OE5| Integrar la Carta Gantt interactiva y el centro de alertas de | Generación automática de notificaciones ante    | Semana 14      |
|    | vencimiento a 60, 30, 15 y 7 días para mantenciones de equipos| tareas críticas y vencimiento inminente de      | (Fase 4)       |
|    | críticos y pólizas de garantías de activos fijos.             | garantías comerciales de proveedores.           |                |
+----+---------------------------------------------------------------+-------------------------------------------------+----------------+
| OE6| Validar la usabilidad, rendimiento y conformidad del sistema  | Obtención de un índice System Usability Scale   | Semana 16      |
|    | con usuarios finales del hotel, asegurando el cumplimiento de | (SUS) >= 85 puntos y 0 defectos bloqueantes     | (Fase 4)       |
|    | los estándares de calidad de software ISO/IEC 25010.          | en el entorno de pruebas de aceptación.         |                |
+----+---------------------------------------------------------------+-------------------------------------------------+----------------+
```
*Tabla 5: Objetivos Específicos del Proyecto y Metas Medibles (SMART). Fuente: Elaboración propia.*

---

<div style="page-break-after: always;"></div>

# CAPÍTULO 4: PROPUESTA DE METODOLOGÍA DE TRABAJO Y PLANIFICACIÓN

### 4.1 Marco Metodológico: Enfoque Ágil Adaptado (Scrum Framework)

Considerando la naturaleza evolutiva de los requerimientos en el sector hotelero y la necesidad de recibir retroalimentación temprana por parte de los usuarios operativos de El Almendro, se seleccionó el marco ágil **Scrum adaptado**. Este enfoque combina la entrega incremental de incrementos de software potencialmente desplegables con el rigor de la ingeniería de software exigida en el proyecto Capstone.

```
       CICLO DE VIDA ITERATIVO SCRUM ADAPTADO (SPRINTS DE 2 SEMANAS)
       
  +----------------+     Sprint Planning      +-------------------+
  | Product Backlog| -----------------------> |   Sprint Backlog  |
  +----------------+                          +-------------------+
          ^                                             |
          |                                             v
          |                                   +-------------------+
          |                                   |  Sprint (2 sem.)  | <--- Daily Standups (15 min)
          |                                   +-------------------+
          |                                             |
          |       Sprint Review & Retrospective         v
          +----------------------------------- +-------------------+
                                               | Incremento de SW  |
                                               +-------------------+
```

#### Elementos Clave de la Metodología:
1. **Duración de los Sprints:** Sprints quincenales (2 semanas de duración cada uno), estructurados a lo largo de las 16 semanas académicas (total de 8 Sprints).
2. **Ceremonias Ágiles Adaptadas:**
   * *Sprint Planning:* Definición de objetivos e Historias de Usuario a abordar al inicio de cada quincena.
   * *Daily Standup (Asíncrono / Semipresencial):* Puesta en común diaria de 15 minutos respondiendo a: ¿Qué avancé ayer?, ¿Qué haré hoy? y ¿Existe algún bloqueo técnico?
   * *Sprint Review:* Demostración del prototipo funcional con los directivos y personal del hotel para recibir *feedback* constructivo.
   * *Sprint Retrospective:* Análisis interno del equipo BPB para perfeccionar prácticas de codificación y trabajo colaborativo.
3. **Herramientas de Gestión:** Tablero virtual tipo Kanban en GitHub Projects para seguimiento de tareas, control de versiones mediante Git y reuniones de alineación mediante Discord y Google Meet.

---

### 4.2 Roles y Responsabilidades del Equipo BPB

La distribución de responsabilidades en el equipo asegura que todas las actividades del ciclo de vida queden asignadas formalmente sin vacíos de liderazgo:

```
+-------------------+--------------------+--------------------------------------------------------------------------+
| INTEGRANTE        | ROL METODOLÓGICO   | RESPONSABILIDADES Y ÁREAS DE ACCIÓN ESPECÍFICAS                          |
+-------------------+--------------------+--------------------------------------------------------------------------+
| Bruno Carpio      | Scrum Master &     | • Velar por el cumplimiento de las ceremonias y plazos del cronograma.   |
|                   | QA Lead            | • Facilitar la comunicación con la comisión evaluadora de Duoc UC.       |
|                   |                    | • Diseñar los planes de pruebas y verificar métricas ISO/IEC 25010.      |
+-------------------+--------------------+--------------------------------------------------------------------------+
| Pablo Gamboa      | Product Owner &    | • Gestionar y priorizar las Historias de Usuario en el Product Backlog.   |
|                   | Data Architect     | • Diseñar y mantener el esquema relacional en PostgreSQL / Supabase.     |
|                   |                    | • Validar las reglas de cálculo financiero y consistencia de datos.      |
+-------------------+--------------------+--------------------------------------------------------------------------+
| Benjamín Salinas  | Lead Frontend Dev &| • Liderar el diseño de la interfaz de usuario (UI) y la experiencia (UX).|
|                   | UX/UI Designer     | • Implementar las vistas en JavaScript modular, Tailwind CSS y animaciones.|
|                   |                    | • Garantizar la adaptabilidad móvil y la navegación visual por tarjetas. |
+-------------------+--------------------+--------------------------------------------------------------------------+
```
*Tabla 6: Distribución de Roles Scrum en el Equipo BPB. Fuente: Elaboración propia.*

---

### 4.3 Plan de Trabajo y Cronograma de Ejecución (Carta Gantt 16 Semanas)

El proyecto se distribuye a lo largo de las 16 semanas lectivas del semestre académico Capstone, articulado en torno a las 4 Fases de Evaluación oficiales:

```
+-------------------------------------------------------------+----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+
| FASE Y ACTIVIDAD DE INGENIERÍA                              | S1 | S2 | S3 | S4 | S5 | S6 | S7 | S8 | S9 | S10| S11| S12| S13| S14| S15| S16|
+-------------------------------------------------------------+----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+
| FASE 1: DEFINICIÓN PROYECTO APT (Semana 1 a 4)              |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |
| • Levantamiento de requerimientos y visitas a El Almendro   | XX | XX |    |    |    |    |    |    |    |    |    |    |    |    |    |    |
| • Análisis de viabilidad y definición del alcance del software|  | XX | XX |    |    |    |    |    |    |    |    |    |    |    |    |    |
| • Prototipado inicial y definición de las 6 áreas de trabajo|    |    | XX | XX |    |    |    |    |    |    |    |    |    |    |    |    |
| • HITO 1: Entrega Informe Fase 1 y Presentación PPT (20%)   |    |    |    | ** |    |    |    |    |    |    |    |    |    |    |    |    |
+-------------------------------------------------------------+----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+
| FASE 2: DISEÑO Y ARQUITECTURA DE SOFTWARE (Semana 5 a 8)    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |
| • Modelado Entidad-Relación y script SQL Supabase / Postgres|    |    |    |    | XX | XX |    |    |    |    |    |    |    |    |    |    |
| • Diseño UI/UX de alta fidelidad (cuadrícula tarjetas)      |    |    |    |    |    | XX | XX |    |    |    |    |    |    |    |    |    |
| • Arquitectura modular de vistas JavaScript (app.js, state) |    |    |    |    |    |    | XX | XX |    |    |    |    |    |    |    |    |
| • HITO 2: Evaluación Fase 2 - Arquitectura y Prototipo (25%)|    |    |    |    |    |    |    | ** |    |    |    |    |    |    |    |    |
+-------------------------------------------------------------+----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+
| FASE 3: CONSTRUCCIÓN E INTEGRACIÓN (Semana 9 a 12)          |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |
| • Desarrollo del Dashboard con 4 KPIs y lógica de cálculo   |    |    |    |    |    |    |    |    | XX | XX |    |    |    |    |    |    |
| • Programación de fichas expandidas y calculadora materiales|    |    |    |    |    |    |    |    |    | XX | XX |    |    |    |    |    |
| • Implementación de Carta Gantt integrada y alertas prevent.|    |    |    |    |    |    |    |    |    |    | XX | XX |    |    |    |    |
| • HITO 3: Evaluación Fase 3 - Producto Integrado (25%)      |    |    |    |    |    |    |    |    |    |    |    | ** |    |    |    |    |
+-------------------------------------------------------------+----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+
| FASE 4: PRUEBAS, VALIDACIÓN Y CIERRE (Semana 13 a 16)       |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |
| • Pruebas de usabilidad en terreno con técnicos y recepción |    |    |    |    |    |    |    |    |    |    |    |    | XX | XX |    |    |
| • Pruebas de calidad y accesibilidad ISO/IEC 25010          |    |    |    |    |    |    |    |    |    |    |    |    |    | XX | XX |    |
| • Corrección de observaciones, despliegue y manual técnico  |    |    |    |    |    |    |    |    |    |    |    |    |    |    | XX | XX |
| • HITO FINAL: Evaluación Fase 4 - Defensa de Título (30%)   |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    | ** |
+-------------------------------------------------------------+----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+
```
*Tabla 7: Cronograma Maestro de Trabajo del Proyecto Capstone (16 Semanas). Fuente: Elaboración propia.*

---

### 4.4 Hitos y Entregables Clave por Fase

* **Hito 1 (Semana 4 - Fase 1 - Ponderación 20%):** Aprobación del Acta de Definición del Proyecto, Especificación de Requisitos, Prototipo Preliminar y Validación de Factibilidad con la empresa.
* **Hito 2 (Semana 8 - Fase 2 - Ponderación 25%):** Entrega de la Arquitectura de Software, Diagrama Entidad-Relación normalizado, endpoints y diseño interactivo validado.
* **Hito 3 (Semana 12 - Fase 3 - Ponderación 25%):** Entrega del Software Funcional con las 6 áreas operativas interconectadas, motor de cálculo de materiales operativo y Gantt integrado.
* **Hito 4 (Semana 16 - Fase 4 - Ponderación 30%):** Aceptación formal por parte del Hotel El Almendro, informe final de aseguramiento de calidad y Defensa Pública del Proyecto de Título.

---

<div style="page-break-after: always;"></div>

# CAPÍTULO 5: DETERMINACIÓN Y JUSTIFICACIÓN TÉCNICA DE EVIDENCIAS

### 5.1 Matriz General de Evidencias de Ingeniería

Para dar cumplimiento formal al estándar académico de la asignatura Capstone, se ha determinado un conjunto articulado de evidencias que sustentan las decisiones técnicas tomadas:

```
+----+---------------------------------------+-----------------------+---------------------------------------------------------+
| CÓD| NOMBRE DE LA EVIDENCIA TÉCNICA        | SOPORTE / FORMATO     | DESCRIPCIÓN Y CONTENIDO TÉCNICO ASOCIADO                |
+----+---------------------------------------+-----------------------+---------------------------------------------------------+
| E-1| Acta de Levantamiento de Requerimientos| Documento PDF firmado | Registro de entrevistas con Roberto Silva (Admin) y      |
|    | y Reunión con Stakeholders            | y minutas de trabajo  | Carolina Morales (Operaciones), detallando dolores reales|
+----+---------------------------------------+-----------------------+---------------------------------------------------------+
| E-2| Especificación de Requisitos de       | Documento IEEE 830    | Catálogo completo de 16 Requisitos Funcionales y        |
|    | Software (SRS) Formal                 | en Markdown / PDF     | 8 No Funcionales clasificados por criticidad.           |
+----+---------------------------------------+-----------------------+---------------------------------------------------------+
| E-3| Prototipo Web Funcional e Interactivo | Aplicación Web        | Código fuente ejecutable (`index.html`, `dashboard.js`, |
|    | (Prueba de Concepto y Mockups)        | HTML5 / CSS / JS      | `areas.js`) con navegación completa por tarjetas.       |
+----+---------------------------------------+-----------------------+---------------------------------------------------------+
| E-4| Esquema de Base de Datos y Modelo E-R | Archivo `schema.json` | Definición formal de tablas, tipos de datos, llaves     |
|    | para Supabase / PostgreSQL            | y Diagrama E-R        | foráneas y campos autogenerados de costos.              |
+----+---------------------------------------+-----------------------+---------------------------------------------------------+
| E-5| Repositorio de Control de Versiones   | Repositorio Git       | Historial de commits estructurado por módulos con       |
|    | (Git y GitHub)                        | institucional         | ramas de características (`feature branches`).          |
+----+---------------------------------------+-----------------------+---------------------------------------------------------+
| E-6| Matriz de Trazabilidad de Pruebas     | Hoja de cálculo de    | Validación de casos de prueba unitarios para el cálculo |
|    | de Calidad y Criterios de Aceptación  | casos de prueba       | automático de materiales y alertas de vencimiento.      |
+----+---------------------------------------+-----------------------+---------------------------------------------------------+
```
*Tabla 8: Matriz de Determinación, Justificación y Trazabilidad de Evidencias de Ingeniería. Fuente: Elaboración propia.*

---

### 5.2 Justificación Técnica y Trazabilidad de las Evidencias

Cada evidencia seleccionada cumple un propósito metodológico insustituible dentro del proceso de ingeniería:

1. **Justificación de E-1 (Actas de Levantamiento):** Proporciona validez empírica y garantiza que el proyecto no se fundamente en supuestos abstractos, sino en las necesidades reales del predio campestre de 31.000 m² de El Almendro.
2. **Justificación de E-2 (SRS IEEE 830):** Constituye el "contrato de ingeniería" que vincula los requerimientos de la organización con la evaluación académica, asegurando una trazabilidad bidireccional entre la problemática y las funcionalidades.
3. **Justificación de E-3 (Prototipo Web Funcional):** En hotelería, donde el personal rota o no cuenta con perfiles informáticos avanzados, la prueba de concepto visual es la única forma confiable de corroborar que el diseño basado en tarjetas y emojis resulta más intuitivo y rápido que las planillas tradicionales.
4. **Justificación de E-4 (Esquema de Base de Datos Relacional):** Asegura que el software soporte escalabilidad futura sin generar anomalías de inserción, actualización o borrado, garantizando que el historial de mantenimiento y compras de materiales no se corrompa.
5. **Justificación de E-5 (Control de Versiones Git):** Permite fiscalizar la contribución individual equitativa de cada integrante del equipo BPB y asegura la resiliencia del código ante errores de desarrollo.
6. **Justificación de E-6 (Matriz de Pruebas):** Garantiza que reglas de negocio críticas —tales como la prohibición de modificar manualmente el costo total de una obra o el disparo de alertas de garantía a 60 días— funcionen con precisión matemática infalible.

---

<div style="page-break-after: always;"></div>

# CAPÍTULO 6: CUMPLIMIENTO DE INDICADORES DE CALIDAD EN EL DISEÑO DEL PROYECTO

### 6.1 Modelo de Calidad de Software ISO/IEC 25010

El diseño y desarrollo del sistema web se guían por las 8 características fundamentales de calidad establecidas por el estándar internacional **ISO/IEC 25010 (System and Software Quality Models)**:

```
+---------------------------+-----------------------------------------------------------------------------------------------+
| CARACTERÍSTICA ISO 25010  | CRITERIO APLICADO Y MECANISMO DE ASEGURAMIENTO EN EL PROYECTO                                 |
+---------------------------+-----------------------------------------------------------------------------------------------+
| 1. Adecuación Funcional   | • Completitud, corrección y pertinencia en las 6 áreas de mantención y obras.                 |
|                           | • Cálculo matemático exacto de insumos de remodelación: `subtotal = cantidad * precio_unit`.  |
+---------------------------+-----------------------------------------------------------------------------------------------+
| 2. Usabilidad y Ergonomía | • Paradigma visual estricto: Cuadrícula de tarjetas táctiles de 120x120px mínimas.           |
|                           | • Reconocimiento antes que recuerdo mediante emojis universales (🔧, ⚡, 🌿, 🏗️, ⚙️, 🌳).     |
|                           | • Cumplimiento de contraste lumínico WCAG 2.1 AA en temas Claro y Modo Oscuro.                |
+---------------------------+-----------------------------------------------------------------------------------------------+
| 3. Rendimiento / Eficiencia| • Carga del DOM en menos de 800 milisegundos gracias a Vanilla JS sin dependencias pesadas.   |
|                           | • Filtrado dinámico de tareas y activos en memoria en menos de 50 milisegundos.               |
+---------------------------+-----------------------------------------------------------------------------------------------+
| 4. Confiabilidad          | • Persistencia dual en base de datos PostgreSQL con respaldo en LocalState ante desconexiones.|
|                           | • Validación exhaustiva de formularios para prevenir campos nulos o inconsistentes.          |
+---------------------------+-----------------------------------------------------------------------------------------------+
| 5. Seguridad y Privacidad | • Control de acceso basado en roles (RBAC) que restringe a Recepción la vista de costos.     |
|                           | • Sanitización de entradas para prevenir inyecciones de código malicioso (XSS y SQLi).        |
+---------------------------+-----------------------------------------------------------------------------------------------+
| 6. Mantenibilidad         | • Modularidad limpia en capas: vistas separadas en `/js/views/`, estado en `state.js`.        |
|                           | • Código documentado bajo directrices JSDoc y nomenclatura en inglés/español consistente.     |
+---------------------------+-----------------------------------------------------------------------------------------------+
| 7. Portabilidad           | • Capacidad multiplataforma: funcionamiento idéntico en Windows, Android, iOS y macOS.        |
|                           | • Interfaz responsiva probada en resoluciones de 375px (iPhone), 768px (iPad) y 1920px (PC).  |
+---------------------------+-----------------------------------------------------------------------------------------------+
| 8. Compatibilidad         | • Coexistencia armónica con navegadores web estándar mediante APIs W3C oficiales.             |
|                           | • Módulo de importación de datos para migrar planillas Excel/CSV existentes sin fricción.     |
+---------------------------+-----------------------------------------------------------------------------------------------+
```
*Tabla 9: Aplicación Práctica del Modelo ISO/IEC 25010 en el Software de Gestión. Fuente: Elaboración propia.*

---

### 6.2 Reglas de Negocio Críticas y Criterios de Aceptación del Hotel

El software incorpora cinco directrices funcionales y de diseño no negociables, impuestas por la naturaleza de la operación de El Almendro:

1. **Directriz 1: Navegación Visual Exclusiva por Tarjetas Cuadradas (Zero Lists):**
   * *Regla:* La interfaz principal y los accesos a las áreas deben organizarse mediante una cuadrícula de tarjetas independientes y espaciosas. 
   * *Justificación:* En las pruebas previas con planillas Excel y listas verticales de texto plano, el personal operativo ignoraba tareas pendientes por fatiga visual. Las tarjetas ofrecen un foco delimitado y claro.
2. **Directriz 2: Código Semafórico Universal para Prioridades y Estados:**
   * *Regla:* Toda tarea, alerta o vencimiento debe utilizar rigurosamente tres colores normalizados:
     * **Rojo (#EF4444 / rose-600):** Tarea crítica, urgencia reactiva inmediata o fecha vencida.
     * **Amarillo (#F59E0B / amber-500):** Tarea próxima a vencer (dentro de 30 días) o advertencia preventiva.
     * **Verde (#10B981 / emerald-600):** Tarea completada a tiempo, activo operativo o garantía al día.
3. **Directriz 3: Cálculo Automático e Inalterable de Materiales y Costos:**
   * *Regla:* Al ingresar insumos para una remodelación (ej. ladrillo refractario, sacos de cemento, pintura), el usuario ingresa únicamente cantidad y costo unitario. El software calcula automáticamente el subtotal de la fila y el costo total del proyecto.
   * *Justificación:* Se elimina de raíz el error humano de digitación o el cálculo mental erróneo, garantizando transparencia en las rendiciones de fondos del hotel.
4. **Directriz 4: Ficha Expandible de Área con 5 Bloques de Información:**
   * *Regla:* Al pulsar una tarjeta de área, el sistema abre una vista focalizada con: (1) Descripción y alcance, (2) Tareas activas y estado, (3) Carta Gantt del área, (4) Detalle de materiales y costos, y (5) Responsable e historial de actividades.
5. **Directriz 5: Soporte Nativo de Modo Oscuro:**
   * *Regla:* El sistema debe permitir alternar entre una paleta diurna clara y un Modo Oscuro (*Dark Mode*) de alto contraste para facilitar la visualización en ambientes con poca luz (ej. salas de calderas, bodegas subterráneas o inspecciones nocturnas en los jardines).

---

<div style="page-break-after: always;"></div>

# CAPÍTULO 7: INDIVIDUAL CONCLUSIONS (STRICTLY IN ENGLISH)

### 7.1 Individual Conclusion: Pablo Gamboa

> "Working through Phase 1 of the Capstone Project has demonstrated the critical importance of rigorous database design and systems architecture in the hospitality industry. By deeply analyzing the operational shortcomings of Hotel & Centro de Eventos El Almendro, I confirmed that enterprise software development does not begin with code, but with a profound comprehension of relational data structures, business logic, and operational pain points. Transitioning the hotel from disjointed, error-prone spreadsheets to a normalized relational data model in PostgreSQL—specifically through our structured `schema.json` containing 8 interconnected entities—guarantees data integrity, eliminates redundancy, and establishes the essential foundation for automatic cost calculations. Furthermore, enforcing the automated generation of itemized material subtotals (`quantity * unit_cost`) ensures financial accountability that the hotel previously lacked. From an engineering perspective, establishing these architectural boundaries early in the software lifecycle protects the project from scope creep, minimizes technical debt, and provides our team with a robust platform for the upcoming implementation phases."
>
> *— Pablo Gamboa, Software Engineering Student, Duoc UC.*

---

### 7.2 Individual Conclusion: Benjamín Salinas

> "Phase 1 has solidified my conviction that user experience (UX) and visual ergonomics are just as critical as architectural robustness when building enterprise applications. In traditional maintenance environments, workers frequently reject software not because the backend fails, but because cluttered text lists and convoluted navigation menus create cognitive overload. In designing the user interface for El Almendro, our decision to strictly mandate a card-based interactive grid—enriched with meaningful emojis, intuitive badge indicators, and a standardized traffic-light color system (Red, Yellow, and Green)—fundamentally transforms how maintenance tasks are perceived and prioritized. Developing expandable detail cards that seamlessly reveal specific information—such as the integrated Gantt timeline and real-time KPI metrics—proves that modern web applications can achieve superior operational usability without sacrificing structural rigor. This phase has reinforced my engineering ability to bridge user needs and modern frontend technologies, demonstrating that disciplined UI design directly fosters software adoption across all organizational tiers."
>
> *— Benjamín Salinas, Software Engineering Student, Duoc UC.*

---

### 7.3 Individual Conclusion: Bruno Carpio

> "Executing Phase 1 of this Capstone project has underscored the indispensable role of structured engineering methodologies and continuous quality assurance when tackling real-world technological challenges. By implementing an adapted Scrum framework with bi-weekly sprints, our team BPB established clear accountability, measurable milestones, and a direct alignment with the official graduation competencies defined by Duoc UC. Evaluating the project against the ISO/IEC 25010 software quality model enabled us to balance functional completeness with non-functional imperatives such as system performance, maintainability, and accessibility. Validating our requirements with the operational management of Hotel El Almendro provided empirical confirmation that our 16-week Gantt schedule is not only technically and operationally feasible, but also capable of delivering substantial business value. Managing this phase from initial stakeholder interviews to high-fidelity architectural deliverables has enhanced my capabilities as a technical project manager and software quality lead, fully preparing our team for the construction and validation stages ahead."
>
> *— Bruno Carpio, Software Engineering Student, Duoc UC.*

---

<div style="page-break-after: always;"></div>

# CAPÍTULO 8: INDIVIDUAL REFLECTIONS (STRICTLY IN ENGLISH)

### 8.1 Professional Reflection: Pablo Gamboa

> "Reflecting upon this first evaluative phase of our Capstone course, I recognize a substantial evolution in my identity from an academic programmer to an engineering professional capable of solving complex organizational problems. Interacting directly with the management of Hotel El Almendro revealed how easy it is for an organization to lose operational control when critical data is siloed across personal communication channels like WhatsApp and manual paper logs. My primary challenge was translating chaotic, unwritten administrative habits into strict mathematical models and structured relational schemas. This experience challenged my technical assumptions and taught me that true data architecture must be empathetic: it must serve the practical reality of people working in the field while simultaneously providing upper management with exact financial visibility. Moving forward into the subsequent construction phases, I feel an enhanced sense of responsibility and motivation to build clean, maintainable backend services that prove how disciplined software engineering can revitalize a traditional hospitality enterprise."
>
> *— Pablo Gamboa, Capstone Project BPB Team.*

---

### 8.2 Professional Reflection: Benjamín Salinas

> "This evaluative milestone has given me a deeper, more mature perspective on the social and human dimensions of technology. While developing the interactive wireframes and frontend modules for the maintenance staff at Hotel El Almendro, I realized that our users are not typical tech workers sitting at corporate desks; they are ground technicians, receptionists, and operational supervisors working across 31,000 square meters of facilities. Therefore, every design decision I made—from the size of clickable buttons on mobile touchscreens to the clarity of contrast in our Dark Mode implementation—had to prioritize simplicity, speed, and cognitive ease. This project has taught me that great software does not intimidate its users; rather, it empowers them by removing friction from their daily responsibilities. The satisfaction of seeing our card-based navigation paradigm instantly resonate with the hotel staff during requirement validation confirmed that my passion for frontend architecture and human-computer interaction can generate meaningful, tangible value in real-world organizations."
>
> *— Benjamín Salinas, Capstone Project BPB Team.*

---

### 8.3 Professional Reflection: Bruno Carpio

> "Navigating the inception and definition phase of our Capstone project has provided me with invaluable insights into leadership, team synchronization, and risk mitigation in software engineering. One of the most significant lessons I absorbed was how to negotiate the scope of a technical solution when faced with ambitious organizational expectations and strict academic deadlines. Acting as Scrum Master demanded balanced communication, active listening, and continuous alignment between Pablo's backend architectural proposals, Benjamín's UI/UX vision, and our client's real-world constraints. I learned that project management is not about imposing rigid bureaucracy, but about creating an environment of trust, transparency, and technical rigor where every team member can excel. Furthermore, evaluating our progress against the software engineering graduate profile reinforced my readiness to graduate and step into the IT industry as a confident, ethically committed software engineer capable of leading multidisciplinary technology initiatives."
>
> *— Bruno Carpio, Capstone Project BPB Team.*

---

<div style="page-break-after: always;"></div>

# CAPÍTULO 9: REFERENCIAS BIBLIOGRÁFICAS

1. **Duoc UC.** (2024). *Perfil de Egreso y Competencias Profesionales de la Carrera de Ingeniería en Informática y Desarrollo de Software*. Dirección de Escuela de Informática y Telecomunicaciones, Santiago de Chile.
2. **Duoc UC.** (2026). *Pauta de Evaluación Fase 1: Definición Proyecto APT (PTY4614 Capstone)*. Vicerrectoría Académica, Escuela de Informática y Telecomunicaciones.
3. **ISO/IEC.** (2011). *Systems and software engineering — Systems and software Quality Requirements and Evaluation (SQuaRE) — System and software quality models (ISO/IEC Standard No. 25010:2011)*. International Organization for Standardization. Ginebra, Suiza.
4. **IEEE Computer Society.** (1998). *IEEE Recommended Practice for Software Requirements Specifications (IEEE Std 830-1998)*. Institute of Electrical and Electronics Engineers. Nueva York, EE. UU.
5. **Pressman, R. S., & Maxim, B. R.** (2020). *Software Engineering: A Practitioner's Approach* (9ª ed.). McGraw-Hill Education.
6. **Sommerville, I.** (2016). *Software Engineering* (10ª ed.). Pearson Education.
7. **Schwaber, K., & Sutherland, J.** (2020). *The Scrum Guide: The Definitive Guide to Scrum: The Rules of the Game*. Scrum.org.
8. **Nielsen, J.** (1994). *Usability Engineering*. Morgan Kaufmann Publishers, San Francisco, CA.
9. **W3C.** (2018). *Web Content Accessibility Guidelines (WCAG) 2.1*. World Wide Web Consortium. https://www.w3.org/TR/WCAG21/

---

<div style="page-break-after: always;"></div>

# CAPÍTULO 10: ANEXOS TÉCNICOS Y DE INGENIERÍA

### Anexo A: Matriz Formal de Requisitos Funcionales y No Funcionales

#### Requisitos Funcionales (RF)
```
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| CÓDIGO | NOMBRE DEL REQUISITO               | DESCRIPCIÓN FUNCIONAL DETALLADA                                                | PRIORIDAD|
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RF-01  | Navegación por Tarjetas de Área    | El sistema debe presentar las 6 áreas de trabajo mediante una cuadrícula de    | Alta     |
|        |                                    | tarjetas interactivas independientes, prohibiendo listas de texto plano.       |          |
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RF-02  | Panel General de KPIs (Dashboard)  | La pantalla principal debe calcular en tiempo real: Tareas Activas, Mantenciones| Alta     |
|        |                                    | Próximas (30 días), Costo Acumulado del Mes (CLP) y % de Cumplimiento a Tiempo.|          |
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RF-03  | Gráfico de Tareas por Área         | Despliegue de un gráfico de barras comparativo con el volumen de tareas activas| Media    |
|        |                                    | en cada una de las 6 áreas operativas de El Almendro.                          |          |
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RF-04  | Ficha de Detalle de Área Expandida | Al pulsar una tarjeta de área, se desplegará una vista detallada con:          | Alta     |
|        |                                    | descripción, tareas activas, Gantt, costos/materiales y responsable asignado.  |          |
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RF-05  | Gestión de las 6 Áreas Base        | Administración segmentada de: Mantención General, Mantención Reactiva, Mejoras,| Alta     |
|        |                                    | Remodelaciones, Mantención de Máquinas y Mantención de Jardinería.             |          |
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RF-06  | Cálculo Automático de Materiales   | Al ingresar insumos para una tarea u obra, el sistema debe multiplicar cantidad| Crítica  |
|        |                                    | por costo unitario y totalizar el presupuesto de forma automática.             |          |
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RF-07  | Bloqueo de Edición Manual de Costo | La interfaz debe bloquear la digitación manual de subtotales y totales en los  | Alta     |
|        |                                    | formularios de materiales para evitar descuadres presupuestarios.              |          |
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RF-08  | Carta Gantt Común e Integrada      | Visualización cronológica en una sola línea de tiempo que integre mantenciones | Alta     |
|        |                                    | preventivas, reactivas, mejoras y remodelaciones por mes/semana.               |          |
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RF-09  | Prioridad Reactiva Fuera Calendario| Las emergencias reactivas deben destacarse fuera del calendario con alerta roja| Alta     |
|        |                                    | de alta prioridad para atención inmediata del técnico de turno.                |          |
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RF-10  | Notificaciones Automáticas Alertas | El sistema debe emitir alertas tempranas automáticas para mantenciones         | Alta     |
|        |                                    | próximas a su fecha límite y garantías a 60, 30, 15 y 7 días de expirar.       |          |
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RF-11  | Registro de Solicitudes Recepción  | Formulario accesible para Recepción y Gobernanta para registrar incidencias con| Alta     |
|        |                                    | recinto, descripción, prioridad y fotografía opcional de la falla.             |          |
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RF-12  | Conversión de Solicitudes a Tareas | El Administrador o Jefa de Mantención debe poder convertir una solicitud en una| Media    |
|        |                                    | orden de mantención o remodelación con un solo clic.                           |          |
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RF-13  | Ficha Técnica de Activos Fijos     | Inventario con marca, modelo, número de serie, ubicación, fecha de compra,     | Media    |
|        |                                    | proveedor, costo histórico y póliza de garantía asociada.                      |          |
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RF-14  | Filtro Dinámico de Tareas          | Capacidad de filtrar mantenciones por estado (Pendiente, En Proceso,           | Media    |
|        |                                    | Completada, Atrasada) y por área de trabajo sin recargar la página web.        |          |
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RF-15  | Módulo de Importación Excel / CSV  | Interfaz para cargar de forma masiva activos y tareas desde planillas de       | Baja     |
|        |                                    | cálculo históricas de la empresa.                                              |          |
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RF-16  | Conmutador de Roles de Usuario     | Mecanismo de prueba para alternar rápidamente entre perfiles (Administrador,   | Media    |
|        |                                    | Jefa Mantención, Técnico Terreno, Solicitante) y validar permisos.             |          |
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
```
*Tabla 10: Matriz de Requisitos Funcionales (RF). Fuente: Elaboración propia.*

---

#### Requisitos No Funcionales (RNF)
```
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| CÓDIGO | NOMBRE DEL REQUISITO               | ESPECIFICACIÓN TÉCNICA Y MÉTRICA ASOCIADA                                      | CRITERIO |
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RNF-01 | Prohibición de Listas Tradicionales| La navegación debe sustentarse al 100% en cuadrículas de tarjetas visuales.    | Usabilidad|
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RNF-02 | Uso Semántico de Emojis            | La interfaz debe utilizar emojis como anclajes visuales de rápido reconocimiento| Ergonomía|
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RNF-03 | Paleta de Colores de Semáforo      | Rojo (#EF4444) para urgente/peligro; Amarillo (#F59E0B) para por vencer;      | Ergonomía|
|        |                                    | Verde (#10B981) para completado/al día.                                        |          |
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RNF-04 | Soporte Nativo de Modo Oscuro      | El software debe incluir selector de tema Claro / Oscuro con persistencia.    | Accesib. |
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RNF-05 | Tiempo de Respuesta                | Las operaciones de renderizado, filtrado y cálculo deben tomar < 100 ms en DOM. | Rendim.  |
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RNF-06 | Diseño Responsivo Mobile-First     | Adaptabilidad completa a pantallas móviles de técnicos (>= 375px) y PC (1080p).| Portabil.|
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RNF-07 | Integridad y Restricciones BD      | Claves foráneas y tipos de datos estrictos en PostgreSQL para evitar huérfanos.| Fiabil.  |
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
| RNF-08 | Modularidad de Código              | Separación estricta de controladores, vistas y almacén de estado en JS.        | Mantenib.|
+--------+------------------------------------+--------------------------------------------------------------------------------+----------+
```
*Tabla 11: Matriz de Requisitos No Funcionales (RNF). Fuente: Elaboración propia.*

---

### Anexo B: Estructura Operativa de las 6 Áreas de Trabajo y Fichas de Detalle

```
+---------------------------+----+---------------------------------------------------------------+-------------------------------+
| ÁREA OPERATIVA            |ICON| DESCRIPCIÓN Y ALCANCE DE LA GESTIÓN EN EL HOTEL               | RESPONSABLE ASIGNADO          |
+---------------------------+----+---------------------------------------------------------------+-------------------------------+
| 1. Mantención General     | 🛠️ | Tareas rutinarias programadas en habitaciones, pasillos,      | Manuel Pérez / Roberto Silva  |
|                           |    | salones de conferencia y fachada.                             | (Técnico / Administrador)     |
+---------------------------+----+---------------------------------------------------------------+-------------------------------+
| 2. Mantención Reactiva    | ⚡ | Emergencias o averías inesperadas que exigen atención urgente:| Manuel Pérez                  |
|                           |    | fugas de agua, artefactos sanitarios, cortocircuitos.         | (Técnico de Turno)            |
+---------------------------+----+---------------------------------------------------------------+-------------------------------+
| 3. Mejoras                | 🌿 | Proyectos planificados de obra nueva que agregan valor:       | Carolina Morales              |
|                           |    | zona de parrillas, pérgolas de jardín, iluminación de parque. | (Jefa de Operaciones)         |
+---------------------------+----+---------------------------------------------------------------+-------------------------------+
| 4. Remodelación           | 🏗️ | Cambio o renovación integral de espacios existentes: baños,  | Carolina Morales              |
|                           |    | cambio de pisos, rediseño de terraza, con costeo de materiales.| (Jefa de Operaciones)         |
+---------------------------+----+---------------------------------------------------------------+-------------------------------+
| 5. Mantención de Máquinas | ⚙️ | Revisión técnica periódica (semanal, mensual, anual) de       | Manuel Pérez                  |
|                           |    | calderas, sala de bombas, generadores diésel y refrigeración. | (Técnico Especialista)        |
+---------------------------+----+---------------------------------------------------------------+-------------------------------+
| 6. Mantención Jardinería  | 🌳 | Cuidado estacional del parque de 3,1 hectáreas, labores de    | Carolina Morales / M. Pérez   |
|                           |    | poda, riego tecnificado y mantención de piscinas en temporada.| (Operaciones / Técnico)       |
+---------------------------+----+---------------------------------------------------------------+-------------------------------+
```
*Tabla 12: Estructura de las 6 Áreas de Trabajo del Sistema. Fuente: Elaboración propia.*

---

### Anexo C: Matriz de Usuarios, Roles y Permisos de Acceso

```
+-----------------------+------------+--------------------+-----------------------------------------------------------------+
| ROL DE USUARIO        | ICONO      | USUARIO REFERENCIAL| PERMISOS Y PRIVILEGIOS ASIGNADOS                                |
+-----------------------+------------+--------------------+-----------------------------------------------------------------+
| Administrador General | 👨‍💼         | Roberto Silva      | Acceso irrestricto al 100% del sistema, configuración,          |
|                       |            |                    | presupuestos, aprobación de gastos, eliminación y reportes KPI. |
+-----------------------+------------+--------------------+-----------------------------------------------------------------+
| Jefa de Operaciones   | 👩‍🔧         | Carolina Morales   | Gestión total de las 6 áreas, asignación de órdenes de trabajo, |
| y Mantención          |            |                    | conversión de solicitudes, control de compras y obras.          |
+-----------------------+------------+--------------------+-----------------------------------------------------------------+
| Técnico de Mantención | 👷‍♂️         | Manuel Pérez       | Visualización de órdenes asignadas, actualización de avance,    |
| en Terreno            |            |                    | registro de estado a "Completado" y subida de notas de trabajo. |
+-----------------------+------------+--------------------+-----------------------------------------------------------------+
| Solicitante           | 👩‍💼         | Valentina Castro   | Acceso exclusivo a la bandeja de solicitudes para registrar     |
| (Recepción/Gobernanta)|            |                    | averías de pasajeros y revisar el estado de atención del ticket.|
+-----------------------+------------+--------------------+-----------------------------------------------------------------+
```
*Tabla 13: Matriz de Roles y Privilegios de Acceso del Sistema. Fuente: Elaboración propia.*

---

### Anexo D: Especificación Visual de Pantallas, Mockups y Flujos de Navegación

El diseño de la aplicación web se articula en torno a tres vistas principales de interacción ergonómica:

1. **Pantalla Principal (Dashboard Ejecutivo):**
   * Encabezado corporativo con datos de Hotel El Almendro y selector de modo oscuro.
   * Barra superior con buscador predictivo y conmutador rápido de roles de usuario.
   * Fila superior de 4 tarjetas KPI en formato *widget* con datos calculados dinámicamente: Tareas Activas (`totalActiveTasks`), Mantenciones Próximas (`upcomingCount`), Costo Acumulado Mes (`formatCLP(totalMonthlyCost)`) y % de Tareas a Tiempo (`onTimePercentage%`).
   * Gráfico de distribución horizontal que refleja el volumen de tareas activas en cada una de las 6 áreas.
   * Sección central con la cuadrícula de las 6 tarjetas de área en disposición 3x2 en escritorio. Cada tarjeta contiene el icono representativo, estado de atrasos, título, descripción sintética, mini-métricas de tareas (Activas, Pendientes, Completadas) y botón directo "Abrir Ficha de Área".
   * Sección inferior de 4 cuadrículas con mini-tarjetas interactivas de actividad reciente: Mantenciones Próximas, Garantías por Vencer, Trabajos Atrasados y Solicitudes Nuevas.
2. **Ficha Expandida de Área de Trabajo:**
   * Despliegue en ventana modal o vista focalizada al hacer clic en cualquiera de las 6 tarjetas.
   * Cinco pestañas de navegación interna:
     * *Pestaña 1: Alcance del Área:* Descripción operativa, objetivos e inventario de instalaciones abarcadas.
     * *Pestaña 2: Tareas Activas:* Cuadrícula de tarjetas de órdenes con código semafórico de prioridad (rojo, amarillo, verde) y estado.
     * *Pestaña 3: Línea de Tiempo Gantt:* Cronograma del área con fechas de inicio, límite y alerta de vencimiento.
     * *Pestaña 4: Costos y Materiales:* Calculadora automatizada de materiales donde se desglosan los insumos utilizados (ej. ladrillo refractario, cemento, pintura) con subtotales autogenerados y costo consolidado.
     * *Pestaña 5: Responsable e Historial:* Ficha del técnico a cargo y bitácora cronológica de intervenciones pasadas.
3. **Módulo de Planificación y Carta Gantt Integrada:**
   * Barra temporal unificada que abarca de Enero a Diciembre.
   * Barras de color diferenciadas para cada una de las 6 áreas operativas.
   * Indicador visual de alerta roja para mantenciones con fecha próxima o vencida.
   * Carril superior exclusivo para intervenciones reactivas y urgencias prioritarias fuera de calendario.

---

### Anexo E: Diccionario de Datos y Modelo Entidad-Relación (Supabase / PostgreSQL)

A continuación, se resume la estructura del modelo relacional documentado en el archivo `schema.json` del proyecto:

* **Tabla `areas`:** Registra las 6 áreas de trabajo operativas.
  * `id` (UUID, PK), `name` (VARCHAR 100), `icon` (VARCHAR 20), `description` (TEXT), `color` (VARCHAR 30), `created_at` (TIMESTAMPTZ).
* **Tabla `assets`:** Catálogo de maquinaria y activos fijos del hotel.
  * `id` (UUID, PK), `name` (VARCHAR 200), `category` (VARCHAR 100), `brand` (VARCHAR 100), `model` (VARCHAR 100), `serial_number` (VARCHAR 100), `area_id` (UUID, FK -> areas.id), `location` (VARCHAR 200), `purchase_date` (DATE), `provider` (VARCHAR 200), `purchase_value` (NUMERIC 12,2), `responsible_user_id` (UUID, FK -> users.id), `status` (VARCHAR 50), `photo_url` (TEXT), `requires_maintenance` (BOOLEAN), `warranty_end_date` (DATE), `warranty_provider` (VARCHAR 200), `warranty_notes` (TEXT).
* **Tabla `maintenances`:** Órdenes de trabajo preventivas, correctivas y reactivas.
  * `id` (UUID, PK), `title` (VARCHAR 255), `description` (TEXT), `area_id` (UUID, FK -> areas.id), `asset_id` (UUID, FK -> assets.id), `type` (VARCHAR 50: Preventiva, Correctiva, Esporádica), `priority` (VARCHAR 20: Baja, Media, Alta, Crítica), `responsible_user_id` (UUID, FK -> users.id), `start_date` (DATE), `limit_date` (DATE), `completed_date` (DATE), `status` (VARCHAR 30: Pendiente, Programada, En proceso, Completada, Atrasada), `estimated_cost` (NUMERIC 12,2), `actual_cost` (NUMERIC 12,2), `observations` (TEXT).
* **Tabla `improvements`:** Proyectos de obras nuevas planificadas en el recinto.
  * `id` (UUID, PK), `name` (VARCHAR 255), `description` (TEXT), `area_id` (UUID, FK -> areas.id), `responsible` (VARCHAR 100), `start_date` (DATE), `end_date` (DATE), `priority` (VARCHAR 20), `status` (VARCHAR 30), `budget` (NUMERIC 12,2), `actual_cost` (NUMERIC 12,2), `progress_percent` (INTEGER).
* **Tabla `renovations`:** Obras de remodelación en recintos existentes.
  * `id` (UUID, PK), `name` (VARCHAR 255), `space` (VARCHAR 200), `area_id` (UUID, FK -> areas.id), `description` (TEXT), `responsible` (VARCHAR 100), `start_date` (DATE), `end_date` (DATE), `status` (VARCHAR 30), `budget` (NUMERIC 12,2), `progress_percent` (INTEGER).
* **Tabla `renovation_materials`:** Detalle de insumos asociados a cada remodelación.
  * `id` (UUID, PK), `renovation_id` (UUID, FK -> renovations.id), `name` (VARCHAR 200), `quantity` (NUMERIC 10,2), `unit` (VARCHAR 30), `unit_cost` (NUMERIC 12,2), `subtotal` (NUMERIC 12,2 GENERATED ALWAYS AS `quantity * unit_cost`).
* **Tabla `requests`:** Solicitudes de reparación ingresadas por Recepción.
  * `id` (UUID, PK), `title` (VARCHAR 255), `area_id` (UUID, FK -> areas.id), `location` (VARCHAR 255), `description` (TEXT), `priority` (VARCHAR 20), `requester_name` (VARCHAR 100), `requester_email` (VARCHAR 150), `status` (VARCHAR 30: Pendiente, En Revisión, Convertida, Rechazada), `converted_type` (VARCHAR 50), `converted_ref_id` (UUID), `created_at` (TIMESTAMPTZ).
