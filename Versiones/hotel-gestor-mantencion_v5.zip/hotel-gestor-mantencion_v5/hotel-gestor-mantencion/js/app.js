// ==========================================================
// APP PRINCIPAL & ENRUTADOR - HOTEL EL ALMENDRO
// ==========================================================
// Permission map and helper dinámico y escalable
function hasAccess(view, role) {
  const roles = window.SYSTEM_ROLES || (typeof SYSTEM_ROLES !== 'undefined' ? SYSTEM_ROLES : []);
  const roleConfig = roles.find(r => r.id === role);
  if (!roleConfig) {
    return role === 'ADMINISTRADOR' || view === 'dashboard';
  }
  return roleConfig.permissions.includes(view);
}

function updateSidebarVisibility() {
  const role = state.currentUser?.role || 'ADMINISTRADOR';
  document.querySelectorAll('.nav-item').forEach(btn => {
    const viewName = btn.id?.replace('nav-','');
    if (viewName && !hasAccess(viewName, role)) {
      btn.classList.add('hidden');
    } else {
      btn.classList.remove('hidden');
    }
  });
}

function toggleMobileSidebar(forceState) {
  const sidebar = document.getElementById('sidebar');
  const backdrop = document.getElementById('sidebar-backdrop');
  if (!sidebar) return;

  const isClosed = sidebar.classList.contains('-translate-x-full');
  const shouldOpen = (typeof forceState === 'boolean') ? forceState : isClosed;

  if (shouldOpen) {
    sidebar.classList.remove('-translate-x-full');
    sidebar.classList.add('translate-x-0');
    if (backdrop) backdrop.classList.remove('hidden');
  } else {
    sidebar.classList.add('-translate-x-full');
    sidebar.classList.remove('translate-x-0');
    if (backdrop) backdrop.classList.add('hidden');
  }
}

function navigateTo(viewName, filterAreaId = null) {
  // Cerrar sidebar móvil si estaba abierto
  toggleMobileSidebar(false);

  // Cerrar dropdowns superiores si estaban abiertos
  const rDrop = document.getElementById('role-dropdown');
  if (rDrop) rDrop.classList.add('hidden');
  const nDrop = document.getElementById('notification-dropdown');
  if (nDrop) nDrop.classList.add('hidden');

  const role = state.currentUser?.role || 'ADMINISTRADOR';
  if (!hasAccess(viewName, role)) {
    alert('Acceso denegado: su rol no permite ver esta sección');
    return;
  }
  currentView = viewName;
  if (filterAreaId !== undefined) {
    activeAreaFilter = filterAreaId;
  }
  
  document.querySelectorAll('.nav-item').forEach(btn => {
    btn.classList.remove('bg-blue-600/20', 'text-blue-400', 'border', 'border-blue-500/30');
  });
  const activeNav = document.getElementById(`nav-${viewName}`);
  if (activeNav) {
    activeNav.classList.add('bg-blue-600/20', 'text-blue-400', 'border', 'border-blue-500/30');
  }

  renderCurrentView();
}

function renderCurrentView() {
  updateSidebarVisibility();
  const container = document.getElementById('view-container');
  const pageIcon = document.getElementById('page-icon');
  const pageTitle = document.getElementById('page-title');
  const pageSubtitle = document.getElementById('page-subtitle');

  switch (currentView) {
    case 'dashboard':
      pageIcon.textContent = '📊';
      pageTitle.textContent = 'Panel Principal - Hotel El Almendro';
      pageSubtitle.textContent = 'Navegación visual por los tres pilares de trabajo y resúmenes';
      container.innerHTML = renderDashboardView();
      break;

    case 'mantenciones':
      pageIcon.textContent = '🔧';
      pageTitle.textContent = 'Mantenciones del Hotel';
      pageSubtitle.textContent = 'Cuadrícula visual de mantenciones preventivas, correctivas y esporádicas';
      container.innerHTML = renderMaintenancesView();
      break;

    case 'mejoras':
      pageIcon.textContent = '🌿';
      pageTitle.textContent = 'Mejoras y Proyectos Nuevos';
      pageSubtitle.textContent = 'Obras, quincho, pérgolas, jardinería y conectividad';
      container.innerHTML = renderImprovementsView();
      break;

    case 'remodelaciones':
      pageIcon.textContent = '🏗️';
      pageTitle.textContent = 'Remodelaciones de Espacios';
      pageSubtitle.textContent = 'Renovación de habitaciones, salones y calculadora de materiales';
      container.innerHTML = renderRenovationsView();
      break;

    case 'activos':
      pageIcon.textContent = '🏷️';
      pageTitle.textContent = 'Activos Fijos y Equipamiento';
      pageSubtitle.textContent = 'Inventario, fichas técnicas, garantías automatizadas e historial';
      container.innerHTML = renderAssetsView();
      break;

    case 'areas':
      pageIcon.textContent = '📍';
      pageTitle.textContent = 'Áreas de Trabajo';
      pageSubtitle.textContent = 'Unidades base de gestión operativa y mantenimiento de El Almendro';
      container.innerHTML = renderAreasView();
      break;

    case 'fechas-proximas':
      pageIcon.textContent = '📅';
      pageTitle.textContent = 'Fechas Próximas y Vencimientos';
      pageSubtitle.textContent = 'Cronograma en tarjetas organizado por días';
      container.innerHTML = renderUpcomingDatesView();
      break;

    case 'gantt':
      pageIcon.textContent = '📈';
      pageTitle.textContent = 'Línea de Tiempo & Diagrama Visual Gantt';
      pageSubtitle.textContent = 'Visualización 100% gráfica de obras y mantenciones sin listas ni tablas';
      container.innerHTML = renderGanttView();
      break;

    case 'solicitudes':
      pageIcon.textContent = '📩';
      pageTitle.textContent = 'Solicitudes de Personal y Huéspedes';
      pageSubtitle.textContent = 'Bandeja de solicitudes para conversión a órdenes de trabajo';
      container.innerHTML = renderRequestsView();
      break;

    case 'notificaciones':
      pageIcon.textContent = '🔔';
      pageTitle.textContent = 'Centro de Notificaciones y Alertas';
      pageSubtitle.textContent = 'Avisos automáticos de garantías, mantenciones atrasadas y asignaciones';
      container.innerHTML = renderNotificationsView();
      break;

    case 'importar':
      pageIcon.textContent = '📥';
      pageTitle.textContent = 'Importación de Datos Excel / CSV';
      pageSubtitle.textContent = 'Mapeo visual y carga masiva de datos';
      container.innerHTML = renderImportView();
      break;

    case 'configuracion':
      pageIcon.textContent = '⚙️';
      pageTitle.textContent = 'Configuración del Sistema';
      pageSubtitle.textContent = 'Ajustes de alertas de garantías, áreas y parámetros del hotel';
      container.innerHTML = renderSettingsView();
      break;

    default:
      container.innerHTML = `<div class="p-8 text-center"><p class="text-slate-500">Módulo en construcción</p></div>`;
  }

  updateSidebarBadges();
  populateSelectAreas();
}

function updateSidebarBadges() {
  const activeMnt = state.maintenances.filter(m => m.status !== 'Completada' && m.status !== 'Cancelada').length;
  const activeImp = state.improvements.filter(i => i.status !== 'Completado').length;
  const activeRen = state.renovations.filter(r => r.status !== 'Completado').length;
  const pendingReq = state.requests.filter(r => r.status === 'Pendiente').length;
  const unreadNotif = state.notifications.filter(n => !n.read).length;

  const elMnt = document.getElementById('badge-nav-mantenciones');
  const elImp = document.getElementById('badge-nav-mejoras');
  const elRen = document.getElementById('badge-nav-remodelaciones');
  const elAst = document.getElementById('badge-nav-activos');
  const elReq = document.getElementById('badge-nav-solicitudes');
  const elNot = document.getElementById('badge-nav-notif-count');
  const elTopNot = document.getElementById('topbar-notif-badge');

  if (elMnt) elMnt.textContent = activeMnt;
  if (elImp) elImp.textContent = activeImp;
  if (elRen) elRen.textContent = activeRen;
  if (elAst) elAst.textContent = state.assets.length;
  if (elReq) elReq.textContent = pendingReq;
  if (elNot) elNot.textContent = unreadNotif;
  if (elTopNot) {
    elTopNot.textContent = unreadNotif;
    elTopNot.style.display = unreadNotif > 0 ? 'flex' : 'none';
  }
}

function handleGlobalSearch(e) {
  const query = e.target.value.toLowerCase().trim();
  if (!query) return;
  if (e.key === 'Enter') {
    navigateTo('mantenciones');
  }
}

function syncCurrentUserUI() {
  if (!state.currentUser) return;
  const sName = document.getElementById('sidebar-user-name');
  const sRole = document.getElementById('sidebar-user-role');
  const sAvatar = document.getElementById('sidebar-user-avatar');
  const topBadge = document.getElementById('topbar-role-badge');
  const roles = window.SYSTEM_ROLES || [];
  const roleConfig = roles.find(r => r.id === state.currentUser.role);

  if (sName) sName.textContent = state.currentUser.name;
  if (sRole) sRole.textContent = state.currentUser.role;
  if (sAvatar) sAvatar.textContent = state.currentUser.avatar;
  if (topBadge) {
    topBadge.textContent = state.currentUser.role;
    topBadge.className = `font-bold px-2 py-0.5 rounded-md text-xs truncate ${roleConfig?.badgeClass || 'bg-blue-100 text-blue-700'}`;
  }
}

// Inicialización y Listeners Globales
window.addEventListener('DOMContentLoaded', () => {
  syncCurrentUserUI();
  if (typeof syncMaintenanceAlertNotifications === 'function') {
    syncMaintenanceAlertNotifications();
  }
  renderCurrentView();

  // Cerrar modales y dropdowns al presionar Escape
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.querySelectorAll('[id^="modal-"]:not(.hidden)').forEach(modal => {
        if (typeof closeModal === 'function') closeModal(modal.id);
      });
      const rDrop = document.getElementById('role-dropdown');
      if (rDrop) rDrop.classList.add('hidden');
      const nDrop = document.getElementById('notification-dropdown');
      if (nDrop) nDrop.classList.add('hidden');
      if (typeof toggleMobileSidebar === 'function') toggleMobileSidebar(false);
    }
  });

  // Listener global para cerrar modales y dropdowns al hacer clic fuera
  document.addEventListener('click', (e) => {
    if (e.target && e.target.id && e.target.id.startsWith('modal-') && !e.target.classList.contains('hidden')) {
      if (typeof closeModal === 'function') {
        closeModal(e.target.id);
      }
    }

    // Cerrar dropdown de rol si se hace clic fuera
    const roleDropdown = document.getElementById('role-dropdown');
    const roleBtn = document.getElementById('btn-role-dropdown');
    if (roleDropdown && !roleDropdown.classList.contains('hidden')) {
      if (!roleDropdown.contains(e.target) && (!roleBtn || !roleBtn.contains(e.target))) {
        roleDropdown.classList.add('hidden');
      }
    }

    // Cerrar dropdown de notificaciones si se hace clic fuera
    const notifDropdown = document.getElementById('notification-dropdown');
    const notifBtn = document.getElementById('btn-notification-dropdown');
    if (notifDropdown && !notifDropdown.classList.contains('hidden')) {
      if (!notifDropdown.contains(e.target) && (!notifBtn || !notifBtn.contains(e.target))) {
        notifDropdown.classList.add('hidden');
      }
    }
  });
});

