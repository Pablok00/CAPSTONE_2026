// ==========================================================
// GESTOR DE ESTADO GLOBAL (STATE STORE) - HOTEL EL ALMENDRO
// ==========================================================

function getSystemDate() {
  return new Date('2026-08-28T00:00:00');
}

// Configuración Maestra y Escalable de Roles del Sistema
const SYSTEM_ROLES = [
  {
    id: "ADMINISTRADOR",
    name: "Administrador General",
    title: "Administrador General",
    avatar: "👨‍💼",
    badgeClass: "bg-blue-100 text-blue-700 border border-blue-200",
    description: "Acceso total a todo el sistema, presupuestos y configuración",
    defaultUserId: "usr_1",
    permissions: [
      'dashboard', 'mantenciones', 'mejoras', 'remodelaciones', 'activos', 
      'areas', 'fechas-proximas', 'gantt', 'solicitudes', 'notificaciones', 
      'importar', 'configuracion'
    ]
  },
  {
    id: "TECNICO",
    name: "Técnico Mantención",
    title: "Técnico Especialista en Terreno",
    avatar: "👷‍♂️",
    badgeClass: "bg-amber-100 text-amber-700 border border-amber-200",
    description: "Actualizar trabajos asignados, fotos y estados",
    defaultUserId: "usr_3",
    permissions: [
      'dashboard', 'mantenciones', 'mejoras', 'remodelaciones', 'activos', 
      'areas', 'fechas-proximas', 'gantt', 'solicitudes', 'notificaciones'
    ]
  },
  {
    id: "SOLICITANTE",
    name: "Solicitante (Recepción / Mucamas)",
    title: "Recepción / Gobernanta / Mucamas",
    avatar: "👩‍💼",
    badgeClass: "bg-purple-100 text-purple-700 border border-purple-200",
    description: "Ingresar incidentes de pasajeros y consultar estado",
    defaultUserId: "usr_4",
    permissions: [
      'dashboard', 'solicitudes'
    ]
  }
];

window.SYSTEM_ROLES = SYSTEM_ROLES;

const DEFAULT_WORK_AREAS = [
  {
    id: "workarea_general",
    name: "Mantención General",
    icon: "🛠️",
    description: "Tareas rutinarias de mantenimiento integral en habitaciones, pasillos y salones del hotel.",
    bullets: [
      "Tareas rutinarias de mantenimiento.",
      "Habitaciones, pasillos y salones.",
      "Mantenciones generales programadas."
    ],
    color: "blue",
    isPrincipal: true,
    relatedAreas: ["workarea_reactiva", "workarea_maquinas", "workarea_jardineria"],
    responsible: "Manuel Pérez / Roberto Silva"
  },
  {
    id: "workarea_reactiva",
    name: "Mantención Reactiva",
    icon: "⚡",
    description: "Emergencias o fallas imprevistas que requieren atención inmediata y reparación técnica sin demora.",
    bullets: [
      "Emergencias o fallas que requieren atención inmediata.",
      "Fugas, sifones, artefactos u otros problemas inesperados.",
      "Trabajos que no estaban previamente programados."
    ],
    color: "amber",
    isPrincipal: false,
    responsible: "Manuel Pérez"
  },
  {
    id: "workarea_mejoras",
    name: "Mejoras",
    icon: "🌿",
    description: "Proyectos nuevos y obras de valor planificadas para enriquecer las instalaciones de El Almendro.",
    bullets: [
      "Proyectos nuevos o mejoras futuras.",
      "Ejemplo: zona de parrillas, pérgola, iluminación, nuevas instalaciones.",
      "Trabajos planificados para mejorar espacios existentes."
    ],
    color: "emerald",
    isPrincipal: false,
    responsible: "Roberto Silva"
  },
  {
    id: "workarea_remodelacion",
    name: "Remodelación",
    icon: "🏗️",
    description: "Renovación y modificación de recintos existentes con control estricto de materiales y partidas.",
    bullets: [
      "Renovación o modificación de espacios existentes.",
      "Cambio de materiales, terminaciones o distribución.",
      "Control de materiales y costos asociados a la remodelación."
    ],
    color: "purple",
    isPrincipal: false,
    responsible: "Roberto Silva"
  },
  {
    id: "workarea_maquinas",
    name: "Mantención de Máquinas",
    icon: "⚙️",
    description: "Revisión técnica sistemática de maquinaria, generadores, calderas y equipos centrales del hotel.",
    bullets: [
      "Revisión y mantenimiento de equipos y maquinaria.",
      "Mantenciones semanales, mensuales o anuales.",
      "Responsable y fechas de revisión asignadas."
    ],
    color: "slate",
    isPrincipal: false,
    responsible: "Manuel Pérez"
  },
  {
    id: "workarea_jardineria",
    name: "Mantención de Jardinería",
    icon: "🌳",
    description: "Cuidado continuo del parque, áreas verdes, piscina y labores de jardinería según estación climática.",
    bullets: [
      "Cuidado y mantenimiento de jardines y áreas verdes.",
      "Trabajos según temporada.",
      "Planificación de labores de invierno y verano."
    ],
    color: "teal",
    isPrincipal: false,
    responsible: "Manuel Pérez"
  }
];

function normalizeState(data) {
  if (!data) data = {};
  if (!data.workAreas || data.workAreas.length < 6) {
    data.workAreas = JSON.parse(JSON.stringify(DEFAULT_WORK_AREAS));
  } else {
    data.workAreas.forEach(wa => {
      const def = DEFAULT_WORK_AREAS.find(d => d.id === wa.id);
      if (def) {
        wa.bullets = def.bullets;
        wa.description = def.description;
        wa.responsible = def.responsible;
      }
    });
  }

  // Depuración y escalabilidad de roles en usuarios
  if (Array.isArray(data.users)) {
    data.users = data.users.filter(u => u.role !== 'ENCARGADO');
    const adminUser = data.users.find(u => u.role === 'ADMINISTRADOR');
    const tecUser = data.users.find(u => u.role === 'TECNICO');
    const solUser = data.users.find(u => u.role === 'SOLICITANTE');

    if (!adminUser && window.INITIAL_HOTEL_DATA?.users) {
      data.users.unshift(window.INITIAL_HOTEL_DATA.users[0]);
    }
    if (!tecUser && window.INITIAL_HOTEL_DATA?.users) {
      const defT = window.INITIAL_HOTEL_DATA.users.find(u => u.role === 'TECNICO');
      if (defT) data.users.push(defT);
    }
    if (!solUser && window.INITIAL_HOTEL_DATA?.users) {
      const defS = window.INITIAL_HOTEL_DATA.users.find(u => u.role === 'SOLICITANTE');
      if (defS) data.users.push(defS);
    }
  }

  // Si el usuario actual tenía rol ENCARGADO o inexistente, migrar a ADMINISTRADOR
  if (!data.currentUser || data.currentUser.role === 'ENCARGADO' || !SYSTEM_ROLES.some(r => r.id === data.currentUser.role)) {
    data.currentUser = (data.users && data.users.find(u => u.role === 'ADMINISTRADOR')) || {
      id: "usr_1",
      name: "Roberto Silva",
      role: "ADMINISTRADOR",
      email: "roberto.silva@elalmendro.cl",
      avatar: "👨‍💼",
      title: "Administrador General"
    };
  }

  // Normalizar mantenciones para asociarlas a las 6 áreas de trabajo
  if (Array.isArray(data.maintenances)) {
    data.maintenances.forEach(m => {
      if (m.responsible === 'Carolina Morales') m.responsible = 'Roberto Silva';
      if (!m.materials) m.materials = [];
      if (!m.workAreaId) {
        const text = ((m.title || '') + ' ' + (m.assetName || '') + ' ' + (m.description || '')).toLowerCase();
        if (text.includes('caldera') || text.includes('generador') || text.includes('lavavajillas') || text.includes('lavadora') || text.includes('frío') || text.includes('refrigerador')) {
          m.workAreaId = 'workarea_maquinas';
          m.workAreaName = 'Mantención de Máquinas';
        } else if (text.includes('piscina') || text.includes('césped') || text.includes('jardín') || text.includes('árboles') || text.includes('bomba') || text.includes('filtro de piscina')) {
          m.workAreaId = 'workarea_jardineria';
          m.workAreaName = 'Mantención de Jardinería';
        } else if (text.includes('fuga') || text.includes('urgente') || text.includes('imprevista') || text.includes('cortocircuito') || text.includes('falla') || m.type === 'Esporádica') {
          m.workAreaId = 'workarea_reactiva';
          m.workAreaName = 'Mantención Reactiva';
        } else {
          m.workAreaId = 'workarea_general';
          m.workAreaName = 'Mantención General';
        }
      }
    });
  }

  // Normalizar mejoras
  if (Array.isArray(data.improvements)) {
    data.improvements.forEach(imp => {
      if (imp.responsible === 'Carolina Morales') imp.responsible = 'Roberto Silva';
      imp.workAreaId = 'workarea_mejoras';
      imp.workAreaName = 'Mejoras';
      if (!imp.materials) imp.materials = [];
    });
  }

  // Normalizar remodelaciones
  if (Array.isArray(data.renovations)) {
    data.renovations.forEach(ren => {
      if (ren.responsible === 'Carolina Morales') ren.responsible = 'Roberto Silva';
      ren.workAreaId = 'workarea_remodelacion';
      ren.workAreaName = 'Remodelación';
      if (!ren.materials) ren.materials = [];
    });
  }

  return data;
}

function loadInitialState() {
  const savedData = localStorage.getItem('EL_ALMENDRO_HOTEL_DATA');
  if (savedData) {
    try {
      const parsed = JSON.parse(savedData);
      return normalizeState(parsed);
    } catch (e) {
      console.error("Error al cargar localStorage, usando datos iniciales", e);
    }
  }
  const initial = window.INITIAL_HOTEL_DATA || {};
  return normalizeState(JSON.parse(JSON.stringify(initial)));
}

// Variables de estado global
let state = loadInitialState();
let currentView = 'dashboard';
let activeAreaFilter = null;
let activeConvertingRequestId = null;
let selectedAssetTab = 'ficha';
let ganttViewMode = 'timeline'; // 'timeline' (diagrama) o 'horizontes' (fases)
let ganttCategoryFilter = 'TODAS';
let ganttAreaFilter = 'TODAS';
let ganttStatusFilter = 'TODAS';
let maintenanceCategoryFilter = 'TODAS';
let maintenanceAreaFilter = 'TODAS';
let maintenanceStatusFilter = 'TODAS';
let assetCategoryFilter = 'TODAS';
let assetWarrantyFilter = 'TODAS';
let upcomingDateAreaFilter = 'TODAS';
let upcomingDateTypeFilter = 'TODAS';

// Persistencia en localStorage
function saveState() {
  localStorage.setItem('EL_ALMENDRO_HOTEL_DATA', JSON.stringify(state));
  if (typeof updateSidebarBadges === 'function') updateSidebarBadges();
  if (typeof renderCurrentView === 'function') renderCurrentView();
}

function resetToFactoryData() {
  if (confirm("¿Estás seguro de que deseas restablecer todos los datos del prototipo a su estado original?")) {
    localStorage.removeItem('EL_ALMENDRO_HOTEL_DATA');
    state = normalizeState(JSON.parse(JSON.stringify(window.INITIAL_HOTEL_DATA)));
    saveState();
    alert("Datos restablecidos con éxito para Hotel El Almendro.");
  }
}

// Funciones de formato y utilidades
function formatCLP(amount) {
  return '$ ' + Number(amount || 0).toLocaleString('es-CL');
}

function formatDate(dateStr) {
  if (!dateStr) return 'No definida';
  const parts = dateStr.split('-');
  if (parts.length === 3) {
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
  }
  return dateStr;
}

function calculateWarrantyStatus(warranty) {
  if (!warranty || !warranty.endDate) {
    return { status: 'Sin Garantía', color: 'slate', badge: 'Sin Garantía', daysLeft: 0, text: 'No registra garantía' };
  }
  const today = getSystemDate();
  const endDate = new Date(warranty.endDate + 'T00:00:00');
  const diffTime = endDate.getTime() - today.getTime();
  const daysLeft = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (daysLeft < 0) {
    return {
      status: 'Vencida',
      color: 'rose',
      badge: 'Garantía Vencida',
      daysLeft: daysLeft,
      text: `Venció el ${formatDate(warranty.endDate)}`
    };
  } else if (daysLeft <= 60) {
    return {
      status: 'Proxima',
      color: 'amber',
      badge: `Por vencer (${daysLeft} días)`,
      daysLeft: daysLeft,
      text: `Vence el ${formatDate(warranty.endDate)} (Quedan ${daysLeft} días)`
    };
  } else {
    return {
      status: 'Vigente',
      color: 'emerald',
      badge: 'En Garantía',
      daysLeft: daysLeft,
      text: `Vigente hasta ${formatDate(warranty.endDate)}`
    };
  }
}

// ==========================================================
// LÓGICA DE ALERTAS AUTOMÁTICAS DE MANTENCIÓN
// ==========================================================
function getMaintenanceAlert(mnt) {
  if (!mnt || mnt.status === 'Completada' || mnt.status === 'Cancelada') {
    return null;
  }

  const targetDateStr = mnt.limitDate || mnt.startDate;
  if (!targetDateStr) return null;

  const today = getSystemDate();
  const targetDate = new Date(targetDateStr + 'T00:00:00');
  const diffTime = targetDate.getTime() - today.getTime();
  const daysLeft = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (daysLeft < 0) {
    return {
      level: 'Atrasada',
      badge: 'Atrasada',
      color: 'rose',
      badgeClass: 'bg-rose-100 text-rose-800 border-rose-300 font-extrabold ring-1 ring-rose-400',
      daysLeft: daysLeft,
      text: `Venció hace ${Math.abs(daysLeft)} día(s)`
    };
  } else if (daysLeft === 0) {
    return {
      level: 'Vence hoy',
      badge: 'Vence hoy',
      color: 'rose',
      badgeClass: 'bg-rose-600 text-white font-black animate-pulse shadow-sm',
      daysLeft: 0,
      text: 'Vence hoy'
    };
  } else if (daysLeft >= 1 && daysLeft <= 3) {
    return {
      level: 'Urgente',
      badge: `Urgente (${daysLeft}d)`,
      color: 'orange',
      badgeClass: 'bg-orange-100 text-orange-900 border border-orange-300 font-bold',
      daysLeft: daysLeft,
      text: `Urgente: faltan ${daysLeft} día(s)`
    };
  } else if (daysLeft >= 4 && daysLeft <= 7) {
    return {
      level: 'Alta',
      badge: `Alta (${daysLeft}d)`,
      color: 'amber',
      badgeClass: 'bg-amber-100 text-amber-900 border border-amber-300 font-bold',
      daysLeft: daysLeft,
      text: `Prioridad alta: faltan ${daysLeft} días`
    };
  } else if (daysLeft >= 8 && daysLeft <= 30) {
    return {
      level: 'Próxima',
      badge: `Próxima (${daysLeft}d)`,
      color: 'blue',
      badgeClass: 'bg-blue-100 text-blue-900 border border-blue-200 font-semibold',
      daysLeft: daysLeft,
      text: `Programada en ${daysLeft} días`
    };
  }

  return null;
}

// Sincronización de notificaciones automáticas sin duplicación
function syncMaintenanceAlertNotifications() {
  if (!state.notifications) state.notifications = [];

  let newNotificationsAdded = false;

  (state.maintenances || []).forEach(m => {
    const alert = getMaintenanceAlert(m);
    if (alert && (alert.level === 'Atrasada' || alert.level === 'Vence hoy' || alert.level === 'Urgente' || alert.level === 'Alta')) {
      const notifId = `notif_mnt_alert_${m.id}_${alert.level}`;
      const exists = state.notifications.some(n => n.id === notifId);

      if (!exists) {
        state.notifications.unshift({
          id: notifId,
          type: alert.level === 'Atrasada' || alert.level === 'Vence hoy' ? 'alert' : 'warning',
          title: `Alerta: ${m.title} (${alert.badge})`,
          message: `${alert.text} en ${m.areaName} (${m.workAreaName || 'Mantención'}). Responsable: ${m.responsible}.`,
          timestamp: 'Automática',
          linkModule: 'mantenciones',
          read: false,
          referenceId: m.id
        });
        sendEmailAlertNotification(alert, m);
        newNotificationsAdded = true;
      }
    }
  });

  if (newNotificationsAdded) {
    saveState();
  }
}

// Preparación lógica para envío de correo
function sendEmailAlertNotification(alert, mnt) {
  // Simulación y registro de auditoría de despacho de correo
  const emailPayload = {
    to: state.currentUser ? state.currentUser.email : 'operaciones@elalmendro.cl',
    subject: `[Alerta Mantención - ${alert.badge}] ${mnt.title}`,
    body: `Se ha detectado una mantención con estado: ${alert.level}.\nÁrea: ${mnt.areaName}\nFecha límite: ${mnt.limitDate}\nResponsable: ${mnt.responsible}`,
    sentAt: new Date().toISOString()
  };
  console.info("📧 [ALERTA DE CORREO PREPARADA]", emailPayload);
}

// ==========================================================
// CÁLCULO DINÁMICO DE KPIS PARA EL DASHBOARD
// ==========================================================
function getDashboardKPIs() {
  const activeMnt = (state.maintenances || []).filter(m => m.status !== 'Completada' && m.status !== 'Cancelada').length;
  const activeImp = (state.improvements || []).filter(i => i.status !== 'Completado' && i.status !== 'Cancelado').length;
  const activeRen = (state.renovations || []).filter(r => r.status !== 'Completado' && r.status !== 'Cancelado').length;
  const totalActiveTasks = activeMnt + activeImp + activeRen;

  // Mantenciones próximas (alertas activas Próxima, Alta, Urgente, Vence hoy)
  const upcomingCount = (state.maintenances || []).filter(m => {
    const alert = getMaintenanceAlert(m);
    return alert && (alert.level === 'Próxima' || alert.level === 'Alta' || alert.level === 'Urgente' || alert.level === 'Vence hoy');
  }).length;

  // Costo acumulado del mes (suma de costos reales y cómputos de materiales del periodo actual)
  const costMnt = (state.maintenances || []).reduce((acc, m) => acc + (m.actualCost || 0), 0);
  const costImp = (state.improvements || []).reduce((acc, i) => acc + (i.actualCost || 0), 0);
  const costRen = (state.renovations || []).reduce((acc, r) => {
    const matSum = (r.materials || []).reduce((subAcc, mat) => subAcc + (mat.subtotal || 0), 0);
    return acc + matSum;
  }, 0);
  const totalMonthlyCost = costMnt + costImp + costRen;

  // Porcentaje de tareas completadas a tiempo
  let completedOnTime = 0;
  let totalCompleted = 0;

  (state.maintenances || []).forEach(m => {
    if (m.status === 'Completada') {
      totalCompleted++;
      if (m.completedDate && m.limitDate) {
        if (m.completedDate <= m.limitDate) completedOnTime++;
      } else {
        completedOnTime++;
      }
    }
  });

  (state.improvements || []).forEach(i => {
    if (i.status === 'Completado') {
      totalCompleted++;
      completedOnTime++;
    }
  });

  (state.renovations || []).forEach(r => {
    if (r.status === 'Completado') {
      totalCompleted++;
      completedOnTime++;
    }
  });

  const onTimePercentage = totalCompleted > 0 ? Math.round((completedOnTime / totalCompleted) * 100) : 92;

  return {
    totalActiveTasks,
    upcomingCount,
    totalMonthlyCost,
    onTimePercentage,
    completedOnTime,
    totalCompleted
  };
}

// ==========================================================
// CONSULTA UNIFICADA POR ÁREA DE TRABAJO (SINGLE SOURCE OF TRUTH)
// ==========================================================
function getWorkAreaStats(workAreaId) {
  const areaDef = (state.workAreas || DEFAULT_WORK_AREAS).find(a => a.id === workAreaId) || DEFAULT_WORK_AREAS[0];

  let tasks = [];

  if (workAreaId === 'workarea_mejoras') {
    tasks = (state.improvements || []).map(i => ({
      id: i.id,
      title: i.name,
      description: i.description,
      status: i.status === 'Completado' ? 'Completada' : (i.status === 'En Proceso' ? 'En proceso' : 'Pendiente'),
      responsible: i.responsible,
      startDate: i.startDate,
      limitDate: i.endDate,
      estimatedCost: i.budget || 0,
      actualCost: i.actualCost || 0,
      materials: i.materials || [],
      type: 'Mejora',
      module: 'mejoras',
      areaName: i.areaName
    }));
  } else if (workAreaId === 'workarea_remodelacion') {
    tasks = (state.renovations || []).map(r => ({
      id: r.id,
      title: r.name,
      description: r.description,
      status: r.status === 'Completado' ? 'Completada' : (r.status === 'En Proceso' ? 'En proceso' : 'Pendiente'),
      responsible: r.responsible,
      startDate: r.startDate,
      limitDate: r.endDate,
      estimatedCost: r.budget || 0,
      actualCost: (r.materials || []).reduce((acc, m) => acc + (m.subtotal || 0), 0),
      materials: r.materials || [],
      type: 'Remodelación',
      module: 'remodelaciones',
      areaName: r.areaName
    }));
  } else {
    // Mantenciones asignadas a este área de trabajo
    tasks = (state.maintenances || []).filter(m => {
      if (workAreaId === 'workarea_general') {
        return m.workAreaId === 'workarea_general' || !m.workAreaId;
      }
      return m.workAreaId === workAreaId;
    }).map(m => ({
      id: m.id,
      title: m.title,
      description: m.description,
      status: m.status,
      responsible: m.responsible,
      startDate: m.startDate,
      limitDate: m.limitDate,
      estimatedCost: m.estimatedCost || 0,
      actualCost: m.actualCost || 0,
      materials: m.materials || [],
      type: m.type,
      module: 'mantenciones',
      areaName: m.areaName,
      alert: getMaintenanceAlert(m)
    }));
  }

  const active = tasks.filter(t => t.status !== 'Completada' && t.status !== 'Cancelada').length;
  const pending = tasks.filter(t => t.status === 'Pendiente' || t.status === 'Programada' || t.status === 'Planificación').length;
  const inProgress = tasks.filter(t => t.status === 'En proceso' || t.status === 'En Proceso').length;
  const completed = tasks.filter(t => t.status === 'Completada' || t.status === 'Completado').length;
  const delayed = tasks.filter(t => t.status === 'Atrasada' || (t.alert && t.alert.level === 'Atrasada')).length;

  const totalEstimatedCost = tasks.reduce((acc, t) => acc + (t.estimatedCost || 0), 0);
  const totalActualCost = tasks.reduce((acc, t) => acc + (t.actualCost || 0), 0);

  // Materiales consolidados del área
  const allMaterials = [];
  tasks.forEach(t => {
    (t.materials || []).forEach(m => {
      allMaterials.push({
        ...m,
        taskTitle: t.title,
        taskId: t.id
      });
    });
  });

  return {
    area: areaDef,
    tasks,
    active,
    pending,
    inProgress,
    completed,
    delayed,
    totalEstimatedCost,
    totalActualCost,
    materials: allMaterials
  };
}

