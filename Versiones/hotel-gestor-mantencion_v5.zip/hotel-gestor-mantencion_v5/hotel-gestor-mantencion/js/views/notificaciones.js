// ==========================================================
// VISTA: NOTIFICACIONES & ALERTAS - HOTEL EL ALMENDRO
// ==========================================================

function renderNotificationsView() {
  return `
    <div class="space-y-6 max-w-4xl mx-auto pb-10">
      
      <div class="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex items-center justify-between">
        <div>
          <h3 class="text-base font-bold text-slate-800">Centro de Notificaciones</h3>
          <p class="text-xs text-slate-600">Registro en tiempo real de alertas de mantención, vencimientos de garantías y solicitudes.</p>
        </div>
        <button onclick="markAllNotificationsRead()" class="text-xs font-bold text-blue-600 hover:underline">
          Marcar todas como leídas
        </button>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        ${state.notifications.map(notif => {
          const notifIcons = {
            'alert': '🚨',
            'warning': '⚠️',
            'info': '📩',
            'success': '✅'
          };

          const notifBorders = {
            'alert': 'border-l-4 border-l-rose-500 bg-rose-50/40',
            'warning': 'border-l-4 border-l-amber-500 bg-amber-50/40',
            'info': 'border-l-4 border-l-blue-500 bg-blue-50/40',
            'success': 'border-l-4 border-l-emerald-500 bg-emerald-50/40'
          };

          return `
            <div class="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm ${notifBorders[notif.type]} flex flex-col justify-between card-hover hover:shadow-md transition-all">
              <div class="flex items-start space-x-3.5">
                <span class="text-2xl flex-shrink-0">${notifIcons[notif.type]}</span>
                <div class="flex-1 min-w-0">
                  <div class="flex items-center justify-between gap-1 mb-1">
                    <h4 class="text-sm font-extrabold text-slate-800 truncate">${notif.title}</h4>
                    <span class="text-[10px] text-slate-500 font-medium flex-shrink-0">${notif.timestamp}</span>
                  </div>
                  <p class="text-xs text-slate-600 leading-relaxed">${notif.message}</p>
                </div>
              </div>

              <div class="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                <span class="text-[10px] font-bold uppercase text-slate-500 tracking-wider">Módulo: ${notif.linkModule}</span>
                <button onclick="navigateTo('${notif.linkModule}')" class="text-xs font-extrabold text-blue-600 hover:text-blue-800 flex items-center space-x-1">
                  <span>Abrir módulo</span>
                  <span>→</span>
                </button>
              </div>
            </div>
          `;
        }).join('')}
      </div>

    </div>
  `;
}

function renderTopbarNotifications() {
  const list = document.getElementById('topbar-notif-list');
  if (list) {
    list.innerHTML = state.notifications.map(n => `
      <div class="p-2.5 rounded-xl ${n.read ? 'bg-slate-50' : 'bg-blue-50/70 border border-blue-200'} text-xs">
        <p class="font-bold text-slate-800">${n.title}</p>
        <p class="text-[11px] text-slate-600 line-clamp-1">${n.message}</p>
      </div>
    `).join('');
  }
}

function markAllNotificationsRead() {
  state.notifications.forEach(n => n.read = true);
  saveState();
  renderTopbarNotifications();
}
