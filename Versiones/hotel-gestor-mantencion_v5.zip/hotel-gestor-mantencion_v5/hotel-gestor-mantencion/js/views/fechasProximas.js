// ==========================================================
// VISTA: FECHAS PRÓXIMAS - HOTEL EL ALMENDRO
// ==========================================================

function renderUpcomingDatesView() {
  let allDateItems = [];

  state.maintenances.forEach(m => {
    if (m.startDate) {
      allDateItems.push({
        id: m.id,
        module: 'mantenciones',
        title: m.title,
        date: m.startDate,
        type: m.type,
        category: 'Mantención',
        areaId: m.areaId,
        areaName: m.areaName,
        responsible: m.responsible,
        status: m.status,
        priority: m.priority
      });
    }
  });

  state.improvements.forEach(i => {
    if (i.startDate) {
      allDateItems.push({
        id: i.id,
        module: 'mejoras',
        title: i.name,
        date: i.startDate,
        type: 'Mejora',
        category: 'Proyecto',
        areaId: i.areaId,
        areaName: i.areaName,
        responsible: i.responsible,
        status: i.status,
        priority: i.priority
      });
    }
  });

  state.renovations.forEach(r => {
    if (r.startDate) {
      allDateItems.push({
        id: r.id,
        module: 'remodelaciones',
        title: r.name,
        date: r.startDate,
        type: 'Remodelación',
        category: 'Remodelación',
        areaId: r.areaId,
        areaName: r.areaName,
        responsible: r.responsible,
        status: r.status,
        priority: 'Alta'
      });
    }
  });

  let filtered = allDateItems.filter(item => {
    if (upcomingDateAreaFilter !== 'TODAS' && item.areaId !== upcomingDateAreaFilter) return false;
    if (upcomingDateTypeFilter !== 'TODAS' && item.type !== upcomingDateTypeFilter) return false;
    return true;
  });

  filtered.sort((a, b) => new Date(a.date) - new Date(b.date));

  const groups = {};
  filtered.forEach(item => {
    if (!groups[item.date]) groups[item.date] = [];
    groups[item.date].push(item);
  });

  return `
    <div class="space-y-6 max-w-7xl mx-auto pb-10">
      
      <div class="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-3">
        <div class="flex flex-wrap items-center gap-3">
          <div class="flex items-center space-x-2">
            <label class="text-xs font-bold text-slate-600 uppercase">Filtrar Área:</label>
            <select onchange="upcomingDateAreaFilter = this.value; renderCurrentView();" class="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-700">
              <option value="TODAS">Todas las áreas</option>
              ${state.areas.map(a => `<option value="${a.id}" ${upcomingDateAreaFilter === a.id ? 'selected' : ''}>${a.name}</option>`).join('')}
            </select>
          </div>

          <div class="flex items-center space-x-2">
            <label class="text-xs font-bold text-slate-600 uppercase">Tipo de Trabajo:</label>
            <select onchange="upcomingDateTypeFilter = this.value; renderCurrentView();" class="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-700">
              <option value="TODAS">Todos los tipos</option>
              <option value="Preventiva" ${upcomingDateTypeFilter === 'Preventiva' ? 'selected' : ''}>Preventiva</option>
              <option value="Correctiva" ${upcomingDateTypeFilter === 'Correctiva' ? 'selected' : ''}>Correctiva</option>
              <option value="Esporádica" ${upcomingDateTypeFilter === 'Esporádica' ? 'selected' : ''}>Esporádica</option>
              <option value="Mejora" ${upcomingDateTypeFilter === 'Mejora' ? 'selected' : ''}>Mejoras</option>
              <option value="Remodelación" ${upcomingDateTypeFilter === 'Remodelación' ? 'selected' : ''}>Remodelaciones</option>
            </select>
          </div>
        </div>

        <div class="text-xs font-bold text-slate-600">
          Total compromisos agendados: <span class="text-blue-600 font-extrabold">${filtered.length}</span>
        </div>
      </div>

      <div class="space-y-6">
        ${Object.keys(groups).length === 0 ? `
          <div class="bg-white rounded-3xl p-12 text-center border border-slate-200">
            <p class="text-sm font-bold text-slate-600">No hay compromisos con los filtros aplicados</p>
          </div>
        ` : Object.keys(groups).map(dateKey => {
          const items = groups[dateKey];
          const dateObj = new Date(dateKey + 'T00:00:00');
          const dayStr = dateObj.toLocaleDateString('es-ES', { weekday: 'short', day: '2-digit', month: 'short' }).toUpperCase();

          return `
            <div>
              <div class="flex items-center space-x-3 mb-3">
                <span class="bg-blue-600 text-white font-extrabold text-xs px-3.5 py-1.5 rounded-xl shadow-md tracking-wider">
                  📅 [${dayStr}] - ${formatDate(dateKey)}
                </span>
                <span class="text-xs font-semibold text-slate-600">${items.length} ${items.length === 1 ? 'actividad' : 'actividades'}</span>
              </div>

              <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                ${items.map(item => `
                  <div onclick="${item.module === 'mantenciones' ? `openMaintenanceDetail('${item.id}')` : item.module === 'mejoras' ? `openImprovementDetail('${item.id}')` : `openRenovationDetail('${item.id}')`}" class="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm hover:shadow-md transition-all cursor-pointer card-hover">
                    <div class="flex items-center justify-between mb-2">
                      <span class="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md ${item.type === 'Preventiva' ? 'bg-blue-100 text-blue-800' : item.type === 'Correctiva' ? 'bg-amber-100 text-amber-800' : item.type === 'Mejora' ? 'bg-emerald-100 text-emerald-800' : 'bg-purple-100 text-purple-800'}">
                        ${item.type}
                      </span>
                      <span class="text-xs font-bold text-slate-600">${item.areaName.split(' ')[0]}</span>
                    </div>

                    <h5 class="text-sm font-bold text-slate-800 leading-snug">${item.title}</h5>

                    <div class="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs">
                      <span class="text-slate-600 font-medium">Resp: ${item.responsible.split(' ')[0]}</span>
                      <span class="font-bold text-blue-600">${item.status}</span>
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>
          `;
        }).join('')}
      </div>

    </div>
  `;
}
