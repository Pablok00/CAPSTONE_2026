// ==========================================================
// VISTA: IMPORTAR EXCEL / CSV - HOTEL EL ALMENDRO
// ==========================================================

function renderImportView() {
  return `
    <div class="space-y-6 max-w-4xl mx-auto pb-10">
      
      <div class="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
        <h3 class="text-lg font-bold text-slate-800">Importación de Datos Masivos</h3>
        <p class="text-xs text-slate-600 mt-1">Carga planillas Excel (.xlsx) o CSV cuando el cliente entregue los archivos definitivos de El Almendro.</p>

        <div class="mt-6 border-2 border-dashed border-blue-300 bg-blue-50/40 rounded-3xl p-10 text-center hover:bg-blue-50 transition-colors cursor-pointer">
          <span class="text-5xl block mb-2">📊</span>
          <p class="text-sm font-extrabold text-slate-800">Arrastra tu archivo Excel o CSV aquí</p>
          <p class="text-xs text-slate-600 mt-1">O haz clic para seleccionar archivo desde tu computador</p>
          <button class="mt-4 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold py-2 px-4 rounded-xl shadow-md transition-all">
            Seleccionar Archivo
          </button>
        </div>

        <div class="mt-8 pt-6 border-t border-slate-100">
          <h4 class="text-sm font-extrabold text-slate-800 mb-2">Esquema de Mapeo de Columnas (Preparado para XLSX)</h4>
          <p class="text-xs text-slate-600 mb-4">El sistema asociará automáticamente las columnas de tu Excel con los campos del sistema:</p>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div class="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
              <span class="font-bold text-slate-700">Nombre de Activo / Máquina</span>
              <span class="bg-blue-100 text-blue-800 font-semibold px-2 py-0.5 rounded">Columna A</span>
            </div>
            <div class="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
              <span class="font-bold text-slate-700">Área / Sector del Hotel</span>
              <span class="bg-blue-100 text-blue-800 font-semibold px-2 py-0.5 rounded">Columna B</span>
            </div>
            <div class="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
              <span class="font-bold text-slate-700">Marca y Modelo</span>
              <span class="bg-blue-100 text-blue-800 font-semibold px-2 py-0.5 rounded">Columna C</span>
            </div>
            <div class="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
              <span class="font-bold text-slate-700">Fecha de Término Garantía</span>
              <span class="bg-blue-100 text-blue-800 font-semibold px-2 py-0.5 rounded">Columna D</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  `;
}
