// ==========================================================
// VISTA: MANTENCIONES - HOTEL EL ALMENDRO
// ==========================================================

function renderMaintenancesView() {
  let filtered = state.maintenances.filter(m => {
    if (maintenanceCategoryFilter !== 'TODAS' && m.type !== maintenanceCategoryFilter) return false;
    if (maintenanceAreaFilter !== 'TODAS' && m.areaId !== maintenanceAreaFilter && m.workAreaId !== maintenanceAreaFilter) return false;
    if (maintenanceStatusFilter !== 'TODAS' && m.status !== maintenanceStatusFilter) return false;
    if (activeAreaFilter && m.areaId !== activeAreaFilter && m.workAreaId !== activeAreaFilter) return false;
    return true;
  });

  const workAreasData = (state.workAreas || DEFAULT_WORK_AREAS);

  return `
    <div class="space-y-6 max-w-7xl mx-auto pb-10">
      
      <!-- CUADRÍCULA SUPERIOR: 6 ÁREAS BASE (3x2 en escritorio, 2 col tablet, 1 col móvil) -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        ${workAreasData.map(area => {
          const stats = getWorkAreaStats(area.id);
          const isSelected = maintenanceAreaFilter === area.id || activeAreaFilter === area.id;

          const defaultBullets = {
            'workarea_general': [
              'Tareas rutinarias de mantenimiento.',
              'Habitaciones, pasillos y salones.',
              'Mantenciones generales programadas.'
            ],
            'workarea_reactiva': [
              'Emergencias o fallas que requieren atención inmediata.',
              'Fugas, sifones, artefactos u otros problemas inesperados.',
              'Trabajos que no estaban previamente programados.'
            ],
            'workarea_mejoras': [
              'Proyectos nuevos o mejoras futuras.',
              'Ejemplo: zona de parrillas, pérgola, iluminación, nuevas instalaciones.',
              'Trabajos planificados para mejorar espacios existentes.'
            ],
            'workarea_remodelacion': [
              'Renovación o modificación de espacios existentes.',
              'Cambio de materiales, terminaciones o distribución.',
              'Control de materiales y costos asociados a la remodelación.'
            ],
            'workarea_maquinas': [
              'Revisión y mantenimiento de equipos y maquinaria.',
              'Mantenciones semanales, mensuales o anuales.',
              'Responsable y fechas de revisión asignadas.'
            ],
            'workarea_jardineria': [
              'Cuidado y mantenimiento de jardines y áreas verdes.',
              'Trabajos según temporada.',
              'Planificación de labores de invierno y verano.'
            ]
          };

          const bullets = area.bullets || defaultBullets[area.id] || [];

          return `
            <div onclick="maintenanceAreaFilter = '${isSelected ? 'TODAS' : area.id}'; activeAreaFilter=null; renderCurrentView();" 
                 class="p-4 rounded-3xl border-2 transition-all cursor-pointer flex flex-col justify-between card-hover relative group ${
                   isSelected 
                     ? 'border-blue-600 bg-blue-50/70 shadow-lg ring-2 ring-blue-500/20' 
                     : 'border-slate-200 bg-white hover:border-blue-400 hover:shadow-md'
                 }">
              
              <div>
                <div class="flex items-center justify-between gap-2 mb-2">
                  <div class="flex items-center space-x-2.5 min-w-0">
                    <span class="text-2xl flex-shrink-0">${area.icon}</span>
                    <h4 class="font-extrabold text-slate-900 text-sm group-hover:text-blue-600 transition-colors truncate">
                      ${area.name}
                    </h4>
                  </div>
                  <span class="text-xs font-black px-2.5 py-0.5 rounded-full ${
                    isSelected ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-700'
                  }">
                    ${stats.tasks.length}
                  </span>
                </div>

                <!-- Viñetas exactas requeridas por el cliente -->
                <ul class="mt-2.5 space-y-1 text-xs text-slate-600 leading-relaxed bg-slate-50/70 group-hover:bg-blue-50/40 p-2.5 rounded-2xl border border-slate-100 transition-colors">
                  ${bullets.map(b => `
                    <li class="flex items-start space-x-1.5">
                      <span class="text-blue-600 font-bold text-[11px] leading-tight">•</span>
                      <span class="text-[11px] font-medium text-slate-700">${b}</span>
                    </li>
                  `).join('')}
                </ul>
              </div>

              <div class="mt-3.5 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px] font-bold">
                <span class="${isSelected ? 'text-blue-700' : 'text-slate-500'}">
                  ${isSelected ? '✓ Área seleccionada' : 'Clic para filtrar'}
                </span>
                <button type="button" 
                  onclick="event.stopPropagation(); openAreaDetail('${area.id}');" 
                  class="text-blue-600 hover:text-blue-800 hover:underline flex items-center space-x-0.5">
                  <span>Ver Ficha</span>
                  <span>→</span>
                </button>
              </div>

            </div>
          `;
        }).join('')}
      </div>


      <!-- BARRA DE FILTROS -->
      <div class="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-3">
        <div class="flex flex-wrap items-center gap-3">
          <div class="flex items-center space-x-2">
            <label class="text-xs font-bold text-slate-600 uppercase">Área:</label>
            <select onchange="maintenanceAreaFilter = this.value; renderCurrentView();" class="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-700">
              <option value="TODAS">Todas las áreas</option>
              <optgroup label="Áreas de Trabajo">
                ${(state.workAreas || DEFAULT_WORK_AREAS).map(wa => `<option value="${wa.id}" ${maintenanceAreaFilter === wa.id || activeAreaFilter === wa.id ? 'selected' : ''}>${wa.icon} ${wa.name}</option>`).join('')}
              </optgroup>
              <optgroup label="Instalaciones del Hotel">
                ${state.areas.map(a => `<option value="${a.id}" ${maintenanceAreaFilter === a.id || activeAreaFilter === a.id ? 'selected' : ''}>${a.name}</option>`).join('')}
              </optgroup>
            </select>
          </div>

          <div class="flex items-center space-x-2">
            <label class="text-xs font-bold text-slate-600 uppercase">Estado:</label>
            <select onchange="maintenanceStatusFilter = this.value; renderCurrentView();" class="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-700">
              <option value="TODAS" ${maintenanceStatusFilter === 'TODAS' ? 'selected' : ''}>Todos los estados</option>
              <option value="Pendiente" ${maintenanceStatusFilter === 'Pendiente' ? 'selected' : ''}>Pendiente</option>
              <option value="Programada" ${maintenanceStatusFilter === 'Programada' ? 'selected' : ''}>Programada</option>
              <option value="En proceso" ${maintenanceStatusFilter === 'En proceso' ? 'selected' : ''}>En proceso</option>
              <option value="Completada" ${maintenanceStatusFilter === 'Completada' ? 'selected' : ''}>Completada</option>
              <option value="Atrasada" ${maintenanceStatusFilter === 'Atrasada' ? 'selected' : ''}>Atrasada</option>
            </select>
          </div>

          <div class="flex items-center space-x-2">
            <label class="text-xs font-bold text-slate-600 uppercase">Tipo:</label>
            <select onchange="maintenanceCategoryFilter = this.value; renderCurrentView();" class="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-700">
              <option value="TODAS" ${maintenanceCategoryFilter === 'TODAS' ? 'selected' : ''}>Todos los tipos</option>
              <option value="Preventiva" ${maintenanceCategoryFilter === 'Preventiva' ? 'selected' : ''}>Preventiva</option>
              <option value="Correctiva" ${maintenanceCategoryFilter === 'Correctiva' ? 'selected' : ''}>Correctiva</option>
              <option value="Esporádica" ${maintenanceCategoryFilter === 'Esporádica' ? 'selected' : ''}>Esporádica</option>
            </select>
          </div>

          ${maintenanceAreaFilter !== 'TODAS' || activeAreaFilter || maintenanceCategoryFilter !== 'TODAS' || maintenanceStatusFilter !== 'TODAS' ? `
            <button onclick="maintenanceAreaFilter = 'TODAS'; maintenanceCategoryFilter = 'TODAS'; maintenanceStatusFilter = 'TODAS'; activeAreaFilter = null; renderCurrentView();" class="bg-blue-100 text-blue-700 hover:bg-blue-200 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center space-x-1.5 transition-colors">
              <span>✕</span>
              <span>Restablecer Filtros</span>
            </button>
          ` : ''}
        </div>

        <div class="text-xs font-bold text-slate-600">
          Mostrando <span class="text-blue-600 font-extrabold">${filtered.length}</span> tarjetas de mantención
        </div>
      </div>

      <!-- CUADRÍCULA DE TARJETAS DE MANTENCIÓN -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        ${filtered.length === 0 ? `
          <div class="col-span-full bg-white rounded-3xl p-12 text-center border border-slate-200">
            <span class="text-4xl block mb-2">🔍</span>
            <p class="text-base font-bold text-slate-700">No hay mantenciones con los filtros seleccionados</p>
            <button onclick="maintenanceCategoryFilter='TODAS'; maintenanceAreaFilter='TODAS'; maintenanceStatusFilter='TODAS'; activeAreaFilter=null; renderCurrentView();" class="mt-3 text-xs font-bold text-blue-600 hover:underline">
              Restablecer todos los filtros
            </button>
          </div>
        ` : filtered.map(m => {
          const alert = getMaintenanceAlert(m);
          const statusBadges = {
            'Pendiente': 'bg-amber-100 text-amber-800 border-amber-200',
            'Programada': 'bg-blue-100 text-blue-800 border-blue-200',
            'En proceso': 'bg-indigo-100 text-indigo-800 border-indigo-200 animate-pulse',
            'Completada': 'bg-emerald-100 text-emerald-800 border-emerald-200',
            'Atrasada': 'bg-rose-100 text-rose-800 border-rose-200 font-black',
            'Cancelada': 'bg-slate-100 text-slate-800 border-slate-200'
          };

          const typeColors = {
            'Preventiva': 'text-blue-700 bg-blue-50 border-blue-200',
            'Correctiva': 'text-amber-700 bg-amber-50 border-amber-200',
            'Esporádica': 'text-purple-700 bg-purple-50 border-purple-200'
          };

          const priorityColors = {
            'Baja': 'text-slate-600 bg-slate-100',
            'Media': 'text-blue-700 bg-blue-100',
            'Alta': 'text-amber-800 bg-amber-100 font-bold',
            'Crítica': 'text-rose-800 bg-rose-100 font-black'
          };

          return `
            <div onclick="openMaintenanceDetail('${m.id}')" 
                 class="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm hover:shadow-xl transition-all cursor-pointer flex flex-col justify-between card-hover group relative ${
                   alert && alert.level === 'Atrasada' ? 'ring-2 ring-rose-400/80 border-rose-300' : (alert && alert.level === 'Urgente' ? 'ring-2 ring-amber-400/80' : '')
                 }">
              
              <div>
                <div class="flex items-center justify-between gap-2 mb-3">
                  <div class="flex items-center space-x-1.5 flex-wrap">
                    <span class="text-[11px] font-extrabold uppercase px-2.5 py-0.5 rounded-lg border ${typeColors[m.type]}">
                      ${m.type}
                    </span>
                    ${alert ? `
                      <span class="text-[10px] font-extrabold px-2 py-0.5 rounded-md ${alert.badgeClass} flex items-center space-x-1">
                        <span>🔔</span>
                        <span>${alert.badge}</span>
                      </span>
                    ` : ''}
                  </div>
                  <span class="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${priorityColors[m.priority]}">
                    ${m.priority}
                  </span>
                </div>

                <h4 class="text-base font-bold text-slate-900 leading-snug group-hover:text-blue-600 transition-colors">
                  ${m.title}
                </h4>

                <div class="mt-3 flex flex-wrap items-center gap-1.5 text-xs">
                  <span class="bg-slate-100 text-slate-700 font-medium px-2 py-0.5 rounded-md flex items-center space-x-1">
                    <span>📍</span>
                    <span>${m.workAreaName || m.areaName}</span>
                  </span>
                  ${m.assetName ? `
                    <span class="bg-blue-50 text-blue-800 font-semibold px-2 py-0.5 rounded-md truncate max-w-[200px] flex items-center space-x-1">
                      <span>🏷️</span>
                      <span class="truncate">${m.assetName}</span>
                    </span>
                  ` : ''}
                </div>

                <p class="text-xs text-slate-600 mt-2.5 line-clamp-2 leading-relaxed">
                  ${m.description}
                </p>
              </div>

              <div class="mt-5 pt-4 border-t border-slate-100">
                <div class="grid grid-cols-2 gap-2 text-xs mb-3">
                  <div>
                    <p class="text-[10px] text-slate-500 font-bold uppercase">Fecha Límite</p>
                    <p class="font-black ${m.status === 'Atrasada' || (alert && alert.level === 'Atrasada') ? 'text-rose-600' : 'text-slate-800'}">
                      ${formatDate(m.limitDate)}
                    </p>
                  </div>
                  <div class="text-right">
                    <p class="text-[10px] text-slate-500 font-bold uppercase">Costo Estimado / Real</p>
                    <p class="font-bold text-slate-800">
                      ${formatCLP(m.estimatedCost)}
                      ${m.actualCost ? `<span class="text-[10px] text-blue-700 block font-semibold">Real: ${formatCLP(m.actualCost)}</span>` : ''}
                    </p>
                  </div>
                </div>

                <div class="flex items-center justify-between pt-2 border-t border-slate-100">
                  <div class="flex items-center space-x-2">
                    <div class="w-6 h-6 rounded-full bg-slate-200 text-xs flex items-center justify-center font-bold">
                      👷
                    </div>
                    <span class="text-xs text-slate-700 font-medium truncate max-w-[120px]">${m.responsible.split(' ')[0]}</span>
                  </div>

                  <span class="text-xs font-bold px-2.5 py-1 rounded-full border ${statusBadges[m.status]}">
                    ${m.status}
                  </span>
                </div>
              </div>

            </div>
          `;
        }).join('')}
      </div>

    </div>
  `;
}

function setMaintenanceCategory(category) {
  maintenanceCategoryFilter = category;
  renderCurrentView();
}
