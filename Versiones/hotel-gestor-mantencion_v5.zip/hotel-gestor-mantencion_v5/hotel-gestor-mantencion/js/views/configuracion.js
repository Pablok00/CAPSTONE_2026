// ==========================================================
// VISTA: CONFIGURACIÓN Y PREFERENCIAS - HOTEL EL ALMENDRO
// ==========================================================

let activeConfigTab = 'cuenta';
let localCacheSize = 42.8;

function switchConfigTab(tabName) {
  activeConfigTab = tabName;
  renderCurrentView();
}

function renderSettingsView() {
  if (!state.settings) {
    state.settings = {
      profile: {
        name: state.currentUser ? state.currentUser.name : 'Roberto Silva',
        email: state.currentUser ? state.currentUser.email : 'rsilva@elalmendro.cl',
        phone: '+56 9 8765 4321',
        avatar: state.currentUser ? state.currentUser.avatar : '👨‍💼',
        role: state.currentUser ? state.currentUser.role : 'ADMINISTRADOR',
        twoFactor: true
      },
      appearance: {
        theme: 'light',
        fontSize: 'normal',
        highContrast: false,
        screenReader: false,
        language: 'es',
        timeZone: 'America/Santiago',
        currency: 'CLP'
      },
      notifications: {
        push: true,
        email: true,
        sms: false,
        frequency: 'instant',
        doNotDisturb: false,
        dndStart: '22:00',
        dndEnd: '07:00'
      },
      privacy: {
        visibility: 'team',
        camera: true,
        location: true,
        contacts: false,
        mic: false,
        analytics: false
      },
      storage: {
        wifiOnly: true,
        autoCleanDays: 30,
        connectedGoogle: true,
        connectedSlack: true,
        connectedWhatsApp: false
      }
    };
  }

  const s = state.settings;

  const tabs = [
    { id: 'cuenta', label: 'Cuenta y Perfil', icon: '👤', desc: 'Datos personales, seguridad y facturación' },
    { id: 'aspecto', label: 'Interfaz y Aspecto', icon: '🎨', desc: 'Tema, accesibilidad, idioma y moneda' },
    { id: 'notificaciones', label: 'Notificaciones', icon: '🔔', desc: 'Canales, frecuencia y modo no molestar' },
    { id: 'privacidad', label: 'Privacidad y Datos', icon: '🔒', desc: 'Permisos de hardware, visibilidad y exportación' },
    { id: 'almacenamiento', label: 'Almacenamiento', icon: '💾', desc: 'Caché, uso de datos e integraciones' },
    { id: 'soporte', label: 'Ayuda y Soporte', icon: '❓', desc: 'Preguntas frecuentes, reporte y versiones' },
    { id: 'hotel', label: 'Parámetros Hotel', icon: '⚙️', desc: 'Garantías y restablecimiento' }
  ];

  return `
    <div class="max-w-7xl mx-auto pb-12 space-y-6">
      
      <!-- ENCABEZADO PRINCIPAL DE AJUSTES -->
      <div class="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-4 border border-slate-700">
        <div class="flex items-center space-x-4">
          <div class="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-500 to-indigo-400 flex items-center justify-center text-3xl shadow-lg shadow-blue-500/30">
            ⚙️
          </div>
          <div>
            <h3 class="text-xl font-extrabold">Configuración del Sistema</h3>
            <p class="text-slate-300 text-xs mt-0.5">Hotel & Centro de Eventos El Almendro • Preferencias globales de usuario e interfaz</p>
          </div>
        </div>

        <div class="flex items-center space-x-2">
          <span class="bg-blue-600/30 border border-blue-400/30 text-blue-200 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center space-x-1.5">
            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Versión 2.4.0 Activa</span>
          </span>
        </div>
      </div>

      <!-- DISPOSICIÓN EN 2 COLUMNAS: MENÚ LATERAL DE SECCIONES + CONTENIDO ACTIVO -->
      <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        <!-- COLUMNA 1: MENÚ DE NAVEGACIÓN DE SECCIONES (TABS) -->
        <div class="lg:col-span-1 space-y-2">
          <div class="bg-white rounded-2xl p-3 border border-slate-200 shadow-sm space-y-1">
            <p class="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-3 py-1.5">Secciones de Ajustes</p>
            ${tabs.map(t => `
              <button onclick="switchConfigTab('${t.id}')" class="w-full text-left p-3 rounded-xl transition-all flex items-center space-x-3 card-hover ${activeConfigTab === t.id ? 'bg-blue-600 text-white shadow-md font-bold' : 'hover:bg-slate-100 text-slate-700 font-medium'}">
                <span class="text-xl">${t.icon}</span>
                <div class="min-w-0 flex-1">
                  <p class="text-xs leading-tight ${activeConfigTab === t.id ? 'text-white' : 'text-slate-800 font-bold'}">${t.label}</p>
                  <p class="text-[10px] truncate mt-0.5 ${activeConfigTab === t.id ? 'text-blue-100' : 'text-slate-400'}">${t.desc}</p>
                </div>
              </button>
            `).join('')}
          </div>

          <!-- Tarjeta de Estado Rápido -->
          <div class="bg-gradient-to-br from-slate-900 to-indigo-950 text-white rounded-2xl p-4 border border-slate-800 text-xs space-y-2">
            <div class="flex items-center justify-between">
              <span class="font-bold text-slate-300">Usuario Activo:</span>
              <span class="bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-bold text-[10px]">Conectado</span>
            </div>
            <p class="font-bold text-white">${s.profile.name}</p>
            <p class="text-slate-400 text-[11px]">${s.profile.email}</p>
          </div>
        </div>

        <!-- COLUMNA 2: CONTENIDO DE LA SECCIÓN ACTIVA -->
        <div class="lg:col-span-3">
          ${renderActiveConfigSection(activeConfigTab, s)}
        </div>

      </div>

    </div>
  `;
}

function renderActiveConfigSection(tabId, s) {
  switch (tabId) {
    case 'cuenta':
      return renderSectionAccount(s);
    case 'aspecto':
      return renderSectionAppearance(s);
    case 'notificaciones':
      return renderSectionNotifications(s);
    case 'privacidad':
      return renderSectionPrivacy(s);
    case 'almacenamiento':
      return renderSectionStorage(s);
    case 'soporte':
      return renderSectionSupport();
    case 'hotel':
      return renderSectionHotelParams();
    default:
      return renderSectionAccount(s);
  }
}

// ==========================================================
// 1. CUENTA Y PERFIL
// ==========================================================
function renderSectionAccount(s) {
  return `
    <div class="space-y-6">
      
      <!-- Datos Personales -->
      <div class="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-5">
        <div class="flex items-center justify-between pb-4 border-b border-slate-100">
          <div>
            <h4 class="text-base font-extrabold text-slate-800 flex items-center space-x-2">
              <span>👤</span>
              <span>Datos Personales</span>
            </h4>
            <p class="text-xs text-slate-500 mt-0.5">Edita tu información de contacto y visualización en el sistema</p>
          </div>
          <span class="text-xs font-bold bg-blue-50 text-blue-700 px-2.5 py-1 rounded-lg border border-blue-200">
            Rol: ${s.profile.role}
          </span>
        </div>

        <form onsubmit="handleSaveProfile(event)" class="space-y-4">
          <div class="flex items-center space-x-4 pb-2">
            <div class="w-16 h-16 rounded-2xl bg-slate-100 border-2 border-dashed border-slate-300 flex items-center justify-center text-3xl shadow-inner cursor-pointer hover:bg-slate-200 transition-colors" title="Cambiar Avatar">
              <span id="cfg-profile-avatar">${s.profile.avatar}</span>
            </div>
            <div>
              <p class="text-xs font-bold text-slate-700">Foto / Avatar de Perfil</p>
              <p class="text-[11px] text-slate-500">Selecciona un emoji representativo o sube una fotografía corporativa</p>
              <div class="flex items-center space-x-1.5 mt-2">
                <button type="button" onclick="selectAvatar('👨‍💼')" class="px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded text-sm">👨‍💼</button>
                <button type="button" onclick="selectAvatar('👩‍🔧')" class="px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded text-sm">👩‍🔧</button>
                <button type="button" onclick="selectAvatar('👷‍♂️')" class="px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded text-sm">👷‍♂️</button>
                <button type="button" onclick="selectAvatar('👩‍💼')" class="px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded text-sm">👩‍💼</button>
                <button type="button" onclick="selectAvatar('🏨')" class="px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded text-sm">🏨</button>
              </div>
            </div>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Nombre Completo *</label>
              <input type="text" id="cfg-name" value="${s.profile.name}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-semibold text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-500">
            </div>
            <div>
              <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Correo Electrónico *</label>
              <input type="email" id="cfg-email" value="${s.profile.email}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-semibold text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-500">
            </div>
            <div>
              <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Teléfono de Contacto</label>
              <input type="text" id="cfg-phone" value="${s.profile.phone}" class="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-semibold text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-500">
            </div>
            <div>
              <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Organización / Propiedad</label>
              <input type="text" disabled value="Hotel & Centro de Eventos El Almendro" class="w-full bg-slate-100 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-500 cursor-not-allowed">
            </div>
          </div>

          <div class="pt-2 flex justify-end">
            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-md transition-all">
              Guardar Cambios de Perfil
            </button>
          </div>
        </form>
      </div>

      <!-- Seguridad & 2FA -->
      <div class="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-5">
        <div class="pb-3 border-b border-slate-100">
          <h4 class="text-base font-extrabold text-slate-800 flex items-center space-x-2">
            <span>🛡️</span>
            <span>Seguridad & Acceso</span>
          </h4>
          <p class="text-xs text-slate-500 mt-0.5">Control de contraseña, doble factor y sesiones activas</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
          <!-- Cambio de Contraseña -->
          <div class="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <h5 class="text-xs font-extrabold text-slate-800 uppercase">Cambiar Contraseña</h5>
            <div class="space-y-2">
              <input type="password" placeholder="Contraseña actual" class="w-full bg-white border border-slate-200 rounded-xl p-2 text-xs">
              <input type="password" placeholder="Nueva contraseña segura" class="w-full bg-white border border-slate-200 rounded-xl p-2 text-xs">
              <input type="password" placeholder="Confirmar nueva contraseña" class="w-full bg-white border border-slate-200 rounded-xl p-2 text-xs">
            </div>
            <button type="button" onclick="alert('✅ Solicitud de cambio de contraseña procesada con éxito.')" class="w-full bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs py-2 rounded-xl transition-all">
              Actualizar Contraseña
            </button>
          </div>

          <!-- Verificación 2FA y Sesiones -->
          <div class="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
            <div>
              <div class="flex items-center justify-between">
                <div>
                  <p class="text-xs font-bold text-slate-800">Verificación en Dos Pasos (2FA)</p>
                  <p class="text-[11px] text-slate-500">Autenticación adicional mediante aplicación o SMS</p>
                </div>
                <input type="checkbox" ${s.profile.twoFactor ? 'checked' : ''} onchange="toggle2FA(this.checked)" class="w-5 h-5 text-blue-600 rounded cursor-pointer">
              </div>
              <span class="inline-block mt-2 text-[10px] font-extrabold px-2 py-0.5 rounded ${s.profile.twoFactor ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'}">
                ${s.profile.twoFactor ? '✓ 2FA Activado (Google Authenticator)' : '2FA Desactivado'}
              </span>
            </div>

            <div class="pt-3 border-t border-slate-200">
              <p class="text-xs font-bold text-slate-800 mb-2">Dispositivos y Sesiones Activas (3)</p>
              <div class="space-y-1.5 text-xs text-slate-600">
                <div class="flex justify-between items-center bg-white p-2 rounded-lg border border-slate-200">
                  <span>💻 Windows PC (Sesión actual)</span>
                  <span class="text-[10px] font-bold text-emerald-600">Activo ahora</span>
                </div>
                <div class="flex justify-between items-center bg-white p-2 rounded-lg border border-slate-200">
                  <span>📱 iPhone 14 Pro (App Móvil)</span>
                  <span class="text-[10px] text-slate-400">Hace 2 hrs</span>
                </div>
              </div>
              <button type="button" onclick="alert('✅ Se han cerrado todas las sesiones en otros dispositivos.')" class="mt-2.5 text-xs font-bold text-rose-600 hover:underline">
                Cerrar todas las demás sesiones →
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Planes y Facturación -->
      <div class="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div class="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h4 class="text-base font-extrabold text-slate-800 flex items-center space-x-2">
              <span>💳</span>
              <span>Planes & Facturación</span>
            </h4>
            <p class="text-xs text-slate-500 mt-0.5">Gestión de suscripción, medios de pago y comprobantes tributarios</p>
          </div>
          <span class="bg-gradient-to-r from-amber-500 to-amber-600 text-white font-extrabold text-xs px-3 py-1 rounded-full shadow-sm">
            Plan Enterprise Hotel
          </span>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div class="p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
            <p class="text-[10px] text-slate-400 uppercase font-bold">Estado de Cuenta</p>
            <p class="text-sm font-extrabold text-emerald-700 mt-0.5">✓ Al Día / Activo</p>
            <p class="text-[11px] text-slate-500 mt-1">Próxima renovación: 30 Dic 2026</p>
          </div>

          <div class="p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
            <p class="text-[10px] text-slate-400 uppercase font-bold">Método de Pago</p>
            <p class="text-sm font-extrabold text-slate-800 mt-0.5">Visa **** 4821</p>
            <p class="text-[11px] text-blue-600 font-bold mt-1 cursor-pointer hover:underline">Cambiar tarjeta →</p>
          </div>

          <div class="p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
            <p class="text-[10px] text-slate-400 uppercase font-bold">Facturas Recientes</p>
            <p class="text-sm font-extrabold text-slate-800 mt-0.5">Folio #84920-CL</p>
            <button onclick="alert('Descargando factura en PDF...')" class="text-[11px] text-blue-600 font-bold mt-1 hover:underline">Descargar PDF →</button>
          </div>
        </div>
      </div>

      <!-- Zona de Peligro / Eliminar Cuenta -->
      <div class="bg-rose-50/60 rounded-3xl p-6 border-2 border-rose-200 shadow-sm space-y-3">
        <div class="flex items-center justify-between">
          <div>
            <h4 class="text-sm font-extrabold text-rose-900 flex items-center space-x-2">
              <span>⚠️</span>
              <span>Zona de Peligro: Desactivar o Eliminar Cuenta</span>
            </h4>
            <p class="text-xs text-rose-700 mt-0.5">Esta acción revocará accesos, eliminará credenciales y requiere confirmación administrativa.</p>
          </div>
          <button onclick="handleDeleteAccountPrompt()" class="bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-md transition-colors flex-shrink-0">
            Darse de Baja
          </button>
        </div>
      </div>

    </div>
  `;
}

// ==========================================================
// 2. PREFERENCIAS DE LA INTERFAZ (ASPECTO)
// ==========================================================
function renderSectionAppearance(s) {
  return `
    <div class="space-y-6">
      
      <!-- Tema de Color -->
      <div class="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div>
          <h4 class="text-base font-extrabold text-slate-800 flex items-center space-x-2">
            <span>🎨</span>
            <span>Tema Visual del Sistema</span>
          </h4>
          <p class="text-xs text-slate-500 mt-0.5">Selecciona el modo de contraste y visualización que prefieras</p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          <!-- Modo Claro -->
          <div onclick="setThemePreference('light')" class="p-4 rounded-2xl border-2 cursor-pointer transition-all card-hover ${s.appearance.theme === 'light' ? 'border-blue-600 bg-blue-50/70 ring-2 ring-blue-500/20' : 'border-slate-200 bg-white'}">
            <div class="h-20 bg-slate-100 rounded-xl p-2.5 flex flex-col justify-between border border-slate-200 mb-3 shadow-inner">
              <div class="flex items-center space-x-1.5">
                <span class="w-3 h-3 rounded-full bg-rose-400"></span>
                <span class="w-3 h-3 rounded-full bg-amber-400"></span>
                <span class="w-3 h-3 rounded-full bg-emerald-400"></span>
              </div>
              <div class="bg-white rounded p-1 shadow-sm text-[9px] font-bold text-slate-700">☀️ Modo Claro</div>
            </div>
            <div class="flex items-center justify-between">
              <span class="text-xs font-extrabold text-slate-800">Modo Claro (Soleado)</span>
              ${s.appearance.theme === 'light' ? '<span class="text-blue-600 font-black">✓ Activo</span>' : ''}
            </div>
            <p class="text-[11px] text-slate-500 mt-0.5">Recomendado para uso diurno</p>
          </div>

          <!-- Modo Oscuro -->
          <div onclick="setThemePreference('dark')" class="p-4 rounded-2xl border-2 cursor-pointer transition-all card-hover ${s.appearance.theme === 'dark' ? 'border-blue-600 bg-blue-50/70 ring-2 ring-blue-500/20' : 'border-slate-200 bg-white'}">
            <div class="h-20 bg-slate-900 rounded-xl p-2.5 flex flex-col justify-between border border-slate-800 mb-3 shadow-inner">
              <div class="flex items-center space-x-1.5">
                <span class="w-3 h-3 rounded-full bg-rose-500"></span>
                <span class="w-3 h-3 rounded-full bg-amber-500"></span>
                <span class="w-3 h-3 rounded-full bg-emerald-500"></span>
              </div>
              <div class="bg-slate-800 rounded p-1 shadow-sm text-[9px] font-bold text-slate-200">🌙 Modo Oscuro</div>
            </div>
            <div class="flex items-center justify-between">
              <span class="text-xs font-extrabold text-slate-800">Modo Oscuro (Noche)</span>
              ${s.appearance.theme === 'dark' ? '<span class="text-blue-600 font-black">✓ Activo</span>' : ''}
            </div>
            <p class="text-[11px] text-slate-500 mt-0.5">Reduce fatiga visual nocturna</p>
          </div>

          <!-- Seguir Sistema -->
          <div onclick="setThemePreference('system')" class="p-4 rounded-2xl border-2 cursor-pointer transition-all card-hover ${s.appearance.theme === 'system' ? 'border-blue-600 bg-blue-50/70 ring-2 ring-blue-500/20' : 'border-slate-200 bg-white'}">
            <div class="h-20 bg-gradient-to-r from-slate-100 to-slate-900 rounded-xl p-2.5 flex flex-col justify-between border border-slate-300 mb-3 shadow-inner">
              <div class="flex items-center space-x-1.5">
                <span class="w-3 h-3 rounded-full bg-blue-400"></span>
              </div>
              <div class="bg-white/90 rounded p-1 shadow-sm text-[9px] font-bold text-slate-900 text-center">💻 Automático</div>
            </div>
            <div class="flex items-center justify-between">
              <span class="text-xs font-extrabold text-slate-800">Seguir el Sistema</span>
              ${s.appearance.theme === 'system' ? '<span class="text-blue-600 font-black">✓ Activo</span>' : ''}
            </div>
            <p class="text-[11px] text-slate-500 mt-0.5">Sincroniza con Windows / macOS</p>
          </div>
        </div>
      </div>

      <!-- Accesibilidad -->
      <div class="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div>
          <h4 class="text-base font-extrabold text-slate-800 flex items-center space-x-2">
            <span>👁️</span>
            <span>Accesibilidad Visual</span>
          </h4>
          <p class="text-xs text-slate-500 mt-0.5">Adapta la interfaz para máxima legibilidad del equipo de terreno</p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div class="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
            <label class="block text-xs font-bold text-slate-700 uppercase">Tamaño de Texto</label>
            <select onchange="state.settings.appearance.fontSize = this.value; saveState(); alert('Tamaño de texto ajustado a: ' + this.value);" class="w-full bg-white border border-slate-200 rounded-xl p-2 text-xs font-semibold">
              <option value="small" ${s.appearance.fontSize === 'small' ? 'selected' : ''}>Compacto (Pequeño)</option>
              <option value="normal" ${s.appearance.fontSize === 'normal' ? 'selected' : ''}>Estándar (Recomendado)</option>
              <option value="large" ${s.appearance.fontSize === 'large' ? 'selected' : ''}>Grande (Lectura fácil)</option>
              <option value="xlarge" ${s.appearance.fontSize === 'xlarge' ? 'selected' : ''}>Extra Grande</option>
            </select>
            <p class="text-[10px] text-slate-500">Aumenta los títulos y textos de las tarjetas para dispositivos móviles.</p>
          </div>

          <div class="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
            <div class="flex items-center justify-between">
              <div>
                <p class="text-xs font-bold text-slate-800">Alto Contraste</p>
                <p class="text-[10px] text-slate-500">Bordes reforzados para luz solar directa</p>
              </div>
              <input type="checkbox" ${s.appearance.highContrast ? 'checked' : ''} onchange="state.settings.appearance.highContrast = this.checked; saveState();" class="w-5 h-5 text-blue-600 rounded cursor-pointer">
            </div>
            <div class="flex items-center justify-between pt-2 border-t border-slate-200">
              <div>
                <p class="text-xs font-bold text-slate-800">Lector de Pantalla / Screen Reader</p>
                <p class="text-[10px] text-slate-500">Compatibilidad ARIA optimizada</p>
              </div>
              <input type="checkbox" ${s.appearance.screenReader ? 'checked' : ''} onchange="state.settings.appearance.screenReader = this.checked; saveState();" class="w-5 h-5 text-blue-600 rounded cursor-pointer">
            </div>
          </div>
        </div>
      </div>

      <!-- Idioma y Región -->
      <div class="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div>
          <h4 class="text-base font-extrabold text-slate-800 flex items-center space-x-2">
            <span>🌐</span>
            <span>Idioma & Configuración Regional</span>
          </h4>
          <p class="text-xs text-slate-500 mt-0.5">Formato de fechas, zona horaria y moneda de las órdenes de trabajo</p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Idioma de la App</label>
            <select class="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-semibold text-slate-800">
              <option value="es" selected>🇨🇱 Español (Chile)</option>
              <option value="en">🇺🇸 English (US)</option>
              <option value="pt">🇧🇷 Português (Brasil)</option>
            </select>
          </div>

          <div>
            <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Zona Horaria</label>
            <select class="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-semibold text-slate-800">
              <option value="America/Santiago" selected>Santiago de Chile (GMT-3)</option>
              <option value="America/Buenos_Aires">Buenos Aires (GMT-3)</option>
              <option value="America/Lima">Lima (GMT-5)</option>
              <option value="UTC">UTC Universal</option>
            </select>
          </div>

          <div>
            <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Formato de Moneda</label>
            <select class="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-semibold text-slate-800">
              <option value="CLP" selected>Peso Chileno ($ CLP)</option>
              <option value="USD">Dólar Estadounidense ($ USD)</option>
              <option value="EUR">Euro (€ EUR)</option>
            </select>
          </div>
        </div>
      </div>

    </div>
  `;
}

// ==========================================================
// 3. NOTIFICACIONES
// ==========================================================
function renderSectionNotifications(s) {
  return `
    <div class="space-y-6">
      
      <!-- Canales de Notificación -->
      <div class="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div>
          <h4 class="text-base font-extrabold text-slate-800 flex items-center space-x-2">
            <span>🔔</span>
            <span>Canales de Envío de Avisos</span>
          </h4>
          <p class="text-xs text-slate-500 mt-0.5">Elige por qué medios recibir las alertas de mantención y garantías</p>
        </div>

        <div class="space-y-3">
          <div class="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
            <div class="flex items-center space-x-3">
              <span class="text-2xl">💻</span>
              <div>
                <p class="text-xs font-bold text-slate-800">Notificaciones Push en Navegador</p>
                <p class="text-[11px] text-slate-500">Alertas emergentes directas en la pantalla de escritorio o móvil</p>
              </div>
            </div>
            <input type="checkbox" ${s.notifications.push ? 'checked' : ''} onchange="state.settings.notifications.push = this.checked; saveState();" class="w-5 h-5 text-blue-600 rounded cursor-pointer">
          </div>

          <div class="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
            <div class="flex items-center space-x-3">
              <span class="text-2xl">✉️</span>
              <div>
                <p class="text-xs font-bold text-slate-800">Correos Electrónicos (Email)</p>
                <p class="text-[11px] text-slate-500">Envío de resumen y órdenes de trabajo a ${s.profile.email}</p>
              </div>
            </div>
            <input type="checkbox" ${s.notifications.email ? 'checked' : ''} onchange="state.settings.notifications.email = this.checked; saveState();" class="w-5 h-5 text-blue-600 rounded cursor-pointer">
          </div>

          <div class="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
            <div class="flex items-center space-x-3">
              <span class="text-2xl">📱</span>
              <div>
                <p class="text-xs font-bold text-slate-800">Mensajes SMS / WhatsApp Urgentes</p>
                <p class="text-[11px] text-slate-500">Solo para mantenciones de prioridad CRÍTICA o emergencias en habitaciones</p>
              </div>
            </div>
            <input type="checkbox" ${s.notifications.sms ? 'checked' : ''} onchange="state.settings.notifications.sms = this.checked; saveState();" class="w-5 h-5 text-blue-600 rounded cursor-pointer">
          </div>
        </div>
      </div>

      <!-- Frecuencia y Modo No Molestar -->
      <div class="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div>
          <h4 class="text-base font-extrabold text-slate-800 flex items-center space-x-2">
            <span>⏱️</span>
            <span>Frecuencia & Horarios de Silencio</span>
          </h4>
          <p class="text-xs text-slate-500 mt-0.5">Controla cuándo y con qué periodicidad se envían los resúmenes</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
          <!-- Frecuencia -->
          <div class="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
            <label class="block text-xs font-bold text-slate-700 uppercase">Frecuencia de Notificaciones</label>
            <div class="space-y-2 pt-1">
              <label class="flex items-center space-x-2 text-xs font-semibold text-slate-800 cursor-pointer">
                <input type="radio" name="notif-freq" value="instant" ${s.notifications.frequency === 'instant' ? 'checked' : ''} onchange="state.settings.notifications.frequency = this.value; saveState();">
                <span>⚡ Inmediata (Al instante de crearse el requerimiento)</span>
              </label>
              <label class="flex items-center space-x-2 text-xs font-semibold text-slate-800 cursor-pointer">
                <input type="radio" name="notif-freq" value="daily" ${s.notifications.frequency === 'daily' ? 'checked' : ''} onchange="state.settings.notifications.frequency = this.value; saveState();">
                <span>📋 Resumen Diario Consolidado (08:00 AM)</span>
              </label>
              <label class="flex items-center space-x-2 text-xs font-semibold text-slate-800 cursor-pointer">
                <input type="radio" name="notif-freq" value="weekly" ${s.notifications.frequency === 'weekly' ? 'checked' : ''} onchange="state.settings.notifications.frequency = this.value; saveState();">
                <span>📅 Resumen Semanal de Operaciones (Lunes)</span>
              </label>
            </div>
          </div>

          <!-- Modo No Molestar -->
          <div class="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
            <div class="flex items-center justify-between">
              <div>
                <p class="text-xs font-bold text-slate-800">Modo No Molestar Automatizado</p>
                <p class="text-[10px] text-slate-500">Silencia alertas durante el turno nocturno</p>
              </div>
              <input type="checkbox" ${s.notifications.doNotDisturb ? 'checked' : ''} onchange="state.settings.notifications.doNotDisturb = this.checked; saveState(); renderCurrentView();" class="w-5 h-5 text-blue-600 rounded cursor-pointer">
            </div>

            <div class="grid grid-cols-2 gap-2 pt-2 border-t border-slate-200">
              <div>
                <label class="text-[10px] font-bold text-slate-500 uppercase">Inicio Silencio</label>
                <input type="time" value="${s.notifications.dndStart}" class="w-full bg-white border border-slate-200 rounded-lg p-1.5 text-xs font-semibold">
              </div>
              <div>
                <label class="text-[10px] font-bold text-slate-500 uppercase">Fin Silencio</label>
                <input type="time" value="${s.notifications.dndEnd}" class="w-full bg-white border border-slate-200 rounded-lg p-1.5 text-xs font-semibold">
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  `;
}

// ==========================================================
// 4. PRIVACIDAD Y DATOS
// ==========================================================
function renderSectionPrivacy(s) {
  return `
    <div class="space-y-6">
      
      <!-- Visibilidad y Permisos -->
      <div class="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div>
          <h4 class="text-base font-extrabold text-slate-800 flex items-center space-x-2">
            <span>🔒</span>
            <span>Visibilidad del Perfil & Permisos del Dispositivo</span>
          </h4>
          <p class="text-xs text-slate-500 mt-0.5">Controla quién puede ver tus registros y el acceso a hardware para registrar fotos y ubicación</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
          <!-- Visibilidad -->
          <div class="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
            <h5 class="text-xs font-bold text-slate-800 uppercase">Visibilidad de Perfil</h5>
            <div class="space-y-2">
              <label class="flex items-center space-x-2 text-xs font-medium text-slate-800 cursor-pointer">
                <input type="radio" name="privacy-vis" value="public" ${s.privacy.visibility === 'public' ? 'checked' : ''}>
                <span>🏢 Todo el personal de El Almendro</span>
              </label>
              <label class="flex items-center space-x-2 text-xs font-medium text-slate-800 cursor-pointer">
                <input type="radio" name="privacy-vis" value="team" ${s.privacy.visibility === 'team' ? 'checked' : ''}>
                <span>👷 Solo equipo de Operaciones y Mantención</span>
              </label>
              <label class="flex items-center space-x-2 text-xs font-medium text-slate-800 cursor-pointer">
                <input type="radio" name="privacy-vis" value="private" ${s.privacy.visibility === 'private' ? 'checked' : ''}>
                <span>🔒 Privado (Solo administradores)</span>
              </label>
            </div>
          </div>

          <!-- Permisos del Dispositivo -->
          <div class="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2.5">
            <h5 class="text-xs font-bold text-slate-800 uppercase">Permisos de Hardware</h5>
            
            <div class="flex items-center justify-between text-xs">
              <span class="flex items-center space-x-2"><span>📷</span><span>Cámara (Fotos antes/después)</span></span>
              <input type="checkbox" ${s.privacy.camera ? 'checked' : ''} onchange="state.settings.privacy.camera = this.checked; saveState();" class="w-4 h-4 text-blue-600 rounded">
            </div>

            <div class="flex items-center justify-between text-xs">
              <span class="flex items-center space-x-2"><span>📍</span><span>Ubicación GPS (Áreas del terreno)</span></span>
              <input type="checkbox" ${s.privacy.location ? 'checked' : ''} onchange="state.settings.privacy.location = this.checked; saveState();" class="w-4 h-4 text-blue-600 rounded">
            </div>

            <div class="flex items-center justify-between text-xs">
              <span class="flex items-center space-x-2"><span>🎤</span><span>Micrófono (Dictado de fallas)</span></span>
              <input type="checkbox" ${s.privacy.mic ? 'checked' : ''} onchange="state.settings.privacy.mic = this.checked; saveState();" class="w-4 h-4 text-blue-600 rounded">
            </div>
          </div>
        </div>
      </div>

      <!-- Descarga de Datos & Analíticas -->
      <div class="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div>
          <h4 class="text-base font-extrabold text-slate-800 flex items-center space-x-2">
            <span>📦</span>
            <span>Descarga de Información & Analíticas</span>
          </h4>
          <p class="text-xs text-slate-500 mt-0.5">Exportación completa de datos para auditorías o respaldo de hotel</p>
        </div>

        <div class="p-4 bg-blue-50/60 rounded-2xl border border-blue-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            <p class="text-xs font-bold text-blue-900">Descargar Copia Completa de Datos (JSON / ZIP)</p>
            <p class="text-[11px] text-blue-700 mt-0.5">Incluye todas las órdenes de trabajo, fichas de activos fijos, garantías y fotos.</p>
          </div>
          <button onclick="handleExportData()" class="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-md transition-all flex items-center space-x-1.5 flex-shrink-0">
            <span>📥</span>
            <span>Exportar Todo</span>
          </button>
        </div>

        <div class="pt-3 border-t border-slate-100 flex items-center justify-between">
          <div>
            <p class="text-xs font-bold text-slate-800">Cookies y Analíticas de Diagnóstico</p>
            <p class="text-[11px] text-slate-500">Permite registrar tiempos de carga de imágenes para mejorar la app</p>
          </div>
          <input type="checkbox" ${s.privacy.analytics ? 'checked' : ''} onchange="state.settings.privacy.analytics = this.checked; saveState();" class="w-5 h-5 text-blue-600 rounded cursor-pointer">
        </div>
      </div>

    </div>
  `;
}

// ==========================================================
// 5. ALMACENAMIENTO Y CONECTIVIDAD
// ==========================================================
function renderSectionStorage(s) {
  return `
    <div class="space-y-6">
      
      <!-- Limpieza de Caché y Espacio -->
      <div class="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div>
          <h4 class="text-base font-extrabold text-slate-800 flex items-center space-x-2">
            <span>💾</span>
            <span>Espacio de Almacenamiento & Caché Local</span>
          </h4>
          <p class="text-xs text-slate-500 mt-0.5">Gestiona las imágenes en memoria del navegador para optimizar la velocidad</p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div class="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
            <div>
              <p class="text-[10px] font-bold text-slate-400 uppercase">Caché en Uso</p>
              <p id="cfg-cache-size" class="text-2xl font-black text-slate-800 mt-1">${localCacheSize} MB</p>
              <p class="text-[11px] text-slate-500 mt-0.5">Fotos de activos y pautas cacheadas</p>
            </div>
            <button onclick="handleClearCache()" class="bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition-all shadow-sm">
              🧹 Limpiar Caché
            </button>
          </div>

          <div class="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
            <div>
              <p class="text-xs font-bold text-slate-800">Descargas Solo con Wi-Fi</p>
              <p class="text-[11px] text-slate-500">Ahorra datos móviles de los técnicos en terreno</p>
            </div>
            <input type="checkbox" ${s.storage.wifiOnly ? 'checked' : ''} onchange="state.settings.storage.wifiOnly = this.checked; saveState();" class="w-5 h-5 text-blue-600 rounded cursor-pointer">
          </div>
        </div>
      </div>

      <!-- Integraciones con Terceros -->
      <div class="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div>
          <h4 class="text-base font-extrabold text-slate-800 flex items-center space-x-2">
            <span>🔗</span>
            <span>Integraciones y Conectores de Software</span>
          </h4>
          <p class="text-xs text-slate-500 mt-0.5">Sincroniza eventos y avisos con otras aplicaciones del hotel</p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <!-- Google Workspace -->
          <div class="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col justify-between">
            <div class="flex items-center space-x-2.5 mb-2">
              <span class="text-xl">📁</span>
              <div>
                <p class="text-xs font-bold text-slate-800">Google Drive</p>
                <p class="text-[10px] text-emerald-600 font-bold">✓ Conectado</p>
              </div>
            </div>
            <p class="text-[11px] text-slate-500 mb-3">Respaldo automático de facturas y fichas técnicas en la nube.</p>
            <button onclick="alert('Configuración de Google Drive')" class="text-xs font-bold text-blue-600 hover:underline text-left">Ajustes de Sync →</button>
          </div>

          <!-- Slack / Teams -->
          <div class="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col justify-between">
            <div class="flex items-center space-x-2.5 mb-2">
              <span class="text-xl">💬</span>
              <div>
                <p class="text-xs font-bold text-slate-800">Slack / Teams</p>
                <p class="text-[10px] text-emerald-600 font-bold">✓ Canal #mantencion</p>
              </div>
            </div>
            <p class="text-[11px] text-slate-500 mb-3">Envío instantáneo de órdenes correctivas al canal de operaciones.</p>
            <button onclick="alert('Canal de Slack configurado')" class="text-xs font-bold text-blue-600 hover:underline text-left">Reconectar →</button>
          </div>

          <!-- WhatsApp Hotelero -->
          <div class="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col justify-between">
            <div class="flex items-center space-x-2.5 mb-2">
              <span class="text-xl">📱</span>
              <div>
                <p class="text-xs font-bold text-slate-800">WhatsApp API</p>
                <p class="text-[10px] text-slate-400 font-bold">Disponible</p>
              </div>
            </div>
            <p class="text-[11px] text-slate-500 mb-3">Recepción de solicitudes de mucamas vía mensajes de WhatsApp.</p>
            <button onclick="alert('Funcionalidad lista para conectar con API de WhatsApp')" class="text-xs font-bold text-blue-600 hover:underline text-left">+ Conectar API →</button>
          </div>
        </div>
      </div>

    </div>
  `;
}

// ==========================================================
// 6. AYUDA Y SOPORTE
// ==========================================================
function renderSectionSupport() {
  return `
    <div class="space-y-6">
      
      <!-- Centro de Ayuda & FAQ -->
      <div class="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div>
          <h4 class="text-base font-extrabold text-slate-800 flex items-center space-x-2">
            <span>❓</span>
            <span>Centro de Ayuda & Preguntas Frecuentes</span>
          </h4>
          <p class="text-xs text-slate-500 mt-0.5">Respuestas rápidas para el uso diario del software en El Almendro</p>
        </div>

        <div class="space-y-2.5">
          <div class="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 cursor-pointer hover:bg-blue-50/40 transition-colors" onclick="toggleFaq('faq-1')">
            <div class="flex items-center justify-between">
              <p class="text-xs font-bold text-slate-800">¿Cómo convertir una solicitud de recepción en una orden de trabajo?</p>
              <span class="text-xs text-blue-600 font-bold">▼</span>
            </div>
            <p id="faq-1" class="hidden text-xs text-slate-600 mt-2 pt-2 border-t border-slate-200 leading-relaxed">
              Dirígete a la pestaña <strong>📩 Solicitudes</strong>, busca la tarjeta requerida y presiona el botón <em>"⚡ Convertir en Trabajo"</em>. Podrás asignarlo como Mantención Preventiva, Correctiva, Esporádica, Proyecto de Mejora o Remodelación con 1 solo clic.
            </p>
          </div>

          <div class="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 cursor-pointer hover:bg-blue-50/40 transition-colors" onclick="toggleFaq('faq-2')">
            <div class="flex items-center justify-between">
              <p class="text-xs font-bold text-slate-800">¿Cómo calcula el sistema los vencimientos de garantías?</p>
              <span class="text-xs text-blue-600 font-bold">▼</span>
            </div>
            <p id="faq-2" class="hidden text-xs text-slate-600 mt-2 pt-2 border-t border-slate-200 leading-relaxed">
              El sistema evalúa diariamente la fecha de término registrada en la ficha del activo contra la fecha actual. Si restan menos de 60 días emite alerta amarilla 🟡, y si ya expiró pasa automáticamente a estado rojo 🔴 para planificar mantención propia.
            </p>
          </div>

          <div class="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 cursor-pointer hover:bg-blue-50/40 transition-colors" onclick="toggleFaq('faq-3')">
            <div class="flex items-center justify-between">
              <p class="text-xs font-bold text-slate-800">¿Cómo usar la calculadora de materiales de remodelaciones?</p>
              <span class="text-xs text-blue-600 font-bold">▼</span>
            </div>
            <p id="faq-3" class="hidden text-xs text-slate-600 mt-2 pt-2 border-t border-slate-200 leading-relaxed">
              En el módulo <strong>🏗️ Remodelaciones</strong>, abre cualquier espacio (ej: Suite 104) y agrega insumos indicando nombre, cantidad y costo unitario. El sistema sumará automáticamente el costo total de materiales en tiempo real.
            </p>
          </div>
        </div>
      </div>

      <!-- Reportar un Problema / Feedback -->
      <div class="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div>
          <h4 class="text-base font-extrabold text-slate-800 flex items-center space-x-2">
            <span>🛠️</span>
            <span>Reportar un Problema o Sugerencia Técnica</span>
          </h4>
          <p class="text-xs text-slate-500 mt-0.5">Envía un reporte directo al equipo de desarrollo con captura de pantalla</p>
        </div>

        <form onsubmit="handleReportIssue(event)" class="space-y-3">
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Tipo de Reporte</label>
              <select id="rep-type" class="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-semibold">
                <option value="error">🐛 Error en pantalla / Bug</option>
                <option value="mejora">💡 Sugerencia de mejora UX</option>
                <option value="duda">❓ Duda de funcionamiento</option>
              </select>
            </div>
            <div>
              <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Módulo Afectado</label>
              <select id="rep-module" class="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs font-semibold">
                <option value="gantt">Línea de Tiempo / Gantt</option>
                <option value="mantenciones">Mantenciones</option>
                <option value="activos">Activos Fijos</option>
                <option value="remodelaciones">Remodelaciones</option>
                <option value="solicitudes">Solicitudes</option>
              </select>
            </div>
          </div>

          <div>
            <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Descripción del Incidente *</label>
            <textarea id="rep-desc" required rows="3" placeholder="Describe qué ocurrió, qué botón presionaste o qué mejora sugieres..." class="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs"></textarea>
          </div>

          <div class="flex items-center justify-between pt-1">
            <button type="button" class="text-xs font-bold text-slate-600 hover:text-blue-600 flex items-center space-x-1">
              <span>📎</span>
              <span>Adjuntar Captura de Pantalla</span>
            </button>
            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-md transition-all">
              Enviar Reporte a Soporte
            </button>
          </div>
        </form>
      </div>

      <!-- Versión & Legal -->
      <div class="bg-slate-50 rounded-3xl p-6 border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
        <div>
          <p class="font-extrabold text-slate-800">Hotel Gestor Mantención & Activos Fijos</p>
          <p class="text-slate-500 mt-0.5">Versión actual: <strong>v2.4.0 (Build 2026.09.02-hotelfix)</strong></p>
          <div class="flex items-center space-x-3 mt-2 text-slate-500">
            <a href="#" onclick="alert('Términos de Servicio'); return false;" class="hover:underline">Términos de Servicio</a>
            <span>•</span>
            <a href="#" onclick="alert('Política de Privacidad'); return false;" class="hover:underline">Política de Privacidad</a>
            <span>•</span>
            <a href="#" onclick="alert('Licencia Prototipo'); return false;" class="hover:underline">Licencia Comercial</a>
          </div>
        </div>
        <button onclick="handleCheckUpdates()" class="bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-bold px-4 py-2 rounded-xl shadow-sm transition-colors flex-shrink-0">
          🔄 Buscar Actualizaciones
        </button>
      </div>

    </div>
  `;
}

// ==========================================================
// 7. PARÁMETROS DEL HOTEL & RESTABLECIMIENTO
// ==========================================================
function renderSectionHotelParams() {
  return `
    <div class="space-y-6">
      
      <div class="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-6">
        <div>
          <h4 class="text-base font-extrabold text-slate-800 flex items-center space-x-2">
            <span>⚙️</span>
            <span>Parámetros Operativos del Hotel</span>
          </h4>
          <p class="text-xs text-slate-500 mt-0.5">Hotel & Centro de Eventos El Almendro</p>
        </div>

        <div class="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
          <h5 class="text-xs font-extrabold text-slate-800 uppercase">Umbrales de Alerta de Garantía (Días previos)</h5>
          <p class="text-xs text-slate-600">El sistema emitirá notificaciones automáticas cuando falten los siguientes días para que expire una garantía:</p>
          
          <div class="flex flex-wrap items-center gap-2 pt-1">
            <span class="px-3 py-1.5 bg-amber-100 text-amber-800 font-bold text-xs rounded-xl border border-amber-200">🟡 60 Días Previos</span>
            <span class="px-3 py-1.5 bg-amber-100 text-amber-800 font-bold text-xs rounded-xl border border-amber-200">🟡 30 Días Previos</span>
            <span class="px-3 py-1.5 bg-amber-100 text-amber-800 font-bold text-xs rounded-xl border border-amber-200">🟡 15 Días Previos</span>
            <span class="px-3 py-1.5 bg-rose-100 text-rose-800 font-bold text-xs rounded-xl border border-rose-200">🔴 7 Días (Crítico)</span>
          </div>
        </div>

        <div class="pt-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <h5 class="text-sm font-bold text-slate-800">Restablecer Datos de Prueba del Prototipo</h5>
            <p class="text-xs text-slate-500 mt-0.5">Vuelve al dataset ficticio original de El Almendro (9 áreas, 12 activos, 15 mantenciones).</p>
          </div>
          <button onclick="resetToFactoryData()" class="bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold px-4 py-2.5 rounded-xl transition-colors flex-shrink-0">
            Restablecer Prototipo
          </button>
        </div>
      </div>

    </div>
  `;
}

// ==========================================================
// CONTROLADORES DE ACCIONES DE CONFIGURACIÓN
// ==========================================================
function selectAvatar(emoji) {
  if (state.settings && state.settings.profile) {
    state.settings.profile.avatar = emoji;
  }
  const el = document.getElementById('cfg-profile-avatar');
  if (el) el.textContent = emoji;
}

function handleSaveProfile(e) {
  e.preventDefault();
  const name = document.getElementById('cfg-name').value;
  const email = document.getElementById('cfg-email').value;
  const phone = document.getElementById('cfg-phone').value;

  if (state.settings && state.settings.profile) {
    state.settings.profile.name = name;
    state.settings.profile.email = email;
    state.settings.profile.phone = phone;
  }
  if (state.currentUser) {
    state.currentUser.name = name;
    state.currentUser.email = email;
  }
  saveState();
  alert("✅ Perfil de usuario actualizado correctamente.");
}

function toggle2FA(checked) {
  if (state.settings && state.settings.profile) {
    state.settings.profile.twoFactor = checked;
    saveState();
  }
}

function setThemePreference(theme) {
  if (state.settings && state.settings.appearance) {
    state.settings.appearance.theme = theme;
    saveState();
  }
}

function toggleFaq(faqId) {
  const el = document.getElementById(faqId);
  if (el) {
    el.classList.toggle('hidden');
  }
}

function handleClearCache() {
  localCacheSize = 0.0;
  const el = document.getElementById('cfg-cache-size');
  if (el) el.textContent = '0.0 MB';
  alert("🧹 Caché de imágenes y fichas liberado con éxito (0.0 MB).");
}

function handleExportData() {
  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(state, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute("href", dataStr);
  downloadAnchor.setAttribute("download", `hotel_el_almendro_backup_${new Date().toISOString().slice(0,10)}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}

function handleReportIssue(e) {
  e.preventDefault();
  const desc = document.getElementById('rep-desc').value;
  alert("✅ Gracias. Tu reporte ha sido enviado al equipo técnico de soporte con ID #REP-" + Date.now().toString().slice(-4));
  document.getElementById('rep-desc').value = '';
}

function handleCheckUpdates() {
  alert("🔍 Comprobando actualizaciones...\n\n✅ Tu sistema está actualizado a la última versión v2.4.0.");
}

function handleDeleteAccountPrompt() {
  const confirmText = prompt("Para darte de baja escribe 'ELIMINAR':");
  if (confirmText === 'ELIMINAR') {
    alert("⚠️ Cuenta suspendida temporalmente. Contacta a la administración para reactivar.");
  }
}
