// ==========================================================
// VISTA: SOLICITUDES & BANDEJA DE ENTRADA - HOTEL EL ALMENDRO
// ==========================================================

function renderRequestsView() {
  return `
    <div class="space-y-6 max-w-7xl mx-auto pb-10">
      
      <!-- ENCABEZADO CON EL BOTÓN EXCLUSIVO DE NUEVA SOLICITUD -->
      <div class="bg-gradient-to-r from-blue-900 via-indigo-950 to-blue-900 rounded-3xl p-6 text-white shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <span class="bg-blue-400/20 text-blue-200 text-xs font-extrabold px-3 py-1 rounded-full uppercase">Bandeja de Requerimientos</span>
          <h3 class="text-2xl font-black mt-2">Solicitudes de Personal y Recepción</h3>
          <p class="text-blue-100/80 text-xs mt-1">Crea nuevas solicitudes o conviértelas con un clic en órdenes de mantención, mejoras o remodelaciones.</p>
        </div>
        
        <!-- BOTÓN PRINCIPAL EXCLUSIVO -->
        <button onclick="openNewRequestModal()" class="bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-400 hover:to-indigo-400 text-white font-extrabold text-sm px-6 py-3.5 rounded-2xl shadow-xl shadow-blue-500/30 flex items-center space-x-2 transition-all transform active:scale-95 flex-shrink-0">
          <span class="text-xl leading-none">+</span>
          <span>NUEVA SOLICITUD</span>
        </button>
      </div>

      <!-- CUADRÍCULA DE SOLICITUDES -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        ${state.requests.map(req => {
          const priorityColors = {
            'Baja': 'text-slate-600 bg-slate-100',
            'Media': 'text-blue-700 bg-blue-100',
            'Alta': 'text-amber-800 bg-amber-100 font-bold',
            'Crítica': 'text-rose-800 bg-rose-100 font-black'
          };

          return `
            <div class="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm hover:shadow-lg transition-all flex flex-col justify-between card-hover">
              
              <div>
                <div class="flex items-center justify-between mb-2.5">
                  <span class="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${priorityColors[req.priority]}">
                    ${req.priority}
                  </span>
                  <span class="text-[11px] font-extrabold text-slate-600">${req.areaName}</span>
                </div>

                <h4 class="text-base font-bold text-slate-800 leading-snug">
                  ${req.title}
                </h4>

                <div class="mt-2 text-xs text-slate-600 flex items-center space-x-1">
                  <span>📍</span>
                  <span class="font-medium text-slate-700">${req.location}</span>
                </div>

                <p class="text-xs text-slate-600 mt-2.5 leading-relaxed bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  "${req.description}"
                </p>
              </div>

              <div class="mt-4 pt-3 border-t border-slate-100">
                <div class="text-[11px] text-slate-600 mb-3 flex items-center justify-between">
                  <span>Solicitado por: <strong>${req.requesterName}</strong></span>
                  <span>${req.createdDate}</span>
                </div>

                ${req.status === 'Pendiente' ? `
                  <button onclick="openConvertRequestModal('${req.id}')" class="w-full py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center space-x-1.5">
                    <span>⚡</span>
                    <span>Convertir en Trabajo</span>
                  </button>
                ` : `
                  <div class="w-full py-1.5 bg-emerald-50 text-emerald-700 font-bold text-xs rounded-xl text-center border border-emerald-200">
                    ✓ Convertida a ${req.convertedTo ? req.convertedTo.type : 'Trabajo'}
                  </div>
                `}
              </div>

            </div>
          `;
        }).join('')}
      </div>

    </div>
  `;
}
