// ==========================================================
// VISTA: REMODELACIONES & CALCULADORA - HOTEL EL ALMENDRO
// ==========================================================

function renderRenovationsView() {
  return `
    <div class="space-y-6 max-w-7xl mx-auto pb-10">
      
      <div class="bg-gradient-to-r from-purple-900 via-indigo-950 to-purple-900 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <span class="bg-purple-400/20 text-purple-200 text-xs font-extrabold px-3 py-1 rounded-full uppercase">Intervención de Espacios</span>
          <h3 class="text-2xl font-black mt-2">Remodelaciones & Cómputo de Materiales</h3>
          <p class="text-purple-100/80 text-xs mt-1">Gestión de partidas, insumos y cálculo automático del costo total del proyecto.</p>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        ${state.renovations.map(ren => {
          const totalMaterials = (ren.materials || []).reduce((acc, m) => acc + (m.subtotal || 0), 0);

          return `
            <div onclick="openRenovationDetail('${ren.id}')" class="bg-white rounded-3xl p-6 border-2 border-slate-200 hover:border-purple-500 shadow-sm hover:shadow-xl transition-all cursor-pointer card-hover flex flex-col justify-between group">
              
              <div>
                <div class="flex items-center justify-between mb-3">
                  <span class="text-xs font-extrabold bg-purple-100 text-purple-800 px-3 py-1 rounded-lg">
                    🏗️ ${ren.space}
                  </span>
                  <span class="text-xs font-bold px-2.5 py-0.5 rounded-full ${ren.status === 'Completado' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'}">
                    ${ren.status}
                  </span>
                </div>

                <h4 class="text-xl font-extrabold text-slate-800 group-hover:text-purple-700 transition-colors">
                  ${ren.name}
                </h4>

                <p class="text-xs text-slate-600 mt-2 line-clamp-2 leading-relaxed">
                  ${ren.description}
                </p>

                <div class="grid grid-cols-2 gap-3 mt-5 p-3.5 bg-purple-50/50 rounded-2xl border border-purple-100">
                  <div>
                    <p class="text-[10px] text-purple-900 font-bold uppercase">Costo Total Materiales</p>
                    <p class="text-base font-black text-purple-700">${formatCLP(totalMaterials)}</p>
                    <p class="text-[10px] text-slate-600">${ren.materials ? ren.materials.length : 0} ítems calculados</p>
                  </div>
                  <div>
                    <p class="text-[10px] text-slate-600 font-bold uppercase">Presupuesto Aprobado</p>
                    <p class="text-base font-black text-slate-800">${formatCLP(ren.budget)}</p>
                  </div>
                </div>
              </div>

              <div class="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-purple-700 group-hover:text-purple-900">
                <span>Abrir Calculadora de Materiales</span>
                <span class="group-hover:translate-x-1 transition-transform">→</span>
              </div>

            </div>
          `;
        }).join('')}
      </div>

    </div>
  `;
}
