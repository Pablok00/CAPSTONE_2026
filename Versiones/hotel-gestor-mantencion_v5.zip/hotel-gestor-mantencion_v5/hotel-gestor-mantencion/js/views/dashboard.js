// ==========================================================
// VISTA: DASHBOARD PRINCIPAL - HOTEL EL ALMENDRO
// ==========================================================

function renderDashboardView() {
  // Sincronizar alertas automáticas sin duplicar notificaciones
  syncMaintenanceAlertNotifications();

  // Cálculo dinámico de indicadores clave (KPIs)
  const kpi = getDashboardKPIs();

  // Mapeo de las 6 áreas de trabajo con sus estadísticas dinámicas
  const workAreasList = (state.workAreas || DEFAULT_WORK_AREAS).map(area => {
    const stats = getWorkAreaStats(area.id);
    return {
      ...area,
      stats
    };
  });

  // Mantenciones próximas con alertas activas (máximo 4)
  const upcomingMaintenances = (state.maintenances || [])
    .map(m => ({ m, alert: getMaintenanceAlert(m) }))
    .filter(item => item.alert && (item.alert.level === 'Próxima' || item.alert.level === 'Alta' || item.alert.level === 'Urgente' || item.alert.level === 'Vence hoy'))
    .sort((a, b) => (a.alert.daysLeft - b.alert.daysLeft))
    .slice(0, 4);

  // Garantías por vencer (máximo 4)
  const expiringWarranties = (state.assets || [])
    .map(a => ({ asset: a, wInfo: calculateWarrantyStatus(a.warranty) }))
    .filter(item => item.wInfo.status === 'Proxima' || item.wInfo.status === 'Vencida')
    .sort((a, b) => a.wInfo.daysLeft - b.wInfo.daysLeft)
    .slice(0, 4);

  // Trabajos atrasados (máximo 4)
  const overdueTasks = (state.maintenances || [])
    .map(m => ({ m, alert: getMaintenanceAlert(m) }))
    .filter(item => item.m.status === 'Atrasada' || (item.alert && item.alert.level === 'Atrasada'))
    .slice(0, 4);

  // Solicitudes nuevas pendientes (máximo 4)
  const newRequests = (state.requests || [])
    .filter(r => r.status === 'Pendiente')
    .slice(0, 4);

  return `
    <div class="space-y-8 max-w-7xl mx-auto pb-12">
      
      <!-- BANNER DE BIENVENIDA DEL HOTEL -->
      <div class="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-4 border border-slate-800">
        <div class="flex items-center space-x-4">
          <div class="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-400 to-amber-200 text-slate-950 flex items-center justify-center text-3xl font-extrabold shadow-lg shadow-amber-400/20">
            🌳
          </div>
          <div>
            <h3 class="text-xl font-bold">Hotel & Centro de Eventos El Almendro</h3>
            <p class="text-slate-300 text-xs mt-0.5">Gestión operativa centralizada • 6 Áreas de Trabajo • ${state.maintenances.length} Mantenciones • Control en tiempo real</p>
          </div>
        </div>
        <div class="flex items-center space-x-3 w-full md:w-auto">
          <button onclick="navigateTo('gantt')" class="bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold px-4 py-2.5 rounded-xl text-xs flex items-center justify-center space-x-1.5 transition-colors border border-slate-700 shadow-sm">
            <span>📈</span>
            <span>Carta Gantt Unificada</span>
          </button>
          <button onclick="openNewRequestModal()" class="bg-blue-600 hover:bg-blue-700 text-white font-bold px-4 py-2.5 rounded-xl text-xs flex items-center justify-center space-x-1.5 shadow-lg shadow-blue-600/30 transition-all">
            <span>+</span>
            <span>Nueva Solicitud</span>
          </button>
        </div>
      </div>

      <!-- ============================================================ -->
      <!-- REQUISITO 1: 4 TARJETAS KPI GENERALES (CALCULADAS DINÁMICAMENTE) -->
      <!-- ============================================================ -->
      <div class="space-y-3">
        <div class="flex items-center justify-between">
          <h3 class="text-xs font-extrabold text-slate-500 tracking-wider uppercase">Indicadores Clave del Hotel</h3>
          <span class="text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-lg flex items-center space-x-1">
            <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>Datos en Vivo</span>
          </span>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          <!-- KPI 1: Tareas activas -->
          <div class="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold text-slate-500 uppercase tracking-tight">Tareas Activas</span>
              <div class="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-xl font-bold group-hover:scale-110 transition-transform">
                📋
              </div>
            </div>
            <div class="mt-3">
              <span class="text-3xl font-black text-slate-900 leading-tight">${kpi.totalActiveTasks}</span>
              <span class="text-xs font-bold text-blue-600 ml-1.5">en curso</span>
            </div>
            <p class="text-[11px] text-slate-500 mt-1">Mantenciones, mejoras y remodelaciones en ejecución</p>
          </div>

          <!-- KPI 2: Mantenciones próximas -->
          <div class="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold text-slate-500 uppercase tracking-tight">Mantenciones Próximas</span>
              <div class="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center text-xl font-bold group-hover:scale-110 transition-transform">
                ⏰
              </div>
            </div>
            <div class="mt-3">
              <span class="text-3xl font-black text-slate-900 leading-tight">${kpi.upcomingCount}</span>
              <span class="text-xs font-bold text-amber-600 ml-1.5">por atender</span>
            </div>
            <p class="text-[11px] text-slate-500 mt-1">Fechas programadas dentro de los próximos 30 días</p>
          </div>

          <!-- KPI 3: Costo acumulado del mes -->
          <div class="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold text-slate-500 uppercase tracking-tight">Costo Acumulado Mes</span>
              <div class="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-xl font-bold group-hover:scale-110 transition-transform">
                💰
              </div>
            </div>
            <div class="mt-3">
              <span class="text-2xl sm:text-3xl font-black text-emerald-700 leading-tight">${formatCLP(kpi.totalMonthlyCost)}</span>
            </div>
            <p class="text-[11px] text-slate-500 mt-1">Inversión real en reparaciones y materiales</p>
          </div>

          <!-- KPI 4: Porcentaje de tareas completadas a tiempo -->
          <div class="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold text-slate-500 uppercase tracking-tight">% Cumplimiento a Tiempo</span>
              <div class="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center text-xl font-bold group-hover:scale-110 transition-transform">
                🎯
              </div>
            </div>
            <div class="mt-3 flex items-baseline">
              <span class="text-3xl font-black text-purple-700 leading-tight">${kpi.onTimePercentage}%</span>
              <span class="text-[11px] font-bold text-slate-500 ml-2">(${kpi.completedOnTime} a tiempo)</span>
            </div>
            <div class="w-full bg-slate-100 rounded-full h-1.5 mt-2 overflow-hidden">
              <div class="bg-purple-600 h-1.5 rounded-full" style="width: ${kpi.onTimePercentage}%"></div>
            </div>
          </div>

        </div>
      </div>

      <!-- ============================================================ -->
      <!-- REQUISITO 2: SECCIÓN "ÁREAS DE TRABAJO" (6 TARJETAS EXACTAS) -->
      <!-- ============================================================ -->
      <div class="space-y-4">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-3">
          <div>
            <div class="flex items-center space-x-2">
              <span class="text-xl">🏢</span>
              <h3 class="text-lg font-black text-slate-900 tracking-tight">Áreas de Trabajo</h3>
            </div>
            <p class="text-xs text-slate-500">Unidades de gestión operativa de El Almendro. Selecciona cualquier área para abrir su ficha completa.</p>
          </div>
          <span class="text-xs font-bold text-blue-700 bg-blue-50 border border-blue-200 px-3 py-1 rounded-xl self-start sm:self-auto">
            6 Áreas Operativas
          </span>
        </div>

        <!-- CUADRÍCULA RESPONSIVE: 3x2 en escritorio, 2 col en tablet, 1 col en móvil -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          ${workAreasList.map((area, idx) => {
    const isMain = area.isPrincipal || idx === 0;
    const activeCount = area.stats.active;
    const pendingCount = area.stats.pending;
    const delayedCount = area.stats.delayed;

    return `
              <div onclick="openAreaDetail('${area.id}')" 
                   class="bg-white rounded-3xl p-6 border-2 transition-all cursor-pointer card-hover flex flex-col justify-between group relative overflow-hidden shadow-sm hover:shadow-xl ${isMain
        ? 'border-blue-600 ring-2 ring-blue-500/20 shadow-blue-900/10'
        : 'border-slate-200 hover:border-blue-500'
      }">
                
                ${isMain ? `
                  <div class="absolute -top-0.5 right-6 bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-[10px] font-black uppercase tracking-wider px-3 py-0.5 rounded-b-xl shadow-sm">
                    ⭐ Área Principal
                  </div>
                ` : ''}

                <div>
                  <div class="flex items-center justify-between mb-3">
                    <div class="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl shadow-inner transition-transform group-hover:scale-110 ${isMain ? 'bg-blue-50 border border-blue-200' : 'bg-slate-100 group-hover:bg-blue-50'
      }">
                      ${area.icon}
                    </div>

                    <div class="flex items-center space-x-1.5">
                      ${delayedCount > 0 ? `
                        <span class="bg-rose-100 text-rose-700 border border-rose-200 text-[11px] font-extrabold px-2.5 py-0.5 rounded-full flex items-center space-x-1">
                          <span>⚠️</span>
                          <span>${delayedCount} Atrasadas</span>
                        </span>
                      ` : `
                        <span class="bg-emerald-100 text-emerald-800 text-[11px] font-bold px-2.5 py-0.5 rounded-full">
                          ✓ Al día
                        </span>
                      `}
                    </div>
                  </div>

                  <h4 class="text-xl font-extrabold text-slate-900 mt-3 group-hover:text-blue-600 transition-colors flex items-center justify-between">
                    <span>${area.name}</span>
                    <span class="text-slate-400 group-hover:text-blue-600 transition-colors text-base">↗</span>
                  </h4>

                  <p class="text-xs text-slate-800 font-semibold mt-1.5 leading-relaxed">
                    ${area.description}
                  </p>

                  ${area.bullets && area.bullets.length > 0 ? `
                    <ul class="mt-2 space-y-1 text-xs text-slate-600 bg-slate-50/70 group-hover:bg-blue-50/40 p-2 rounded-xl border border-slate-100 transition-colors">
                      ${area.bullets.map(b => `
                        <li class="flex items-start space-x-1.5">
                          <span class="text-blue-600 font-bold text-[11px]">•</span>
                          <span class="text-[11px] font-medium text-slate-700">${b}</span>
                        </li>
                      `).join('')}
                    </ul>
                  ` : ''}

                  <!-- Mini Métricas de la Tarjeta -->
                  <div class="grid grid-cols-3 gap-2 mt-5 pt-4 border-t border-slate-100">
                    <div class="bg-slate-50 group-hover:bg-blue-50/50 rounded-xl p-2.5 text-center transition-colors">
                      <p class="text-[10px] text-slate-500 font-bold uppercase">Activas</p>
                      <p class="text-lg font-black text-slate-900">${activeCount}</p>
                    </div>
                    <div class="bg-slate-50 group-hover:bg-blue-50/50 rounded-xl p-2.5 text-center transition-colors">
                      <p class="text-[10px] text-slate-500 font-bold uppercase">Pendientes</p>
                      <p class="text-lg font-black text-amber-600">${pendingCount}</p>
                    </div>
                    <div class="bg-slate-50 group-hover:bg-blue-50/50 rounded-xl p-2.5 text-center transition-colors">
                      <p class="text-[10px] text-slate-500 font-bold uppercase">Completadas</p>
                      <p class="text-lg font-black text-emerald-600">${area.stats.completed}</p>
                    </div>
                  </div>
                </div>

                <!-- Footer de Acción Visual Directa -->
                <div class="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-blue-600 group-hover:text-blue-700">
                  <span class="flex items-center space-x-1.5">
                    <span>Abrir Ficha de Área</span>
                  </span>
                  <span class="group-hover:translate-x-1 transition-transform">→</span>
                </div>

              </div>
            `;
  }).join('')}
        </div>
      </div>

      <!-- ============================================================ -->
      <!-- REQUISITO 6: RESÚMENES EN MINI-TARJETAS VISUALES (NO LISTAS) -->
      <!-- ============================================================ -->
      <div class="space-y-4 pt-2">
        <div class="flex items-center justify-between border-b border-slate-200 pb-3">
          <div>
            <h3 class="text-base font-extrabold text-slate-900 tracking-tight">Actividad Reciente en Mini-Tarjetas</h3>
            <p class="text-xs text-slate-500">Panel de seguimiento con acceso directo a detalles y órdenes.</p>
          </div>
          <span class="text-xs text-slate-500 font-medium">Cuadrícula interactiva</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          
          <!-- 1. Mantenciones Próximas (Mini-Tarjetas) -->
          <div class="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-col justify-between">
            <div>
              <div class="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                <h5 class="text-xs font-extrabold text-blue-900 uppercase flex items-center space-x-1.5">
                  <span>📅</span>
                  <span>Mantenciones Próximas</span>
                </h5>
                <button onclick="navigateTo('mantenciones')" class="text-[11px] text-blue-600 font-bold hover:underline">Ver todas</button>
              </div>

              <div class="grid grid-cols-1 gap-2.5">
                ${upcomingMaintenances.length === 0 ? `
                  <div class="p-4 text-center text-xs text-slate-400 bg-slate-50 rounded-xl">No hay mantenciones próximas</div>
                ` : upcomingMaintenances.map(item => `
                  <div onclick="openMaintenanceDetail('${item.m.id}')" 
                       class="p-3 rounded-xl bg-slate-50 hover:bg-blue-50 border border-slate-200 hover:border-blue-300 cursor-pointer card-hover transition-all flex flex-col justify-between group">
                    <div class="flex items-center justify-between mb-1.5">
                      <span class="text-[10px] font-extrabold px-2 py-0.5 rounded-md ${item.alert.badgeClass}">
                        ${item.alert.badge}
                      </span>
                      <span class="text-[10px] text-slate-500 font-bold">${formatDate(item.m.limitDate || item.m.startDate)}</span>
                    </div>
                    <h6 class="text-xs font-bold text-slate-800 leading-snug group-hover:text-blue-700 transition-colors line-clamp-2">${item.m.title}</h6>
                    <div class="mt-2 pt-1.5 border-t border-slate-200/60 flex items-center justify-between text-[10px] text-slate-500">
                      <span class="font-medium">${item.m.workAreaName || item.m.areaName}</span>
                      <span class="font-bold text-blue-600 group-hover:translate-x-0.5 transition-transform">Ver ficha →</span>
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>

            <button onclick="navigateTo('mantenciones')" class="w-full mt-4 py-2 bg-slate-100 hover:bg-blue-50 text-slate-700 hover:text-blue-700 rounded-xl text-xs font-bold transition-colors text-center border border-slate-200">
              Ir al Módulo Mantenciones →
            </button>
          </div>

          <!-- 2. Garantías por Vencer (Mini-Tarjetas) -->
          <div class="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-col justify-between">
            <div>
              <div class="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                <h5 class="text-xs font-extrabold text-amber-900 uppercase flex items-center space-x-1.5">
                  <span>🛡️</span>
                  <span>Garantías por Vencer</span>
                </h5>
                <button onclick="navigateTo('activos')" class="text-[11px] text-amber-600 font-bold hover:underline">Ver activos</button>
              </div>

              <div class="grid grid-cols-1 gap-2.5">
                ${expiringWarranties.length === 0 ? `
                  <div class="p-4 text-center text-xs text-slate-400 bg-slate-50 rounded-xl">Todas las garantías al día</div>
                ` : expiringWarranties.map(item => `
                  <div onclick="openAssetDetail('${item.asset.id}', 'garantia')" 
                       class="p-3 rounded-xl bg-amber-50/60 hover:bg-amber-100/60 border border-amber-200 hover:border-amber-300 cursor-pointer card-hover transition-all flex flex-col justify-between group">
                    <div class="flex items-center justify-between mb-1.5">
                      <span class="text-[10px] font-extrabold px-2 py-0.5 rounded-md ${item.wInfo.status === 'Vencida' ? 'bg-rose-100 text-rose-800' : 'bg-amber-200 text-amber-900'
    }">
                        ${item.wInfo.badge}
                      </span>
                      <span class="text-[10px] text-slate-600 font-bold">${item.asset.brand}</span>
                    </div>
                    <h6 class="text-xs font-bold text-slate-800 leading-snug group-hover:text-amber-900 transition-colors line-clamp-2">${item.asset.name}</h6>
                    <div class="mt-2 pt-1.5 border-t border-amber-200/60 flex items-center justify-between text-[10px] text-slate-500">
                      <span>${item.asset.areaName.split(' ')[0]}</span>
                      <span class="font-bold text-amber-800 group-hover:translate-x-0.5 transition-transform">Ver garantía →</span>
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>

            <button onclick="navigateTo('activos')" class="w-full mt-4 py-2 bg-amber-50 hover:bg-amber-100 text-amber-900 rounded-xl text-xs font-bold transition-colors text-center border border-amber-200">
              Control de Garantías →
            </button>
          </div>

          <!-- 3. Trabajos Atrasados (Mini-Tarjetas) -->
          <div class="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-col justify-between">
            <div>
              <div class="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                <h5 class="text-xs font-extrabold text-rose-900 uppercase flex items-center space-x-1.5">
                  <span>⚠️</span>
                  <span>Trabajos Atrasados</span>
                </h5>
                <span class="bg-rose-100 text-rose-700 text-[10px] font-extrabold px-2 py-0.5 rounded-full">${overdueTasks.length} urgentes</span>
              </div>

              <div class="grid grid-cols-1 gap-2.5">
                ${overdueTasks.length === 0 ? `
                  <div class="p-4 text-center text-xs text-emerald-600 font-bold bg-emerald-50 rounded-xl">✓ Cero trabajos atrasados</div>
                ` : overdueTasks.map(item => `
                  <div onclick="openMaintenanceDetail('${item.m.id}')" 
                       class="p-3 rounded-xl bg-rose-50/70 hover:bg-rose-100/70 border border-rose-200 hover:border-rose-400 cursor-pointer card-hover transition-all flex flex-col justify-between group">
                    <div class="flex items-center justify-between mb-1.5">
                      <span class="text-[10px] font-black uppercase px-2 py-0.5 rounded-md bg-rose-200 text-rose-900">
                        Atrasada
                      </span>
                      <span class="text-[10px] text-rose-700 font-extrabold">Venció: ${formatDate(item.m.limitDate)}</span>
                    </div>
                    <h6 class="text-xs font-bold text-slate-900 leading-snug group-hover:text-rose-800 transition-colors line-clamp-2">${item.m.title}</h6>
                    <div class="mt-2 pt-1.5 border-t border-rose-200/60 flex items-center justify-between text-[10px] text-slate-600">
                      <span>${item.m.workAreaName || item.m.areaName}</span>
                      <span class="font-bold text-rose-700 group-hover:translate-x-0.5 transition-transform">Resolver →</span>
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>

            <button onclick="navigateTo('mantenciones')" class="w-full mt-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-900 rounded-xl text-xs font-bold transition-colors text-center border border-rose-200">
              Ver Trabajos Atrasados →
            </button>
          </div>

          <!-- 4. Solicitudes Nuevas (Mini-Tarjetas) -->
          <div class="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-col justify-between">
            <div>
              <div class="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                <h5 class="text-xs font-extrabold text-indigo-900 uppercase flex items-center space-x-1.5">
                  <span>📩</span>
                  <span>Solicitudes Nuevas</span>
                </h5>
                <button onclick="navigateTo('solicitudes')" class="text-[11px] text-indigo-600 font-bold hover:underline">Ver todas</button>
              </div>

              <div class="grid grid-cols-1 gap-2.5">
                ${newRequests.length === 0 ? `
                  <div class="p-4 text-center text-xs text-slate-400 bg-slate-50 rounded-xl">No hay solicitudes pendientes</div>
                ` : newRequests.map(r => `
                  <div onclick="openConvertRequestModal('${r.id}')" 
                       class="p-3 rounded-xl bg-indigo-50/60 hover:bg-indigo-100/60 border border-indigo-200 hover:border-indigo-300 cursor-pointer card-hover transition-all flex flex-col justify-between group">
                    <div class="flex items-center justify-between mb-1.5">
                      <span class="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md bg-indigo-200 text-indigo-900">
                        Prioridad ${r.priority}
                      </span>
                      <span class="text-[10px] text-slate-500 font-semibold">${r.areaName.split(' ')[0]}</span>
                    </div>
                    <h6 class="text-xs font-bold text-slate-900 leading-snug group-hover:text-indigo-800 transition-colors line-clamp-2">${r.title}</h6>
                    <div class="mt-2 pt-1.5 border-t border-indigo-200/60 flex items-center justify-between text-[10px] text-slate-500">
                      <span>De: ${r.requesterName.split(' ')[0]}</span>
                      <span class="font-bold text-indigo-700 group-hover:translate-x-0.5 transition-transform">Convertir →</span>
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>

            <button onclick="navigateTo('solicitudes')" class="w-full mt-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-600/20 transition-all text-center">
              Gestionar Solicitudes →
            </button>
          </div>

        </div>
      </div>

    </div>
  `;
}
