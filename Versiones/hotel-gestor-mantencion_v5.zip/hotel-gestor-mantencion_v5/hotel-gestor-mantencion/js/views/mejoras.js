// ==========================================================
// VISTA: MEJORAS Y OBRAS - HOTEL EL ALMENDRO
// ==========================================================

function renderImprovementsView() {
  return `
    <div class="space-y-6 max-w-7xl mx-auto pb-10">
      
      <div class="bg-gradient-to-r from-emerald-800 to-teal-900 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <span class="bg-emerald-400/20 text-emerald-200 text-xs font-extrabold px-3 py-1 rounded-full uppercase">Obras Nuevas y Mejoras</span>
          <h3 class="text-2xl font-black mt-2">Proyectos de Expansión y Conectividad</h3>
          <p class="text-emerald-100/80 text-xs mt-1">Control presupuestario de nuevas construcciones en parque, terrazas y eventos de El Almendro.</p>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        ${state.improvements.map(imp => `
          <div onclick="openImprovementDetail('${imp.id}')" class="bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-sm hover:shadow-xl transition-all cursor-pointer card-hover flex flex-col justify-between group">
            
            ${imp.photos && imp.photos.length > 0 ? `
              <div class="h-44 bg-slate-100 overflow-hidden relative">
                <img src="${imp.photos[0]}" alt="${imp.name}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
                <div class="absolute top-3 right-3">
                  <span class="bg-slate-900/80 backdrop-blur-md text-white text-xs font-bold px-2.5 py-1 rounded-full">
                    ${imp.status}
                  </span>
                </div>
              </div>
            ` : `
              <div class="h-28 bg-emerald-50 flex items-center justify-center text-4xl">
                🌿
              </div>
            `}

            <div class="p-6 flex-1 flex flex-col justify-between">
              <div>
                <span class="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md">
                  📍 ${imp.areaName}
                </span>

                <h4 class="text-lg font-extrabold text-slate-800 mt-2.5 group-hover:text-emerald-700 transition-colors leading-snug">
                  ${imp.name}
                </h4>

                <p class="text-xs text-slate-600 mt-2 line-clamp-2 leading-relaxed">
                  ${imp.description}
                </p>

                <div class="mt-4">
                  <div class="flex items-center justify-between text-xs font-bold mb-1">
                    <span class="text-slate-600">Avance General</span>
                    <span class="text-emerald-700 font-extrabold">${imp.progressPercent}%</span>
                  </div>
                  <div class="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                    <div class="bg-emerald-500 h-2.5 rounded-full" style="width: ${imp.progressPercent}%"></div>
                  </div>
                </div>
              </div>

              <div class="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
                <div>
                  <p class="text-[10px] text-slate-600 uppercase font-medium">Presupuesto</p>
                  <p class="font-extrabold text-slate-900">${formatCLP(imp.budget)}</p>
                </div>
                <span class="font-bold text-emerald-600 group-hover:translate-x-1 transition-transform flex items-center space-x-1">
                  <span>Ver Detalles</span>
                  <span>→</span>
                </span>
              </div>

            </div>

          </div>
        `).join('')}
      </div>

    </div>
  `;
}
