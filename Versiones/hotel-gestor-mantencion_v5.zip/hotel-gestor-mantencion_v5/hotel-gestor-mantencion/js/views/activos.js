// ==========================================================
// VISTA: ACTIVOS FIJOS & GARANTÍAS - HOTEL EL ALMENDRO
// ==========================================================

function renderAssetsView() {
  let filtered = state.assets.filter(a => {
    if (assetCategoryFilter !== 'TODAS' && a.category !== assetCategoryFilter) return false;
    if (activeAreaFilter && a.areaId !== activeAreaFilter) return false;
    
    if (assetWarrantyFilter !== 'TODAS') {
      const wInfo = calculateWarrantyStatus(a.warranty);
      if (wInfo.status !== assetWarrantyFilter) return false;
    }
    return true;
  });

  return `
    <div class="space-y-6 max-w-7xl mx-auto pb-10">
      
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <button onclick="assetWarrantyFilter='TODAS'; renderCurrentView();" class="p-4 rounded-2xl text-left border-2 transition-all card-hover ${assetWarrantyFilter === 'TODAS' ? 'border-blue-600 bg-blue-50/70 shadow-md ring-2 ring-blue-500/20' : 'border-slate-200 bg-white'}">
          <div class="flex items-center justify-between">
            <span class="text-2xl">🏷️</span>
            <span class="text-xs font-extrabold bg-blue-100 text-blue-800 px-2.5 py-0.5 rounded-full">${state.assets.length}</span>
          </div>
          <p class="font-bold text-slate-800 text-sm mt-2">Total Activos Fijos</p>
          <p class="text-[11px] text-slate-600">Inventario completo</p>
        </button>

        <button onclick="assetWarrantyFilter='Proxima'; renderCurrentView();" class="p-4 rounded-2xl text-left border-2 transition-all card-hover ${assetWarrantyFilter === 'Proxima' ? 'border-amber-600 bg-amber-50/70 shadow-md ring-2 ring-amber-500/20' : 'border-slate-200 bg-white'}">
          <div class="flex items-center justify-between">
            <span class="text-2xl">🛡️</span>
            <span class="text-xs font-extrabold bg-amber-100 text-amber-800 px-2.5 py-0.5 rounded-full">
              ${state.assets.filter(a => calculateWarrantyStatus(a.warranty).status === 'Proxima').length}
            </span>
          </div>
          <p class="font-bold text-slate-800 text-sm mt-2">Garantías por Vencer</p>
          <p class="text-[11px] text-slate-600">Alertas a 60, 30, 15 y 7 días</p>
        </button>

        <button onclick="assetWarrantyFilter='Vencida'; renderCurrentView();" class="p-4 rounded-2xl text-left border-2 transition-all card-hover ${assetWarrantyFilter === 'Vencida' ? 'border-rose-600 bg-rose-50/70 shadow-md ring-2 ring-rose-500/20' : 'border-slate-200 bg-white'}">
          <div class="flex items-center justify-between">
            <span class="text-2xl">⚠️</span>
            <span class="text-xs font-extrabold bg-rose-100 text-rose-800 px-2.5 py-0.5 rounded-full">
              ${state.assets.filter(a => calculateWarrantyStatus(a.warranty).status === 'Vencida').length}
            </span>
          </div>
          <p class="font-bold text-slate-800 text-sm mt-2">Garantías Vencidas</p>
          <p class="text-[11px] text-slate-600">Requieren mantención propia</p>
        </button>
      </div>

      <div class="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-3">
        <div class="flex flex-wrap items-center gap-3">
          <div class="flex items-center space-x-2">
            <label class="text-xs font-bold text-slate-600 uppercase">Filtrar Garantía:</label>
            <select onchange="assetWarrantyFilter=this.value; renderCurrentView();" class="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-700">
              <option value="TODAS" ${assetWarrantyFilter === 'TODAS' ? 'selected' : ''}>Todas</option>
              <option value="Vigente" ${assetWarrantyFilter === 'Vigente' ? 'selected' : ''}>En Garantía</option>
              <option value="Proxima" ${assetWarrantyFilter === 'Proxima' ? 'selected' : ''}>Próxima a vencer</option>
              <option value="Vencida" ${assetWarrantyFilter === 'Vencida' ? 'selected' : ''}>Vencida</option>
            </select>
          </div>

          ${activeAreaFilter ? `
            <button onclick="activeAreaFilter = null; renderCurrentView();" class="bg-blue-100 text-blue-700 text-xs font-bold px-3 py-1 rounded-xl flex items-center space-x-1">
              <span>Filtro de área activo</span>
              <span>✕</span>
            </button>
          ` : ''}
        </div>

        <div class="text-xs font-bold text-slate-600">
          Mostrando <span class="text-blue-600 font-extrabold">${filtered.length}</span> activos fijos
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        ${filtered.map(asset => {
          const wInfo = calculateWarrantyStatus(asset.warranty);
          const wColors = {
            'Vigente': 'bg-emerald-100 text-emerald-800 border-emerald-200',
            'Proxima': 'bg-amber-100 text-amber-800 border-amber-200 font-bold animate-pulse',
            'Vencida': 'bg-rose-100 text-rose-800 border-rose-200',
            'Sin Garantía': 'bg-slate-100 text-slate-700 border-slate-200'
          };

          return `
            <div onclick="openAssetDetail('${asset.id}')" class="bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-sm hover:shadow-xl transition-all cursor-pointer card-hover flex flex-col justify-between group">
              
              <div class="h-44 bg-slate-100 relative overflow-hidden">
                <img src="${asset.photo}" alt="${asset.name}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
                <div class="absolute top-3 left-3">
                  <span class="text-xs font-extrabold px-3 py-1 rounded-full border shadow-sm ${wColors[wInfo.status]}">
                    🛡️ ${wInfo.badge}
                  </span>
                </div>
                <div class="absolute top-3 right-3">
                  <span class="bg-slate-900/80 backdrop-blur-md text-white text-[10px] font-bold px-2.5 py-1 rounded-full">
                    ${asset.status}
                  </span>
                </div>
              </div>

              <div class="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <div class="flex items-center space-x-2 text-xs text-slate-600 font-semibold mb-1">
                    <span>${asset.brand}</span>
                    <span>•</span>
                    <span class="truncate">${asset.model}</span>
                  </div>

                  <h4 class="text-base font-extrabold text-slate-800 group-hover:text-blue-600 transition-colors leading-snug">
                    ${asset.name}
                  </h4>

                  <div class="mt-2.5 space-y-1 text-xs">
                    <div class="flex items-center space-x-1.5 text-slate-600">
                      <span>📍</span>
                      <span class="font-medium text-slate-700">${asset.areaName}</span>
                    </div>
                    <div class="flex items-center space-x-1.5 text-slate-600">
                      <span>🏢</span>
                      <span class="truncate">${asset.location}</span>
                    </div>
                  </div>

                  ${asset.maintenancePlan && asset.maintenancePlan.requiresMaintenance ? `
                    <div class="mt-3.5 bg-blue-50/70 border border-blue-100 rounded-xl p-2.5 text-xs">
                      <p class="text-[10px] font-bold text-blue-900 uppercase">Plan de Mantenimiento</p>
                      <p class="font-semibold text-blue-800 truncate">${asset.maintenancePlan.type}</p>
                      <p class="text-[11px] text-blue-600 font-medium mt-0.5">Próxima: ${formatDate(asset.maintenancePlan.nextDate)} (${asset.maintenancePlan.frequencyLabel})</p>
                    </div>
                  ` : ''}
                </div>

                <div class="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                  <div>
                    <p class="text-[10px] text-slate-600 uppercase font-medium">Valor Compra</p>
                    <p class="font-bold text-slate-800">${formatCLP(asset.purchaseValue)}</p>
                  </div>
                  <span class="font-bold text-blue-600 flex items-center space-x-1 group-hover:translate-x-1 transition-transform">
                    <span>Ficha Técnica</span>
                    <span>→</span>
                  </span>
                </div>

              </div>

            </div>
          `;
        }).join('')}
      </div>

    </div>
  `;
}
