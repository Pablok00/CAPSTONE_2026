// ==========================================================
// VISTA: ÁREAS DE TRABAJO - HOTEL EL ALMENDRO
// ==========================================================

function renderAreasView() {
  const workAreasList = (state.workAreas || DEFAULT_WORK_AREAS).map(area => {
    const stats = getWorkAreaStats(area.id);
    return {
      ...area,
      stats
    };
  });

  return `
    <div class="space-y-6 max-w-7xl mx-auto pb-12">
      
      <!-- ENCABEZADO DE SECCIÓN -->
      <div class="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div class="flex items-center space-x-2.5">
            <span class="text-2xl">📍</span>
            <h3 class="text-xl font-black text-slate-900">Áreas de Trabajo</h3>
          </div>
          <p class="text-xs text-slate-600 mt-1">
            Seis unidades de gestión operativa de El Almendro. Haz clic en cualquiera para abrir su ficha completa con tareas, calendario, costos y materiales.
          </p>
        </div>
        <div class="flex items-center space-x-2">
          <span class="text-xs font-bold text-blue-700 bg-blue-50 border border-blue-200 px-3.5 py-1.5 rounded-xl">
            6 Áreas Base
          </span>
        </div>
      </div>

      <!-- CUADRÍCULA VISUAL: 3x2 en escritorio, 2 col en tablet, 1 col en móvil -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        ${workAreasList.map((area, idx) => {
          const isMain = area.isPrincipal || idx === 0;
          const s = area.stats;

          return `
            <div onclick="openAreaDetail('${area.id}')" 
                 class="bg-white rounded-3xl p-6 border-2 transition-all cursor-pointer card-hover flex flex-col justify-between group relative overflow-hidden shadow-sm hover:shadow-xl ${
                   isMain 
                     ? 'border-blue-600 ring-2 ring-blue-500/20 shadow-blue-900/10' 
                     : 'border-slate-200 hover:border-blue-500'
                 }">
              
              ${isMain ? `
                <div class="absolute -top-0.5 right-6 bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-[10px] font-black uppercase tracking-wider px-3 py-0.5 rounded-b-xl shadow-sm">
                  ⭐ Área Principal
                </div>
              ` : ''}

              <div>
                <div class="flex items-center justify-between mb-3">
                  <div class="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl shadow-inner transition-transform group-hover:scale-110 ${
                    isMain ? 'bg-blue-50 border border-blue-200' : 'bg-slate-100 group-hover:bg-blue-50'
                  }">
                    ${area.icon}
                  </div>

                  <div class="flex items-center space-x-1.5">
                    ${s.delayed > 0 ? `
                      <span class="bg-rose-100 text-rose-700 border border-rose-200 text-xs font-extrabold px-2.5 py-1 rounded-full flex items-center space-x-1">
                        <span>⚠️</span>
                        <span>${s.delayed} Atrasadas</span>
                      </span>
                    ` : `
                      <span class="bg-emerald-100 text-emerald-800 text-xs font-bold px-2.5 py-1 rounded-full">
                        ✓ Al día
                      </span>
                    `}
                  </div>
                </div>

                <h4 class="text-xl font-extrabold text-slate-900 mt-4 group-hover:text-blue-600 transition-colors flex items-center justify-between">
                  <span>${area.name}</span>
                  <span class="text-slate-400 group-hover:text-blue-600 transition-colors text-base">↗</span>
                </h4>

                <p class="text-xs text-slate-800 font-semibold mt-1.5 leading-relaxed">
                  ${area.description}
                </p>

                ${area.bullets && area.bullets.length > 0 ? `
                  <ul class="mt-2.5 space-y-1 text-xs text-slate-600 bg-slate-50/80 group-hover:bg-blue-50/40 p-2.5 rounded-2xl border border-slate-100 transition-colors">
                    ${area.bullets.map(b => `
                      <li class="flex items-start space-x-1.5">
                        <span class="text-blue-600 font-bold text-[11px]">•</span>
                        <span class="text-[11px] font-medium text-slate-700">${b}</span>
                      </li>
                    `).join('')}
                  </ul>
                ` : ''}

                <!-- Resumen Numérico -->
                <div class="grid grid-cols-3 gap-2 mt-5 pt-4 border-t border-slate-100">
                  <div class="bg-slate-50 group-hover:bg-blue-50/50 rounded-xl p-2.5 text-center transition-colors">
                    <p class="text-[10px] text-slate-500 font-bold uppercase">Activas</p>
                    <p class="text-base font-black text-slate-900">${s.active}</p>
                  </div>
                  <div class="bg-slate-50 group-hover:bg-blue-50/50 rounded-xl p-2.5 text-center transition-colors">
                    <p class="text-[10px] text-slate-500 font-bold uppercase">Pendientes</p>
                    <p class="text-base font-black text-amber-600">${s.pending}</p>
                  </div>
                  <div class="bg-slate-50 group-hover:bg-blue-50/50 rounded-xl p-2.5 text-center transition-colors">
                    <p class="text-[10px] text-slate-500 font-bold uppercase">Completadas</p>
                    <p class="text-base font-black text-emerald-600">${s.completed}</p>
                  </div>
                </div>

                <div class="mt-3 flex items-center justify-between text-[11px] text-slate-500 font-medium px-1">
                  <span>Responsable: <strong class="text-slate-700">${area.responsible.split('/')[0]}</strong></span>
                  <span>Gasto: <strong class="text-slate-700">${formatCLP(s.totalActualCost)}</strong></span>
                </div>
              </div>

              <div class="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-blue-600 group-hover:text-blue-700">
                <span>Ver ficha completa y planificación</span>
                <span class="group-hover:translate-x-1 transition-transform">→</span>
              </div>

            </div>
          `;
        }).join('')}
      </div>

    </div>
  `;
}

