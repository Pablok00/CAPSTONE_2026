# Prototipo Gestor de Mantenciones, Obras y Activos Fijos
**Hotel & Centro de Eventos El Almendro**

Estructura de código completamente modularizada, limpia y desacoplada para desarrollo ágil y escalabilidad futura.

---

## 📁 Arquitectura del Proyecto

```
hotel-gestor-mantencion/
├── index.html                      # Contenedor HTML principal y modales
├── README.md                       # Documentación del prototipo
├── css/
│   └── styles.css                  # Estilos CSS personalizados, animaciones y scrollbars
├── data/
│   ├── mockData.js                 # Dataset inicial para Hotel El Almendro
│   └── schema.json                 # Esquema relacional Supabase / PostgreSQL
└── js/
    ├── app.js                      # Enrutador principal e inicializador
    ├── state.js                    # Store de estado global, persistencia y utilidades
    ├── modals.js                   # Controladores de modales y acciones interactivas
    └── views/                      # Vistas modulares independientes
        ├── dashboard.js            # Panel principal con los 3 pilares y resúmenes
        ├── mantenciones.js         # Cuadrícula visual de mantenciones y filtros
        ├── areas.js                # Explorador de los 9 sectores del hotel
        ├── activos.js              # Inventario, fichas técnicas y garantías
        ├── fechasProximas.js       # Compromisos organizados por fecha
        ├── gantt.js                # Línea de tiempo visual y tablero por fases
        ├── mejoras.js              # Proyectos de obras nuevas y avance
        ├── remodelaciones.js       # Remodelaciones con calculadora de materiales
        ├── solicitudes.js          # Bandeja con botón exclusivo de "+ NUEVA SOLICITUD"
        ├── notificaciones.js       # Centro de alertas y notificaciones
        ├── importar.js             # Mapeo y carga masiva Excel / CSV
        └── configuracion.js        # Parámetros y restablecimiento de datos
```

---

## 🚀 Cómo Ejecutar

Abre el archivo [**`index.html`**](file:///C:/Users/B.Salinas/.gemini/antigravity/scratch/hotel-gestor-mantencion/index.html) directamente en cualquier navegador web.
